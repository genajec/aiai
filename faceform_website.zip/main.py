import os
import json
import stripe
import logging
from flask import Flask, render_template, request, redirect, jsonify, url_for, flash, session
from flask_wtf.csrf import CSRFProtect
from flask_wtf import FlaskForm
from wtforms import StringField, PasswordField, BooleanField, HiddenField
from wtforms.validators import DataRequired, Email, EqualTo, Length
from werkzeug.utils import secure_filename
import cv2
import numpy as np
from face_analyzer import FaceAnalyzer
from database import Session, User, Transaction, get_or_create_user, get_user_by_email
import time
from stripe_payment import StripePayment
from dotenv import load_dotenv

# Загрузка переменных окружения
load_dotenv()

# Настройка логирования
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(name)s - %(levelname)s - %(message)s')
logger = logging.getLogger(__name__)

# Инициализация Flask
app = Flask(__name__)
# Установка секретного ключа для сессий
session_secret = os.environ.get("SESSION_SECRET")
if not session_secret:
    # Генерируем секретный ключ и сохраняем его для будущих запусков
    session_secret = os.urandom(24).hex()
    # Если .env файл существует, добавляем ключ туда
    env_path = os.path.join(os.path.dirname(__file__), '.env')
    if os.path.exists(env_path):
        with open(env_path, 'a') as f:
            f.write(f"\nSESSION_SECRET={session_secret}\n")
        logger.info(f"Generated and saved new SESSION_SECRET to .env file")
    
app.secret_key = session_secret
logger.info(f"Flask application initialized with secret key")

# Инициализация CSRF защиты
csrf = CSRFProtect(app)
# Отключаем CSRF для webhook-маршрутов Stripe
csrf.exempt('stripe_webhook')

# Инициализация Stripe
stripe_payment = StripePayment()
stripe.api_key = os.environ.get("STRIPE_SECRET_KEY")

# Инициализация анализатора лиц
face_analyzer = FaceAnalyzer()

# Инициализация интеграции с Telegram ботом
from bot_web_integration import bot_integration

# Формы для регистрации и входа
class RegistrationForm(FlaskForm):
    email = StringField('Email', validators=[DataRequired(), Email()])
    password = PasswordField('Password', validators=[DataRequired(), Length(min=6)])
    password_confirm = PasswordField('Confirm Password', validators=[DataRequired(), EqualTo('password')])
    terms = BooleanField('I agree to the Terms', validators=[DataRequired()])
    
class LoginForm(FlaskForm):
    email = StringField('Email', validators=[DataRequired(), Email()])
    password = PasswordField('Password', validators=[DataRequired()])
    remember = BooleanField('Remember Me')

# Путь для загрузки файлов
UPLOAD_FOLDER = 'static/uploads'
os.makedirs(UPLOAD_FOLDER, exist_ok=True)
app.config['UPLOAD_FOLDER'] = UPLOAD_FOLDER

# Допустимые расширения файлов
ALLOWED_EXTENSIONS = {'png', 'jpg', 'jpeg'}

def allowed_file(filename):
    return '.' in filename and filename.rsplit('.', 1)[1].lower() in ALLOWED_EXTENSIONS

@app.route('/')
def home():
    return render_template('index.html')

@app.route('/about')
def about():
    return render_template('about.html')

@app.route('/services')
def services():
    return render_template('services.html')

@app.route('/hairstyles')
def hairstyles():
    # Получаем данные о доступных прическах для всех форм лица
    face_shapes = ["OVAL", "ROUND", "SQUARE", "HEART", "OBLONG", "DIAMOND"]
    all_hairstyles = {}
    
    for shape in face_shapes:
        male_hairstyles = face_analyzer.get_hairstyle_names(shape, "male")
        female_hairstyles = face_analyzer.get_hairstyle_names(shape, "female")
        all_hairstyles[shape] = {
            'male': male_hairstyles,
            'female': female_hairstyles
        }
        
    return render_template('hairstyles.html', all_hairstyles=all_hairstyles)

@app.route('/try-hairstyle', methods=['GET', 'POST'])
def try_hairstyle():
    if request.method == 'POST':
        # Проверяем, есть ли файл в запросе
        if 'file' not in request.files:
            flash('Файл не найден')
            return redirect(request.url)
            
        file = request.files['file']
        
        # Если пользователь не выбрал файл
        if file.filename == '':
            flash('Файл не выбран')
            return redirect(request.url)
            
        if file and allowed_file(file.filename):
            # Сохраняем файл
            filename = secure_filename(file.filename)
            file_path = os.path.join(app.config['UPLOAD_FOLDER'], filename)
            file.save(file_path)
            
            # Читаем изображение из файла вместо из памяти
            with open(file_path, 'rb') as image_file:
                image_data = image_file.read()
            
            # Анализируем форму лица через интеграцию с ботом
            face_shape, vis_image_bytes, measurements = bot_integration.analyze_face_shape(image_data)
            
            if not face_shape:
                flash('Не удалось определить форму лица. Пожалуйста, загрузите другую фотографию.')
                return redirect(request.url)
                
            # Получаем доступные прически для данной формы лица
            male_hairstyles = face_analyzer.get_hairstyle_names(face_shape, "male")
            female_hairstyles = face_analyzer.get_hairstyle_names(face_shape, "female")
            
            # Сохраняем данные в сессии
            session['face_shape'] = face_shape
            session['original_image'] = file_path
            
            # Сохраняем изображение с визуализацией
            vis_image_path = os.path.join(app.config['UPLOAD_FOLDER'], 'vis_' + filename)
            with open(vis_image_path, 'wb') as f:
                f.write(vis_image_bytes)
            
            # Если пользователь авторизован и имеет Telegram ID, отправляем ему результат анализа
            telegram_id = session.get('user_id', None)
            if telegram_id and telegram_id not in (0, 'website_user'):
                try:
                    # Отправляем результат анализа в Telegram
                    caption = f"Анализ формы лица: {face_shape}\nМы готовы подобрать вам прическу!"
                    bot_integration.send_image_result_to_user(
                        user_id=telegram_id,
                        image_bytes=vis_image_bytes,
                        caption=caption
                    )
                    logger.info(f"Результат анализа отправлен пользователю {telegram_id} в Telegram")
                except Exception as telegram_error:
                    logger.error(f"Ошибка при отправке результата в Telegram: {telegram_error}")
            
            return render_template('try_hairstyle.html', 
                                  face_shape=face_shape, 
                                  original_image=file_path.replace('static/', ''),
                                  vis_image=vis_image_path.replace('static/', ''),
                                  male_hairstyles=male_hairstyles,
                                  female_hairstyles=female_hairstyles)
    
    return render_template('try_hairstyle.html')

@app.route('/apply-hairstyle', methods=['POST'])
def apply_hairstyle():
    # Получаем данные из запроса
    data = request.get_json()
    hairstyle_index = int(data.get('hairstyle_index', 0))
    gender = data.get('gender', 'male')
    
    # Получаем данные из сессии
    face_shape = session.get('face_shape')
    original_image_path = session.get('original_image')
    telegram_id = session.get('user_id', None)
    
    if not face_shape or not original_image_path:
        return jsonify({'error': 'Данные о лице отсутствуют, загрузите фото снова'})
    
    try:
        # Читаем изображение
        with open(original_image_path, 'rb') as f:
            image_data = f.read()
        
        # Используем интеграцию с ботом для обработки запроса
        result_image_bytes = bot_integration.process_hairstyle_request(
            image_data=image_data,
            face_shape=face_shape,
            hairstyle_index=hairstyle_index,
            gender=gender
        )
        
        if not result_image_bytes:
            return jsonify({'error': 'Не удалось применить прическу'})
        
        # Сохраняем результат
        result_filename = f"result_{time.time()}.jpg"
        result_path = os.path.join(app.config['UPLOAD_FOLDER'], result_filename)
        with open(result_path, 'wb') as f:
            f.write(result_image_bytes)
        
        # Если пользователь авторизован и имеет Telegram ID, отправляем результат в Telegram
        if telegram_id and telegram_id not in (0, 'website_user'):
            try:
                # Отправляем результат в Telegram
                caption = f"Ваша фотография с примеркой прически #{hairstyle_index+1} ({gender})"
                bot_integration.send_image_result_to_user(
                    user_id=telegram_id,
                    image_bytes=result_image_bytes,
                    caption=caption
                )
                logger.info(f"Результат обработки отправлен пользователю {telegram_id} в Telegram")
            except Exception as telegram_error:
                logger.error(f"Ошибка при отправке результата в Telegram: {telegram_error}")
        
        return jsonify({'success': True, 'image_url': f"/static/uploads/{result_filename}"})
    
    except Exception as e:
        logger.error(f"Ошибка при применении прически: {e}")
        return jsonify({'error': f'Произошла ошибка: {str(e)}'})

@app.route('/pricing')
def pricing():
    packages = stripe_payment.get_credit_packages()
    return render_template('pricing.html', packages=packages)

@app.route('/create-checkout-session', methods=['POST'])
def create_checkout_session():
    try:
        # Получаем ID пакета из запроса
        package_id = request.form.get('package_id')
        logger.info(f"Получен запрос на создание сессии оплаты для пакета: {package_id}")
        
        if not package_id:
            logger.error("Package ID не был передан в форме")
            return jsonify({'error': 'Package ID is required'}), 400
        
        # Находим пакет по ID
        packages = stripe_payment.get_credit_packages()
        package = next((p for p in packages if p['id'] == package_id), None)
        
        if not package:
            logger.error(f"Пакет с ID {package_id} не найден в списке доступных пакетов")
            return jsonify({'error': 'Invalid package ID'}), 400
        
        # Получаем домен для URL успеха и отмены
        domain = stripe_payment._get_domain()
        logger.info(f"Домен для редиректа: {domain}")
        
        # Создаем сессию оплаты в Stripe
        logger.info(f"Создаем сессию оплаты для пакета {package['name']} стоимостью {package['price']}$")
        
        checkout_session = stripe.checkout.Session.create(
            payment_method_types=['card'],
            line_items=[
                {
                    'price_data': {
                        'currency': 'usd',
                        'product_data': {
                            'name': package['description'],
                        },
                        'unit_amount': int(package['price'] * 100),  # стоимость в центах
                    },
                    'quantity': 1,
                },
            ],
            mode='payment',
            success_url=f'https://{domain}/success?session_id={{CHECKOUT_SESSION_ID}}',
            cancel_url=f'https://{domain}/cancel',
            metadata={
                'package_id': package_id,
                'credits': package['credits'],
                'user_id': session.get('user_id', 'website_user')
            }
        )
        
        logger.info(f"Сессия оплаты создана успешно. ID: {checkout_session.id}")
        
        # Сохраняем транзакцию в базе данных
        db_session = Session()
        try:
            # Получаем или создаем пользователя для этой транзакции
            telegram_id = session.get('user_id', 0)
            logger.info(f"ID пользователя из сессии: {telegram_id}")
            
            # Используем функцию из database.py для получения или создания пользователя
            from database import get_or_create_user
            user = get_or_create_user(
                telegram_id=telegram_id,
                username="website_user"
            )
            
            logger.info(f"Пользователь получен/создан: ID в БД: {user.id}, telegram_id: {user.telegram_id}")
            
            # Создаем транзакцию с правильным user_id
            transaction = Transaction(
                user_id=user.id,  # Используем ID пользователя из БД
                payment_id=checkout_session.id,
                payment_method='stripe',
                amount=package['price'],
                credits=package['credits'],
                status='pending'
            )
            db_session.add(transaction)
            db_session.commit()
            
            # Сохраняем ID транзакции в сессии для отслеживания
            session['transaction_id'] = transaction.id
            logger.info(f"Транзакция создана и сохранена в БД. ID: {transaction.id}")
            
        except Exception as db_error:
            logger.error(f"Ошибка базы данных: {db_error}")
        finally:
            db_session.close()
        
        # Перенаправляем пользователя на страницу оплаты Stripe
        logger.info(f"Перенаправляем пользователя на страницу оплаты: {checkout_session.url}")
        return redirect(checkout_session.url, code=303)
    
    except Exception as e:
        logger.error(f"Ошибка при создании сессии оплаты: {str(e)}")
        import traceback
        logger.error(traceback.format_exc())
        
        # Возвращаем ошибку на страницу
        flash('Произошла ошибка при создании платежа. Пожалуйста, попробуйте позже.', 'danger')
        return redirect(url_for('pricing'))

@app.route('/register', methods=['GET', 'POST'])
def register():
    form = RegistrationForm()
    session_id = request.args.get('session_id')
    payment_complete = request.args.get('payment') == 'True'
    credits = 0
    
    # Если есть email в сессии от успешной оплаты, предзаполняем форму
    if 'payment_email' in session:
        payment_email = session.get('payment_email')
        session_id = session.get('payment_session_id')
        form.email.data = payment_email
        
        # Получаем информацию о платеже и кредитах
        if session_id:
            try:
                # Получаем данные о транзакции из базы
                from database import Session as DBSession, Transaction
                db_session = DBSession()
                transaction = db_session.query(Transaction).filter_by(payment_id=session_id).first()
                if transaction:
                    credits = transaction.credits
                db_session.close()
            except Exception as e:
                logger.error(f"Ошибка при получении информации о транзакции: {e}")
    
    if request.method == 'POST':
        if form.validate_on_submit():
            email = form.email.data
            password = form.password.data
            form_session_id = request.form.get('session_id')
            
            # Если передан session_id в форме, используем его
            if form_session_id:
                session_id = form_session_id
            # Если нет, но есть в сессии, используем его
            elif 'payment_session_id' in session:
                session_id = session.get('payment_session_id')
            
            # Проверяем, существует ли пользователь с таким email
            existing_user = get_user_by_email(email)
            if existing_user:
                flash('Пользователь с таким email уже существует. Пожалуйста, войдите.', 'danger')
                return redirect(url_for('login', session_id=session_id))
            
            # Генерируем уникальный telegram_id (в реальности это будет настоящий id)
            import random
            telegram_id = random.randint(10000000, 99999999)
            
            # Создаем нового пользователя
            user = get_or_create_user(
                telegram_id=telegram_id,
                username=email.split('@')[0],  # Используем часть email как username
                email=email,
                password=password
            )
            
            # Если транзакция из Stripe вебхука и есть session_id
            if session_id:
                try:
                    # Завершаем транзакцию и начисляем кредиты
                    transaction_completed = complete_transaction(session_id, 'completed', user_id=telegram_id)
                    if transaction_completed:
                        logger.info(f"Транзакция {session_id} успешно завершена для нового пользователя {user.id}")
                        flash(f'Ваш аккаунт успешно создан! Вам начислено {credits} кредитов.', 'success')
                    else:
                        logger.error(f"Не удалось завершить транзакцию {session_id} для нового пользователя {user.id}")
                        flash('Аккаунт создан, но возникла проблема с начислением кредитов. Пожалуйста, обратитесь в поддержку.', 'warning')
                except Exception as e:
                    logger.error(f"Ошибка при завершении транзакции для нового пользователя: {e}")
                    flash('Аккаунт создан, но возникла проблема с начислением кредитов. Пожалуйста, обратитесь в поддержку.', 'warning')
            else:
                flash('Аккаунт успешно создан!', 'success')
            
            # Устанавливаем пользователя в сессию
            session['user_id'] = user.telegram_id
            
            # Очищаем данные платежа из сессии
            if 'payment_email' in session:
                session.pop('payment_email')
            if 'payment_session_id' in session:
                session.pop('payment_session_id')
            
            # Перенаправляем на страницу успеха или домашнюю страницу
            if session_id:
                return redirect(url_for('payment_success', session_id=session_id, user_registered=True, credits=credits))
            else:
                return redirect(url_for('home'))
    
    return render_template('register.html', form=form, session_id=session_id, credits=credits, payment_complete=payment_complete)

@app.route('/login', methods=['GET', 'POST'])
def login():
    form = LoginForm()
    session_id = request.args.get('session_id')
    
    if request.method == 'POST':
        if form.validate_on_submit():
            email = form.email.data
            password = form.password.data
            session_id = request.form.get('session_id')
            
            # Ищем пользователя по email
            user = get_user_by_email(email)
            
            if user and user.check_password(password):
                # Устанавливаем пользователя в сессию
                session['user_id'] = user.telegram_id
                flash('Вы успешно вошли в систему!', 'success')
                
                # Если есть session_id, обрабатываем транзакцию для авторизованного пользователя
                if session_id:
                    credits = 0
                    try:
                        # Получаем информацию о сессии
                        checkout_session = stripe.checkout.Session.retrieve(session_id)
                        if checkout_session.payment_status == 'paid':
                            credits = int(checkout_session.metadata.get('credits', 0))
                            
                            # Завершаем транзакцию
                            transaction_completed = complete_transaction(session_id, 'completed')
                            if transaction_completed:
                                logger.info(f"Transaction {session_id} successfully completed for logged in user {user.id}")
                                flash(f'Вам начислено {credits} кредитов!', 'success')
                            else:
                                logger.error(f"Failed to complete transaction {session_id} for logged in user {user.id}")
                        return redirect(url_for('payment_success', session_id=session_id, user_registered=True, credits=credits))
                    except Exception as e:
                        logger.error(f"Error processing transaction after login: {e}")
                
                return redirect(url_for('home'))
            else:
                flash('Неверный email или пароль', 'danger')
    
    return render_template('login.html', form=form, session_id=session_id)

@app.route('/success')
def payment_success():
    session_id = request.args.get('session_id')
    user_registered = request.args.get('user_registered') == 'True'
    credits = request.args.get('credits', 0)
    
    if session_id and not user_registered:
        try:
            # Получаем информацию о сессии из Stripe
            checkout_session = stripe.checkout.Session.retrieve(session_id)
            
            # Проверяем, что платеж успешен
            if checkout_session.payment_status == 'paid':
                # Извлекаем метаданные
                package_id = checkout_session.metadata.get('package_id')
                credits = int(checkout_session.metadata.get('credits', 0))
                
                # Проверяем, авторизован ли пользователь
                if 'user_id' in session and session['user_id'] != 0 and session['user_id'] != 'website_user':
                    # Пользователь авторизован, можем сразу обработать транзакцию
                    transaction_completed = complete_transaction(session_id, 'completed')
                    
                    if transaction_completed:
                        logger.info(f"Transaction {session_id} successfully completed and credits awarded")
                        user_registered = True
                    
                # Получаем информацию о транзакции для отображения
                db_session = Session()
                try:
                    transaction = db_session.query(Transaction).filter_by(payment_id=session_id).first()
                    if transaction:
                        # Сохраняем ID транзакции в сессии для отслеживания
                        session['transaction_id'] = transaction.id
                except Exception as db_error:
                    logger.error(f"Database error: {db_error}")
                finally:
                    db_session.close()
                
                return render_template('success.html', session_id=session_id, credits=credits, user_registered=user_registered)
        
        except Exception as e:
            logger.error(f"Error processing success page: {e}")
    
    return render_template('success.html', session_id=session_id, credits=credits, user_registered=user_registered)

@app.route('/cancel')
def payment_cancel():
    return render_template('cancel.html')

@app.route('/webhook', methods=['POST'])
def stripe_webhook():
    payload = request.get_data(as_text=True)
    sig_header = request.headers.get('Stripe-Signature')
    
    try:
        event = stripe.Webhook.construct_event(
            payload, sig_header, os.environ.get('STRIPE_WEBHOOK_SECRET', '')
        )
    except ValueError as e:
        # Invalid payload
        logger.error(f"Invalid payload: {e}")
        return jsonify({'error': 'Invalid payload'}), 400
    except stripe.error.SignatureVerificationError as e:
        # Invalid signature
        logger.error(f"Invalid signature: {e}")
        return jsonify({'error': 'Invalid signature'}), 400
    
    # Handle the event
    if event['type'] == 'checkout.session.completed':
        session = event['data']['object']
        session_id = session.id
        
        logger.info(f"Received webhook for completed session {session_id}")
        
        # Используем функцию из database.py для завершения транзакции и начисления кредитов
        from database import complete_transaction
        transaction_completed = complete_transaction(session_id, 'completed')
        
        if transaction_completed:
            logger.info(f"Transaction {session_id} successfully completed via webhook")
        else:
            logger.warning(f"Failed to complete transaction {session_id} via webhook")
    
    return jsonify({'status': 'success'})

@app.route('/contact')
def contact():
    return render_template('contact.html')

@app.route('/link-telegram', methods=['GET', 'POST'])
def link_telegram():
    """Страница для связывания Telegram аккаунта с веб-аккаунтом"""
    if request.method == 'POST':
        # Получаем данные из формы
        telegram_id = request.form.get('telegram_id')
        email = request.form.get('email')
        
        if not telegram_id or not email:
            flash('Пожалуйста, укажите все необходимые данные', 'danger')
            return redirect(url_for('link_telegram'))
        
        # Пытаемся преобразовать telegram_id в int
        try:
            telegram_id = int(telegram_id)
        except ValueError:
            flash('Неверный формат Telegram ID', 'danger')
            return redirect(url_for('link_telegram'))
        
        # Связываем аккаунты
        from database import link_telegram_to_web_account
        success = link_telegram_to_web_account(telegram_id, email)
        
        if success:
            # Если связывание успешно, уведомляем пользователя через Telegram
            try:
                bot_integration.send_notification(
                    user_id=telegram_id,
                    message_text="Ваш Telegram аккаунт успешно связан с веб-аккаунтом. Теперь результаты обработки будут автоматически отправляться вам в Telegram."
                )
            except Exception as e:
                logger.error(f"Ошибка при отправке уведомления в Telegram: {e}")
            
            flash('Аккаунты успешно связаны!', 'success')
            return redirect(url_for('home'))
        else:
            flash('Не удалось связать аккаунты. Пожалуйста, проверьте правильность введенных данных.', 'danger')
            return redirect(url_for('link_telegram'))
    
    return render_template('link_telegram.html')

if __name__ == '__main__':
    # Используем порт 8080 вместо 5000, так как порт 5000 уже занят
    port = 8080
    logger.info(f"Starting Flask application on port {port}")
    app.run(host='0.0.0.0', port=port, debug=True)