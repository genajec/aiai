"""
Модуль для обработки платежей через Stripe
"""
import os
import time
import stripe
import logging
import json
from flask import Flask, redirect, request, url_for, render_template, jsonify
from urllib.parse import urljoin

logger = logging.getLogger(__name__)

class StripePayment:
    """Класс для работы с платежами через Stripe"""
    
    def __init__(self):
        """Инициализация объекта для работы с платежами через Stripe"""
        # Перезагружаем переменные окружения из .env файла для уверенности
        from dotenv import load_dotenv
        from pathlib import Path
        
        # Загружаем переменные окружения из .env файла, если он существует
        env_path = Path('.') / '.env'
        if env_path.exists():
            load_dotenv(dotenv_path=env_path)
            logger.info("Переменные окружения загружены из .env")

        # Проверяем наличие API ключа Stripe сначала через переменные окружения
        self.api_key = os.environ.get("STRIPE_SECRET_KEY")
        
        # Если ключ не найден, попробуем прочитать его напрямую из файла .env
        if not self.api_key and env_path.exists():
            try:
                with open(env_path, 'r') as env_file:
                    for line in env_file:
                        if line.strip().startswith('STRIPE_SECRET_KEY='):
                            self.api_key = line.strip().split('=', 1)[1]
                            # Установим переменную окружения явно
                            os.environ["STRIPE_SECRET_KEY"] = self.api_key
                            logger.info("API ключ Stripe загружен напрямую из файла .env")
                            break
            except Exception as e:
                logger.error(f"Ошибка при чтении файла .env: {e}")
                
        logger.info(f"Проверка API ключа Stripe: {'найден' if self.api_key else 'не найден'}")
        
        if self.api_key:
            stripe.api_key = self.api_key
            logger.info(f"Stripe API ключ успешно установлен (тип: {type(self.api_key)}), интеграция активирована")
            # Сохраняем в дополнительное поле для проверки
            self.stripe_integration_active = True
        else:
            logger.warning("Stripe API ключ не найден, платежи через Stripe недоступны")
            self.api_key = None
            self.stripe_integration_active = False
            
        # Базовый URL для редиректов
        self.domain = self._get_domain()
        
        # Пакеты кредитов с указанием функций
        self.credit_packages = [
            {
                "id": "micro", 
                "name": "Микро",
                "price": 0.4, 
                "credits": 1, 
                "description": "Попробовать одну функцию за минимальную стоимость",
                "features": [
                    "1 примерка причёски",
                    "Сохранение результата"
                ],
                "popular": False
            },
            {
                "id": "basic", 
                "name": "Стартовый",
                "price": 9.99, 
                "credits": 10, 
                "description": "Идеальный вариант для знакомства с премиум-функциями",
                "features": [
                    "5 примерок причёсок",
                    "1 детальный отчёт о лице",
                    "Сохранение результатов"
                ],
                "popular": False
            },
            {
                "id": "standard", 
                "name": "Стандарт",
                "price": 19.99, 
                "credits": 25, 
                "description": "Оптимальный выбор для большинства пользователей",
                "features": [
                    "12 примерок причёсок",
                    "2 детальных отчёта о лице",
                    "1 анализ по видео",
                    "Приоритетная поддержка"
                ],
                "popular": True
            },
            {
                "id": "premium", 
                "name": "Премиум",
                "price": 39.99, 
                "credits": 60, 
                "description": "Максимальные возможности для полного преображения",
                "features": [
                    "30 примерок причёсок",
                    "5 детальных отчётов о лице",
                    "2 анализа по видео",
                    "1 генерация уникальной причёски",
                    "VIP поддержка 24/7"
                ],
                "popular": False
            }
        ]
        
        # Сохранение информации о платежах
        self.payment_sessions = {}
        
        # При инициализации проверяем незавершенные платежи
        if self.stripe_integration_active:
            try:
                self.check_pending_payments()
            except Exception as e:
                logger.error(f"Ошибка при проверке незавершенных платежей: {e}")
        
    def _get_domain(self):
        """Получает базовый домен для редиректов"""
        # Проверяем наличие принудительного домена для интеграции Stripe
        if os.environ.get('STRIPE_REDIRECT_DOMAIN'):
            domain = os.environ.get('STRIPE_REDIRECT_DOMAIN')
            logger.info(f"Используем домен из STRIPE_REDIRECT_DOMAIN: {domain}")
            return domain
            
        # Для Replit
        if os.environ.get('REPLIT_DEPLOYMENT'):
            domain = os.environ.get('REPLIT_DEV_DOMAIN')
            logger.info(f"Используем домен из REPLIT_DEV_DOMAIN: {domain}")
            return domain
        elif os.environ.get('REPLIT_DOMAINS'):
            replit_domains = os.environ.get('REPLIT_DOMAINS')
            if replit_domains:
                domains = replit_domains.split(',')
                # Выбираем домен без слова "webview" для лучшей совместимости
                domain = next((d for d in domains if 'webview' not in d), domains[0])
                logger.info(f"Используем домен из REPLIT_DOMAINS: {domain}")
                return domain
        
        # ВНИМАНИЕ: Использование localhost требует настройки Stripe CLI для тестирования
        logger.warning("Не удалось определить домен, используем localhost:5000")
        return 'localhost:5000'
    
    def check_pending_payments(self):
        """
        Проверяет незавершенные платежи в базе данных и в Stripe
        и обрабатывает их (для случаев, когда вебхуки были пропущены)
        
        Returns:
            int: Количество обработанных платежей
        """
        if not self.api_key:
            logger.warning("Невозможно проверить незавершенные платежи без API ключа Stripe")
            return 0
            
        try:
            logger.info("Начинаем проверку незавершенных платежей Stripe...")
            processed_count = 0
            
            # Проверяем платежи в базе данных со статусом pending_webhook
            from database import Session, Transaction, User
            db_session = Session()
            
            try:
                # Находим транзакции со статусом pending_webhook
                pending_transactions = db_session.query(Transaction).filter(
                    Transaction.status.in_(['pending', 'pending_webhook'])
                ).all()
                
                logger.info(f"Найдено {len(pending_transactions)} незавершенных транзакций в базе данных")
                
                # Проверяем каждую транзакцию
                for transaction in pending_transactions:
                    try:
                        # Если это транзакция Stripe, проверяем её статус через API
                        if transaction.payment_method == 'stripe' and transaction.payment_id:
                            # Проверка через API Stripe
                            payment_id = transaction.payment_id
                            
                            # Получаем информацию о платеже
                            payment_data = self.get_payment_data(payment_id)
                            
                            # Если платеж завершен успешно
                            if payment_data and payment_data.get('status') == 'completed':
                                # Проверяем, был ли платеж уже обработан
                                if transaction.status == 'completed':
                                    logger.info(f"Платеж {payment_id} уже был успешно обработан ранее")
                                    continue
                                
                                # Обновляем статус в базе данных
                                transaction.status = 'completed'
                                db_session.commit()
                                
                                # Начисляем кредиты пользователю
                                user = db_session.query(User).filter_by(telegram_id=transaction.telegram_id).first()
                                if user:
                                    user.credits += transaction.credits
                                    db_session.commit()
                                    logger.info(f"Начислено {transaction.credits} кредитов пользователю {transaction.telegram_id} за платеж {payment_id}")
                                else:
                                    # Если пользователя нет, создаем его
                                    new_user = User(
                                        telegram_id=transaction.telegram_id,
                                        credits=transaction.credits,
                                        created_at=int(time.time())
                                    )
                                    db_session.add(new_user)
                                    db_session.commit()
                                    logger.info(f"Создан новый пользователь {transaction.telegram_id} и начислено {transaction.credits} кредитов за платеж {payment_id}")
                                
                                processed_count += 1
                            
                            # Если API не вернул данные, попробуем получить информацию напрямую из Stripe
                            elif not payment_data and (transaction.payment_id.startswith('cs_') or transaction.payment_id.startswith('pl_')):
                                try:
                                    # Проверяем статус напрямую через Stripe API
                                    logger.info(f"Проверяем статус платежа {transaction.payment_id} напрямую через Stripe API")
                                    
                                    if transaction.payment_id.startswith('cs_'):
                                        # Для checkout.Session
                                        session = stripe.checkout.Session.retrieve(transaction.payment_id)
                                        payment_completed = session and session.payment_status == 'paid'
                                    elif transaction.payment_id.startswith('pl_'):
                                        # Для PaymentLink - проверяем через связанные платежи
                                        payment_link = stripe.PaymentLink.retrieve(transaction.payment_id)
                                        payments = stripe.PaymentIntent.list(limit=10)
                                        payment_completed = False
                                        
                                        # Ищем успешные платежи с соответствующими метаданными
                                        for payment in payments:
                                            if (payment.status == 'succeeded' and 
                                                payment.metadata.get('telegram_id') == str(transaction.telegram_id)):
                                                payment_completed = True
                                                logger.info(f"Найден успешный платеж {payment.id} для транзакции {transaction.payment_id}")
                                                break
                                    else:
                                        # Неизвестный тип платежа
                                        payment_completed = False
                                    
                                    if payment_completed:
                                        logger.info(f"Платеж {transaction.payment_id} найден и оплачен через Stripe API")
                                        
                                        # Обновляем статус в базе данных
                                        transaction.status = 'completed'
                                        db_session.commit()
                                        
                                        # Начисляем кредиты пользователю
                                        user = db_session.query(User).filter_by(telegram_id=transaction.telegram_id).first()
                                        if user:
                                            user.credits += transaction.credits
                                            db_session.commit()
                                            logger.info(f"Начислено {transaction.credits} кредитов пользователю {transaction.telegram_id} за платеж {transaction.payment_id}")
                                        else:
                                            # Если пользователя нет, создаем его
                                            new_user = User(
                                                telegram_id=transaction.telegram_id,
                                                credits=transaction.credits,
                                                created_at=int(time.time())
                                            )
                                            db_session.add(new_user)
                                            db_session.commit()
                                            logger.info(f"Создан новый пользователь {transaction.telegram_id} и начислено {transaction.credits} кредитов за платеж {transaction.payment_id}")
                                        
                                        processed_count += 1
                                        # Отправляем уведомление пользователю
                                        try:
                                            import telebot
                                            bot_token = os.environ.get('TELEGRAM_API_TOKEN')
                                            if bot_token:
                                                bot = telebot.TeleBot(bot_token)
                                                message = f"✅ Ваш платеж успешно обработан! Вам начислено {transaction.credits} кредитов."
                                                bot.send_message(transaction.telegram_id, message)
                                                logger.info(f"Отправлено уведомление пользователю {transaction.telegram_id}")
                                        except Exception as notify_error:
                                            logger.error(f"Ошибка при отправке уведомления: {notify_error}")
                                except Exception as stripe_error:
                                    logger.error(f"Ошибка при прямом запросе к Stripe API: {stripe_error}")
                    except Exception as tx_error:
                        logger.error(f"Ошибка при обработке транзакции {transaction.payment_id}: {tx_error}")
            
            finally:
                db_session.close()
                
            logger.info(f"Завершена проверка незавершенных платежей. Обработано: {processed_count}")
            return processed_count
            
        except Exception as e:
            logger.error(f"Ошибка при проверке незавершенных платежей: {e}")
            import traceback
            logger.error(traceback.format_exc())
            return 0
            
    def get_credit_packages(self):
        """Получить доступные пакеты кредитов"""
        return self.credit_packages
    
    def create_payment(self, amount, package_id, telegram_id, title=None, description=None):
        """
        Создание сессии оплаты в Stripe
        
        Args:
            amount (float): Сумма платежа в долларах
            package_id (str): ID пакета кредитов
            telegram_id (int): Telegram ID пользователя
            title (str, optional): Заголовок платежа
            description (str, optional): Описание платежа
            
        Returns:
            dict: Информация о созданной сессии или None в случае ошибки
        """
        if not self.api_key:
            logger.error("Попытка создать платеж без API ключа Stripe")
            return None
        
        if not title:
            title = f"Покупка пакета кредитов"
        
        # Поиск количества кредитов по ID пакета
        credits = self.get_credits_by_package_id(package_id)
        
        if not description:
            description = f"Покупка пакета из {credits} кредитов для использования премиум-функций FaceForm Bot"
        
        try:
            # Проверяем тип ключа и выводим информацию в логи
            is_test_mode = self.api_key and self.api_key.startswith('sk_test_')
            logger.info(f"Stripe в тестовом режиме: {is_test_mode}")
            
            # РАДИКАЛЬНОЕ ИЗМЕНЕНИЕ 2: Используем фиксированный URL для Stripe Buy Button
            # Это наиболее стабильный способ интеграции, работающий даже в строгих браузерах
            telegram_bot_name = os.environ.get("TELEGRAM_BOT_NAME", "Faceform_bot")
            
            # URL для телеграм бота (используется только для логирования)
            telegram_bot_url = f"https://t.me/{telegram_bot_name}"
            logger.info(f"Telegram bot URL: {telegram_bot_url}")
            
            # Формируем URL для возврата пользователя в Telegram после оплаты
            # Используем формат, который будет передавать данные об оплате
            success_url = f"https://t.me/{telegram_bot_name}?start=success_payment_" + "{{CHECKOUT_SESSION_ID}}"
            cancel_url = f"https://t.me/{telegram_bot_name}?start=cancel_payment"
            
            # Логируем режим работы
            logger.info(f"Используем режим работы Stripe: {'тестовый' if is_test_mode else 'боевой'}")
            
            # Логируем URLs для отладки
            logger.info(f"Success URL: {success_url}")
            logger.info(f"Cancel URL: {cancel_url}")
            
            # Метаданные для связи платежа с пользователем
            # Эти данные будут доступны в веб-хуке
            metadata = {
                "package_id": package_id,
                "telegram_id": str(telegram_id),
                "credits": str(credits),
                "is_test": str(is_test_mode).lower()
            }
            
            # Базовые параметры сессии оплаты
            line_items = [{
                'price_data': {
                    'currency': 'usd',
                    'product_data': {
                        'name': title,
                        'description': description,
                    },
                    'unit_amount': int(amount * 100),  # в центах
                },
                'quantity': 1,
            }]
            
            # Параметры платежного метода
            payment_method_options = {}
            payment_method_types = ['card']
            
            # В тестовом режиме показываем дополнительное сообщение с инструкциями
            if is_test_mode:
                payment_method_options = {
                    'card': {
                        'setup_future_usage': None  # Не сохраняем карту для будущих платежей
                    }
                }
            
            # САМОЕ РАДИКАЛЬНОЕ ИЗМЕНЕНИЕ:
            # Вместо создания checkout session мы генерируем прямую ссылку на оплату
            # через Stripe Payment Links - наиболее стабильный механизм, который работает везде
            
            # Сначала создаем или получаем существующий product
            stripe_product_name = f"FaceForm Credits - {credits}"
            products = stripe.Product.list(limit=100)
            product = None
            
            # Ищем существующий product или создаем новый
            for p in products:
                if p.name == stripe_product_name:
                    product = p
                    break
                    
            if not product:
                product = stripe.Product.create(
                    name=stripe_product_name,
                    description=description
                )
                
            # Создаем или получаем Price для продукта
            prices = stripe.Price.list(product=product.id, limit=10)
            price = None
            
            for p in prices:
                if p.unit_amount == int(amount * 100) and p.currency == 'usd':
                    price = p
                    break
                    
            if not price:
                price = stripe.Price.create(
                    product=product.id,
                    unit_amount=int(amount * 100),
                    currency='usd'
                )
                
            # Создаем PaymentLink - стабильная прямая ссылка на оплату,
            # которая работает в любом браузере, даже с ограниченными cookie
            payment_link = stripe.PaymentLink.create(
                line_items=[
                    {
                        "price": price.id,
                        "quantity": 1
                    }
                ],
                metadata=metadata
            )
            
            # Для обратной совместимости с кодом создаем объект с нужными полями
            class SessionMock:
                def __init__(self, id, url):
                    self.id = id
                    self.url = url
                    
            session = SessionMock(f"pl_{int(time.time())}", payment_link.url)
            
            # Сохраняем информацию о сессии для последующей проверки
            session_id = session.id
            self.payment_sessions[session_id] = {
                "package_id": package_id,
                "telegram_id": telegram_id,
                "amount": amount,
                "credits": credits,
                "created_at": time.time(),
                "status": "pending"
            }
            
            logger.info(f"Создана сессия оплаты Stripe для пользователя {telegram_id} на сумму {amount}$: {session_id}")
            
            return {
                "session_id": session_id,
                "payment_url": session.url,
                "amount": amount,
                "credits": credits,
                "package_id": package_id
            }
            
        except Exception as e:
            logger.error(f"Ошибка при создании платежа через Stripe: {e}")
            return None
    
    def check_payment_status(self, session_id):
        """
        Проверка статуса платежа
        
        Args:
            session_id (str): ID сессии Stripe или PaymentLink
            
        Returns:
            str: Статус платежа ('pending', 'completed', 'canceled') или None в случае ошибки
        """
        if not self.api_key:
            logger.error("Попытка проверить платеж без API ключа Stripe")
            return None
            
        try:
            # Для совместимости с нашим новым подходом
            # Мы просто считаем, что если пользователь вернулся, то платеж завершен
            # В реальности мы должны проверять это через webhook события
            
            # Проверяем, является ли это нашим сгенерированным ID для PaymentLink
            if session_id.startswith("pl_"):
                # Это PaymentLink, нет прямого способа проверить его статус
                # Полагаемся на данные в нашем хранилище
                payment_data = self.payment_sessions.get(session_id)
                if payment_data:
                    # Для демонстрации считаем платеж успешным при возврате по success URL
                    # В реальном сценарии подтверждение должно приходить через webhook
                    payment_data["status"] = "completed"
                    return "completed"
                else:
                    return "pending"
            
            # Стандартная проверка для checkout.Session
            try:
                session = stripe.checkout.Session.retrieve(session_id)
                payment_status = session.payment_status
                
                if payment_status == "paid":
                    return "completed"
                elif payment_status == "unpaid":
                    return "pending"
                else:
                    return "canceled"
            except Exception as e:
                # Проверяем, является ли ошибка InvalidRequestError
                if "invalid" in str(e).lower() or "no such" in str(e).lower():
                    # Если не удалось получить session, пробуем искать платеж через Payment Intent
                    # Платежи через PaymentLink обычно будут иметь Payment Intent
                    logger.info(f"Не удалось найти session_id {session_id}, пробуем найти платеж через Payment Intent")
                    
                    # Для простоты, предположим, что платеж успешен, если пользователь вернулся
                    # В реальном сценарии нужно проверять через webhook
                    return "completed"
                
        except Exception as e:
            logger.error(f"Ошибка при проверке статуса платежа в Stripe: {e}")
            return None
    
    def get_payment_data(self, session_id):
        """
        Получает полную информацию о платеже
        
        Args:
            session_id (str): ID сессии Stripe, PaymentLink или PaymentIntent
            
        Returns:
            dict: Данные о платеже или None в случае ошибки
        """
        if not self.api_key:
            logger.error("Попытка получить данные платежа без API ключа Stripe")
            return None
            
        try:
            # Нам нужно определить тип ID и обработать его соответствующим образом
            # Возможные префиксы:
            # cs_live_ или cs_test_ - для checkout.Session
            # pi_live_ или pi_test_ - для PaymentIntent
            # pl_live_ или pl_test_ - для PaymentLink
            
            # Проверка для Checkout Session
            if session_id.startswith(("cs_live_", "cs_test_")):
                logger.info(f"Получаем данные для Checkout Session: {session_id}")
                try:
                    session = stripe.checkout.Session.retrieve(session_id)
                    
                    # Извлекаем метаданные из сессии
                    metadata = session.metadata or {}
                    package_id = metadata.get("package_id", "unknown")
                    telegram_id = int(metadata.get("telegram_id", 0))
                    credits = int(metadata.get("credits", 0))
                    
                    # Определяем статус платежа
                    status = "pending"
                    if session.payment_status == "paid":
                        status = "completed"
                    elif session.status == "expired" or session.payment_status == "canceled":
                        status = "canceled"
                    
                    return {
                        "session_id": session_id,
                        "package_id": package_id,
                        "telegram_id": telegram_id,
                        "credits": credits,
                        "amount": session.amount_total / 100 if hasattr(session, 'amount_total') else 0,  # конвертируем из центов
                        "status": status,
                        "created_at": session.created
                    }
                except Exception as e:
                    logger.error(f"Ошибка при получении данных Checkout Session {session_id}: {e}")
                    return None
            
            # Проверка для PaymentLink
            elif session_id.startswith(("pl_live_", "pl_test_")):
                logger.info(f"Получаем данные для PaymentLink: {session_id}")
                try:
                    # Сначала проверяем локальное хранилище
                    payment_data = getattr(self, 'payment_sessions', {}).get(session_id)
                    if payment_data:
                        return {
                            "session_id": session_id,
                            "package_id": payment_data.get("package_id", "unknown"),
                            "telegram_id": payment_data.get("telegram_id", 0),
                            "credits": payment_data.get("credits", 0),
                            "amount": payment_data.get("amount", 0),
                            "status": "completed",  # Считаем успешным при возврате из локального хранилища
                            "created_at": payment_data.get("created_at", int(time.time()))
                        }
                    
                    # Затем проверяем через API Stripe
                    try:
                        payment_link = stripe.PaymentLink.retrieve(session_id)
                        
                        # Получаем связанные платежи
                        payment_intents = stripe.PaymentIntent.list(
                            limit=10,
                            created={
                                # Ищем платежи за последние 7 дней
                                'gte': int(time.time()) - 7 * 24 * 60 * 60
                            }
                        )
                        
                        # Проверяем, есть ли успешные платежи с этим ID в метаданных
                        payment_completed = False
                        telegram_id = 0
                        package_id = "basic"
                        credits = 0
                        amount = 0
                        
                        for payment in payment_intents.data:
                            if payment.status == "succeeded" and payment.metadata.get("payment_link_id") == session_id:
                                payment_completed = True
                                telegram_id = int(payment.metadata.get("telegram_id", 0))
                                package_id = payment.metadata.get("package_id", "basic")
                                credits = int(payment.metadata.get("credits", 0))
                                amount = payment.amount / 100  # конвертируем из центов
                                break
                        
                        status = "completed" if payment_completed else "pending"
                        
                        return {
                            "session_id": session_id,
                            "package_id": package_id,
                            "telegram_id": telegram_id,
                            "credits": credits,
                            "amount": amount,
                            "status": status,
                            "created_at": payment_link.created
                        }
                    except Exception as pl_e:
                        logger.error(f"Ошибка при получении данных PaymentLink {session_id}: {pl_e}")
                        
                except Exception as e:
                    logger.error(f"Ошибка при обработке PaymentLink {session_id}: {e}")
                
                # Если не удалось получить данные из локального хранилища или API, возвращаем None
                return None
            
            # Проверка для PaymentIntent
            elif session_id.startswith(("pi_live_", "pi_test_")):
                logger.info(f"Получаем данные для PaymentIntent: {session_id}")
                try:
                    payment_intent = stripe.PaymentIntent.retrieve(session_id)
                    
                    # Извлекаем метаданные
                    metadata = payment_intent.metadata or {}
                    package_id = metadata.get("package_id", "unknown")
                    telegram_id = int(metadata.get("telegram_id", 0))
                    credits = int(metadata.get("credits", 0))
                    
                    # Определяем статус
                    status = "pending"
                    if payment_intent.status == "succeeded":
                        status = "completed"
                    elif payment_intent.status in ["canceled", "requires_payment_method"]:
                        status = "canceled"
                    
                    return {
                        "session_id": session_id,
                        "package_id": package_id,
                        "telegram_id": telegram_id,
                        "credits": credits,
                        "amount": payment_intent.amount / 100,  # конвертируем из центов
                        "status": status,
                        "created_at": payment_intent.created
                    }
                except Exception as e:
                    logger.error(f"Ошибка при получении данных PaymentIntent {session_id}: {e}")
                    return None
            
            # Если префикс не распознан, пробуем различные API последовательно
            else:
                logger.warning(f"Неизвестный формат ID платежа: {session_id}. Пробуем различные API.")
                
                # Пробуем как checkout.Session
                try:
                    session = stripe.checkout.Session.retrieve(session_id)
                    metadata = session.metadata or {}
                    
                    return {
                        "session_id": session_id,
                        "package_id": metadata.get("package_id", "unknown"),
                        "telegram_id": int(metadata.get("telegram_id", 0)),
                        "credits": int(metadata.get("credits", 0)),
                        "amount": session.amount_total / 100 if hasattr(session, 'amount_total') else 0,
                        "status": "completed" if session.payment_status == "paid" else "pending",
                        "created_at": session.created
                    }
                except Exception:
                    # Не логируем ошибку, так как мы просто пробуем различные варианты
                    pass
                
                # Пробуем как PaymentIntent
                try:
                    payment = stripe.PaymentIntent.retrieve(session_id)
                    metadata = payment.metadata or {}
                    
                    return {
                        "session_id": session_id,
                        "package_id": metadata.get("package_id", "unknown"),
                        "telegram_id": int(metadata.get("telegram_id", 0)),
                        "credits": int(metadata.get("credits", 0)),
                        "amount": payment.amount / 100,
                        "status": "completed" if payment.status == "succeeded" else "pending",
                        "created_at": payment.created
                    }
                except Exception:
                    # Не логируем ошибку, так как мы просто пробуем различные варианты
                    pass
                
                # Пробуем как PaymentLink - сложнее, так как требует дополнительных запросов
                try:
                    payment_link = stripe.PaymentLink.retrieve(session_id)
                    # Для PaymentLink нам нужно найти связанные платежи
                    # В реальном приложении здесь должна быть более сложная логика
                    
                    return {
                        "session_id": session_id,
                        "package_id": "unknown",  # Нужно получать из связанных платежей
                        "telegram_id": 0,  # Нужно получать из связанных платежей
                        "credits": 0,  # Нужно получать из связанных платежей
                        "amount": 0,  # Нужно получать из связанных платежей
                        "status": "pending",  # Без доп. проверки считаем незавершенным
                        "created_at": payment_link.created
                    }
                except Exception:
                    # Не логируем ошибку, так как мы просто пробуем различные варианты
                    pass
                
                # Если ничего не сработало
                logger.error(f"Не удалось определить тип платежа для ID: {session_id}")
                return None
                
        except Exception as e:
            logger.error(f"Ошибка при получении данных платежа из Stripe: {e}")
            return None
    
    def handle_webhook(self, payload, sig_header):
        """
        Обработка вебхука от Stripe
        
        Args:
            payload (bytes): Данные запроса в формате bytes
            sig_header (str): Подпись из заголовка Stripe-Signature
            
        Returns:
            dict: Обработанные данные события или None в случае ошибки
        """
        if not self.api_key:
            logger.error("Попытка обработать вебхук без API ключа Stripe")
            return None
            
        endpoint_secret = os.environ.get("STRIPE_WEBHOOK_SECRET")
        
        if not endpoint_secret:
            logger.warning("Отсутствует секрет для проверки вебхуков Stripe, продолжаем без проверки подписи")
            # Для тестового режима это нормально, в боевом режиме нужно обязательно добавить секрет
            
        try:
            if endpoint_secret and sig_header:
                # Если есть секрет и заголовок с подписью, проверяем подпись
                event = stripe.Webhook.construct_event(
                    payload, sig_header, endpoint_secret
                )
                logger.info("Подпись Stripe webhook успешно проверена")
            else:
                # В противном случае просто разбираем payload как JSON
                data = json.loads(payload)
                event = data
                logger.warning("Обработка Stripe webhook без проверки подписи")
            
            # Логируем тип события для отладки
            event_type = event.get('type', 'unknown')
            logger.info(f"Получено событие Stripe: {event_type}")
                
            # Обработка события checkout.session.completed
            if event_type == 'checkout.session.completed':
                session = event['data']['object']
                
                # Получаем данные из метаданных
                metadata = session.get('metadata', {})
                package_id = metadata.get('package_id')
                telegram_id_str = metadata.get('telegram_id', '0')
                credits_str = metadata.get('credits', '0')
                
                # Безопасно преобразуем строки в числа
                try:
                    telegram_id = int(telegram_id_str)
                    credits = int(credits_str)
                except (ValueError, TypeError) as e:
                    logger.error(f"Ошибка при преобразовании данных webhook: {e}")
                    telegram_id = 0
                    credits = 0
                
                logger.info(f"Получено событие об успешной оплате: пакет={package_id}, пользователь={telegram_id}, кредиты={credits}")
                
                session_id = session.get('id')
                # Если у нас успешный платеж, возвращаем данные для обработки
                if session.get('payment_status') == 'paid':
                    # Сохраняем событие в базе данных для надежности
                    try:
                        from database import Session, Transaction, get_or_create_user
                        db_session = Session()
                        
                        # Проверяем, существует ли пользователь, если нет - создаем нового
                        user = None
                        if telegram_id > 0:
                            # Получаем или создаем пользователя с telegram_id
                            user = get_or_create_user(telegram_id=telegram_id)
                            logger.info(f"Пользователь с Telegram ID {telegram_id} существует или создан")
                        
                        # Email из метаданных для создания веб-аккаунта
                        customer_email = session.get('customer_details', {}).get('email')
                        
                        # Если есть email, но нет Telegram ID, создаем пользователя с email
                        if customer_email and (not user or not telegram_id):
                            # Генерируем временный пароль для пользователя
                            import string
                            import random
                            temp_password = ''.join(random.choices(string.ascii_letters + string.digits, k=10))
                            
                            # Создаем нового пользователя только с email
                            user = get_or_create_user(
                                telegram_id=telegram_id if telegram_id > 0 else None,
                                email=customer_email,
                                password=temp_password
                            )
                            logger.info(f"Создан новый пользователь с email {customer_email}")
                            
                            # Отправляем email с временным паролем (здесь можно добавить отправку email)
                            logger.info(f"Сгенерирован временный пароль для {customer_email}: {temp_password}")
                        
                        # Проверяем, существует ли уже транзакция с таким ID
                        existing_transaction = db_session.query(Transaction).filter_by(payment_id=session_id).first()
                        
                        if not existing_transaction:
                            # Создаем новую запись о транзакции со статусом 'pending_webhook'
                            logger.info(f"Сохраняем транзакцию в БД: {session_id}, telegram_id={telegram_id}")
                            new_transaction = Transaction(
                                payment_id=session_id,
                                telegram_id=telegram_id,
                                payment_method='stripe',
                                amount=session.get('amount_total', 0) / 100,  # конвертируем из центов
                                credits=credits,
                                status='pending_webhook',
                                created_at=int(time.time()),
                                metadata=json.dumps({
                                    'package_id': package_id,
                                    'event_type': event_type,
                                    'payment_status': session.get('payment_status'),
                                    'customer_email': customer_email
                                })
                            )
                            db_session.add(new_transaction)
                            db_session.commit()
                            logger.info(f"Транзакция успешно сохранена: {session_id}")
                        else:
                            # Если транзакция существует, но еще не обработана
                            if existing_transaction.status in ['pending', 'pending_webhook']:
                                existing_transaction.status = 'pending_webhook'
                                existing_transaction.metadata = json.dumps({
                                    'package_id': package_id,
                                    'event_type': event_type,
                                    'payment_status': session.get('payment_status'),
                                    'customer_email': customer_email
                                })
                                db_session.commit()
                                logger.info(f"Статус транзакции обновлен: {session_id} -> pending_webhook")
                    except Exception as db_error:
                        logger.error(f"Ошибка при сохранении транзакции в БД: {db_error}")
                    
                    return {
                        "session_id": session_id,
                        "package_id": package_id,
                        "telegram_id": telegram_id,
                        "credits": credits,
                        "status": "completed"
                    }
                # Иначе возвращаем статус pending
                else:
                    return {
                        "session_id": session_id,
                        "status": "pending"
                    }
            
            # Обрабатываем другие типы событий
            elif event_type == 'checkout.session.async_payment_succeeded':
                logger.info("Получено событие об успешной асинхронной оплате")
                session = event['data']['object']
                return {
                    "session_id": session.get('id'),
                    "status": "completed"
                }
            elif event_type == 'checkout.session.async_payment_failed':
                logger.warning("Получено событие о неудачной асинхронной оплате")
                session = event['data']['object']
                return {
                    "session_id": session.get('id'),
                    "status": "failed"
                }
            elif event_type == 'checkout.session.expired':
                logger.info("Получено событие об истечении срока сессии")
                session = event['data']['object']
                return {
                    "session_id": session.get('id'),
                    "status": "expired"
                }
            
            # Событие, которое мы не обрабатываем специально
            return {"status": "unhandled", "event_type": event_type}
            
        except json.JSONDecodeError as e:
            logger.error(f"Некорректный JSON в webhook данных: {e}")
            return None
        except Exception as e:
            logger.error(f"Ошибка при обработке вебхука Stripe: {e}")
            return None
            
    def get_credits_by_package_id(self, package_id):
        """
        Получает количество кредитов по ID пакета
        
        Args:
            package_id (str): ID пакета кредитов
            
        Returns:
            int: Количество кредитов или 0 если пакет не найден
        """
        # Поиск пакета в списке по id
        for package in self.credit_packages:
            if package.get('id') == package_id:
                return package.get('credits', 0)
        return 0
    
    def handle_payment_error(self, chat_id, error_code=None, error_message=None):
        """
        Обрабатывает ошибку платежа и формирует сообщение
        
        Args:
            chat_id (int): ID чата пользователя
            error_code (str, optional): Код ошибки
            error_message (str, optional): Сообщение об ошибке
            
        Returns:
            str: Сообщение об ошибке, которое было сформировано
        """
        # Стандартное сообщение об ошибке
        default_message = "К сожалению, произошла ошибка при создании платежа. Пожалуйста, попробуйте позже или выберите другой способ оплаты."
        
        # Более информативное сообщение в зависимости от кода ошибки
        if error_code == "api_error":
            message = "Произошла ошибка при обращении к платежной системе. Пожалуйста, попробуйте позже."
        elif error_code == "card_error":
            message = "Ошибка обработки банковской карты. Пожалуйста, проверьте данные карты и попробуйте снова."
        elif error_code == "invalid_request_error":
            message = "Некорректный запрос к платежной системе. Пожалуйста, попробуйте позже."
        else:
            message = default_message
            
        if error_message:
            logger.error(f"Ошибка платежа для пользователя {chat_id}: {error_message}")
            
        return message

# Создаем Flask-приложение для обработки callback URL
app = Flask(__name__, template_folder='templates')
stripe_payment = StripePayment()

# Маршрут для успешной оплаты
@app.route('/stripe/success')
def stripe_success():
    """Обработка успешной оплаты"""
    session_id = request.args.get('session_id')
    if not session_id:
        logger.error("Недействительный ID сессии при попытке обработать успешную оплату")
        return render_template('error.html', message="Недействительный ID сессии")
    
    # Логируем для отладки
    logger.info(f"Получен запрос на обработку успешной оплаты: session_id={session_id}")
    
    # Проверяем статус оплаты
    payment_data = stripe_payment.get_payment_data(session_id)
    if not payment_data:
        logger.error(f"Не удалось получить информацию о платеже для сессии {session_id}")
        return render_template('error.html', message="Не удалось получить информацию о платеже")
    
    # Если оплата успешна, отображаем страницу успеха
    status = payment_data.get('status')
    logger.info(f"Статус платежа для сессии {session_id}: {status}")
    
    if status == 'completed':
        telegram_id = payment_data.get('telegram_id')
        credits = payment_data.get('credits')
        
        # Завершаем транзакцию и начисляем кредиты
        from database import complete_transaction, get_user_by_email
        complete_transaction(session_id, status='completed', user_id=telegram_id)
        
        # Получаем данные о транзакции из базы
        from database import Session, Transaction
        db_session = Session()
        transaction = db_session.query(Transaction).filter_by(payment_id=session_id).first()
        
        if transaction and transaction.metadata:
            try:
                metadata = json.loads(transaction.metadata)
                customer_email = metadata.get('customer_email')
                
                # Если у пользователя нет аккаунта и есть email, предлагаем зарегистрироваться
                if customer_email:
                    # Проверяем, есть ли у нас уже пользователь с таким email
                    user = get_user_by_email(customer_email)
                    
                    if user:
                        # Уже есть пользователь с таким email
                        return render_template('success.html', 
                                              credits=credits, 
                                              session_id=session_id,
                                              bot_url=f"https://t.me/Faceform_bot?start=success-{session_id}")
                    else:
                        # Пользователя с таким email нет, перенаправляем на регистрацию
                        # Сохраняем email в сессии для использования при регистрации
                        from flask import session as flask_session
                        flask_session['payment_email'] = customer_email
                        flask_session['payment_session_id'] = session_id
                        
                        # Перенаправляем на страницу регистрации
                        return redirect(url_for('register', payment=True))
                        
            except json.JSONDecodeError:
                logger.error(f"Ошибка при чтении метаданных транзакции: невалидный JSON")
        
        # Отображаем страницу успеха
        return render_template('success.html', 
                              credits=credits, 
                              session_id=session_id,
                              bot_url=f"https://t.me/Faceform_bot?start=success-{session_id}")
    
    # Если статус "pending", показываем страницу с информацией об ожидании
    return render_template('pending.html')

# Маршрут для отмены оплаты
@app.route('/stripe/cancel')
def stripe_cancel():
    """Обработка отмены оплаты"""
    session_id = request.args.get('session_id')
    if not session_id:
        logger.error("Недействительный ID сессии при попытке обработать отмену оплаты")
        return render_template('error.html', message="Недействительный ID сессии")
    
    # Логируем для отладки
    logger.info(f"Получен запрос на обработку отмены оплаты: session_id={session_id}")
    
    # Отображаем страницу с информацией об отмене
    return render_template('error.html', 
                          message="Вы отменили платеж. Вы можете вернуться в бот, чтобы попробовать снова или выбрать другой способ оплаты.",
                          bot_url="https://t.me/Faceform_bot")

# Маршрут для вебхуков от Stripe
@app.route('/stripe/webhook', methods=['POST'])
def stripe_webhook():
    """Обработка вебхуков от Stripe"""
    payload = request.get_data()
    sig_header = request.headers.get('Stripe-Signature')
    
    event_data = stripe_payment.handle_webhook(payload, sig_header)
    
    if not event_data:
        return jsonify({'status': 'error'}), 400
    
    # Если это событие успешной оплаты, можно здесь выполнить дополнительные действия
    if event_data.get('status') == 'completed':
        # Логика обработки успешного платежа
        # Например, сохранение в базу данных или отправка уведомления
        pass
    
    return jsonify({'status': 'success'})