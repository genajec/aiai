#!/usr/bin/env python3
# -*- coding: utf-8 -*-

import os
import requests
import logging
import sys
import time
from PIL import Image
import io

# Настройка логирования
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(name)s - %(levelname)s - %(message)s')
logger = logging.getLogger(__name__)

def upload_image(api_key, image_data):
    """
    Загружает изображение на сервер LightX
    
    Args:
        api_key (str): API ключ
        image_data (bytes): Данные изображения
    
    Returns:
        str: URL загруженного изображения или None в случае ошибки
    """
    try:
        # Шаг 1: Получение URL для загрузки
        upload_url = "https://api.lightxeditor.com/external/api/v2/uploadImageUrl"
        
        headers = {
            "Content-Type": "application/json",
            "x-api-key": api_key
        }
        
        data = {
            "uploadType": "imageUrl",
            "size": len(image_data),
            "contentType": "image/jpeg"
        }
        
        logger.info("Запрос URL для загрузки изображения...")
        response = requests.post(upload_url, headers=headers, json=data)
        
        if response.status_code != 200:
            logger.error(f"Ошибка при запросе URL: {response.status_code} - {response.text}")
            return None
        
        result = response.json()
        logger.info(f"Получен ответ: {result}")
        
        if result.get("statusCode") != 2000 or "body" not in result:
            logger.error(f"Некорректный ответ API: {result}")
            return None
        
        upload_image_url = result["body"].get("uploadImage")
        image_url = result["body"].get("imageUrl")
        
        if not upload_image_url or not image_url:
            logger.error("Отсутствуют необходимые URL в ответе")
            return None
        
        logger.info(f"Получен URL для загрузки: {upload_image_url}")
        logger.info(f"Получен URL изображения: {image_url}")
        
        # Шаг 2: Загрузка самого изображения
        logger.info("Загрузка изображения...")
        upload_headers = {"Content-Type": "image/jpeg"}
        upload_response = requests.put(upload_image_url, headers=upload_headers, data=image_data)
        
        if upload_response.status_code != 200:
            logger.error(f"Ошибка при загрузке изображения: {upload_response.status_code}")
            return None
        
        logger.info(f"Изображение успешно загружено. URL: {image_url}")
        return image_url
        
    except Exception as e:
        logger.error(f"Ошибка при загрузке изображения: {e}")
        return None

def remove_background(api_key, image_url, bg_color="#FFFFFF"):
    """
    Удаляет фон изображения и заменяет его на указанный цвет
    
    Args:
        api_key (str): API ключ
        image_url (str): URL изображения
        bg_color (str): Цвет фона в HEX формате
    
    Returns:
        str: URL изображения с удаленным фоном или None в случае ошибки
    """
    try:
        logger.info(f"Запрос на удаление фона с заменой на цвет: {bg_color}")
        
        url = 'https://api.lightxeditor.com/external/api/v1/remove-background'
        
        headers = {
            'Content-Type': 'application/json',
            'x-api-key': api_key
        }
        
        data = {
            "imageUrl": image_url,
            "background": bg_color  # Используем белый цвет фона как стандартный
        }
        
        logger.info(f"Заголовки: {headers}")
        logger.info(f"Данные запроса: {data}")
        
        response = requests.post(url, headers=headers, json=data)
        
        logger.info(f"Получен ответ со статусом: {response.status_code}")
        logger.info(f"Текст ответа: {response.text}")
        
        if response.status_code != 200:
            logger.error(f"Ошибка при запросе удаления фона: {response.status_code} - {response.text}")
            return None
        
        result = response.json()
        
        if result.get("statusCode") != 2000 or "body" not in result:
            logger.error(f"Некорректный ответ API: {result}")
            return None
        
        order_id = result["body"].get("orderId")
        
        if not order_id:
            logger.error("Отсутствует ID заказа в ответе")
            return None
        
        logger.info(f"Получен ID заказа: {order_id}")
        
        # Ожидание выполнения заказа
        max_attempts = 20
        wait_time = 3  # секунды между проверками
        
        for attempt in range(max_attempts):
            logger.info(f"Проверка статуса заказа, попытка {attempt+1}/{max_attempts}")
            time.sleep(wait_time)
            
            status_url = "https://api.lightxeditor.com/external/api/v1/order-status"
            status_data = {"orderId": order_id}
            
            status_response = requests.post(status_url, headers=headers, json=status_data)
            
            if status_response.status_code != 200:
                logger.warning(f"Ошибка при проверке статуса: {status_response.status_code} - {status_response.text}")
                continue
            
            status_result = status_response.json()
            
            if status_result.get("statusCode") != 2000 or "body" not in status_result:
                logger.warning(f"Некорректный ответ API статуса: {status_result}")
                continue
            
            status = status_result["body"].get("status")
            output_url = status_result["body"].get("output")
            
            logger.info(f"Статус заказа: {status}, URL результата: {output_url or 'не готов'}")
            
            if status == "active" and output_url:
                logger.info(f"Обработка завершена успешно. URL результата: {output_url}")
                return output_url
            
            elif status == "failed":
                logger.error("Заказ завершился ошибкой")
                return None
        
        logger.error(f"Превышено максимальное количество попыток ({max_attempts})")
        return None
        
    except Exception as e:
        logger.error(f"Ошибка при удалении фона: {e}")
        return None

def download_result(output_url):
    """
    Загружает результат по указанному URL
    
    Args:
        output_url (str): URL с результатом
    
    Returns:
        bytes: Данные изображения или None в случае ошибки
    """
    try:
        logger.info(f"Загрузка результата с URL: {output_url}")
        
        response = requests.get(output_url)
        
        if response.status_code != 200:
            logger.error(f"Ошибка при загрузке результата: {response.status_code}")
            return None
        
        logger.info(f"Результат успешно загружен, размер: {len(response.content)} байт")
        return response.content
        
    except Exception as e:
        logger.error(f"Ошибка при загрузке результата: {e}")
        return None

def create_office_background(width, height, color="white"):
    """
    Создает простой фон офиса
    
    Args:
        width (int): Ширина изображения
        height (int): Высота изображения
        color (str): Цвет фона
        
    Returns:
        PIL.Image: Изображение с фоном офиса
    """
    try:
        from PIL import Image, ImageDraw, ImageFont
        
        # Создаем пустое изображение
        bg = Image.new('RGB', (width, height), color=color)
        draw = ImageDraw.Draw(bg)
        
        # Рисуем простой офисный фон
        # Линия горизонта (пол и стена)
        horizon_y = height * 0.7
        draw.rectangle([(0, horizon_y), (width, height)], fill="#EEE9E3")  # Пол
        
        # Рисуем окна
        window_width = width * 0.2
        window_height = height * 0.4
        window_x1 = width * 0.1
        window_x2 = width * 0.7
        window_y = height * 0.3
        
        # Окно 1
        draw.rectangle([(window_x1, window_y - window_height/2), 
                        (window_x1 + window_width, window_y + window_height/2)], 
                        fill="#A1CAF8")
        
        # Окно 2
        draw.rectangle([(window_x2, window_y - window_height/2), 
                        (window_x2 + window_width, window_y + window_height/2)], 
                        fill="#A1CAF8")
        
        # Рисуем стол
        desk_width = width * 0.6
        desk_height = height * 0.1
        desk_x = (width - desk_width) / 2
        desk_y = horizon_y - desk_height
        
        draw.rectangle([(desk_x, desk_y), 
                        (desk_x + desk_width, desk_y + desk_height)], 
                        fill="#B4916D")
        
        return bg
        
    except Exception as e:
        logger.error(f"Ошибка при создании фона: {e}")
        return None

def composite_images(foreground_bytes, background_img):
    """
    Накладывает передний план на фон
    
    Args:
        foreground_bytes (bytes): Данные изображения переднего плана (с прозрачным фоном)
        background_img (PIL.Image): Изображение фона
        
    Returns:
        bytes: Данные изображения с наложенным передним планом
    """
    try:
        # Загружаем передний план
        foreground = Image.open(io.BytesIO(foreground_bytes)).convert("RGBA")
        
        # Изменяем размер фона до размера переднего плана
        background = background_img.resize((foreground.width, foreground.height))
        background = background.convert("RGBA")
        
        # Накладываем изображения
        composite = Image.alpha_composite(background, foreground)
        
        # Конвертируем в байты
        output = io.BytesIO()
        composite.convert("RGB").save(output, format="JPEG")
        output.seek(0)
        
        return output.getvalue()
        
    except Exception as e:
        logger.error(f"Ошибка при наложении изображений: {e}")
        return None

def main():
    # Проверка API ключа
    api_key = os.environ.get("LIGHTX_API_KEY")
    if not api_key:
        logger.error("API ключ LIGHTX_API_KEY не найден в переменных окружения")
        return
    
    # Проверка аргументов командной строки
    if len(sys.argv) < 2:
        logger.error("Использование: python background_fallback.py <путь_к_изображению> [описание_фона]")
        return
    
    image_path = sys.argv[1]
    background_prompt = "Modern office" if len(sys.argv) < 3 else sys.argv[2]
    
    logger.info(f"Тестирование альтернативного подхода для смены фона")
    logger.info(f"Изображение: {image_path}")
    logger.info(f"Описание фона: '{background_prompt}'")
    
    # Чтение изображения
    try:
        with open(image_path, "rb") as f:
            image_data = f.read()
        logger.info(f"Изображение успешно прочитано, размер: {len(image_data)} байт")
    except Exception as e:
        logger.error(f"Ошибка при чтении изображения: {e}")
        return
    
    # Загрузка изображения
    image_url = upload_image(api_key, image_data)
    if not image_url:
        logger.error("Не удалось загрузить изображение")
        return
    
    # Удаление фона
    output_url = remove_background(api_key, image_url)
    if not output_url:
        logger.error("Не удалось удалить фон")
        return
    
    # Загрузка результата
    foreground_data = download_result(output_url)
    if not foreground_data:
        logger.error("Не удалось загрузить результат")
        return
    
    # Создание фона
    img = Image.open(io.BytesIO(image_data))
    width, height = img.size
    background_img = create_office_background(width, height)
    if not background_img:
        logger.error("Не удалось создать фон")
        return
    
    # Композиция изображений
    result_data = composite_images(foreground_data, background_img)
    if not result_data:
        logger.error("Не удалось создать композицию")
        return
    
    # Сохранение результата
    output_path = "fallback_bg_changed.jpg"
    try:
        with open(output_path, "wb") as f:
            f.write(result_data)
        logger.info(f"Результат успешно сохранен в файл: {output_path}")
    except Exception as e:
        logger.error(f"Ошибка при сохранении результата: {e}")
        return

if __name__ == "__main__":
    main()