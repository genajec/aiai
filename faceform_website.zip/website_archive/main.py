import os
import stripe
import json
import logging
from flask import render_template, request, redirect, url_for, flash, session, jsonify
from flask_login import LoginManager, login_required, current_user, login_user, logout_user
import cv2
import numpy as np
from werkzeug.utils import secure_filename
import uuid
import base64

# Импортируем объект app из app.py
from app import app, db, logger

# Устанавливаем секретный ключ приложения для сессий
app.secret_key = os.environ.get("SESSION_SECRET") or "faceshapebot_secret_key_2025"

# Импортируем модели
from models import User, Package, Order, Feature, ServicePrice

# Настраиваем Stripe
stripe.api_key = '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'
os.environ['STRIPE_SECRET_KEY'] = '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'
os.environ['STRIPE_PUBLISHABLE_KEY'] = 'pk_live_51RFWPbIXP9qWqMx9mFcESigNDB705oZNH8glzwdnzxkxHoBINjgfXZHfNJrJQMuDLEyCnP1jtO1YVLdUSKEyKTzs00DP5wzGaS'

# Домен для URL-адресов Stripe
YOUR_DOMAIN = os.environ.get('REPLIT_DEV_DOMAIN', 'localhost:5000')

# Инициализируем Flask-Login
login_manager = LoginManager()
login_manager.init_app(app)
login_manager.login_view = 'login'

@login_manager.user_loader
def load_user(user_id):
    return User.query.get(int(user_id))

# Создаем необходимые таблицы в базе данных
with app.app_context():
    db.create_all()

@app.route('/')
def index():
    """Главная страница сайта"""
    return render_template('index.html')

@app.route('/about')
def about():
    """Страница о сервисе"""
    return render_template('about.html')

@app.route('/services')
def services():
    """Страница с описанием услуг"""
    return render_template('services.html')

@app.route('/pricing')
def pricing():
    """Страница с ценами и пакетами кредитов"""
    # Получаем все доступные пакеты из базы данных
    packages = Package.query.all()
    return render_template('pricing.html', packages=packages)

@app.route('/create-checkout-session/<int:package_id>', methods=['POST'])
def create_checkout_session(package_id):
    """Создание сессии оплаты Stripe для выбранного пакета"""
    try:
        # Получаем пакет из базы данных
        package = Package.query.get_or_404(package_id)
        
        # Создаем сессию Stripe Checkout
        checkout_session = stripe.checkout.Session.create(
            line_items=[
                {
                    'price_data': {
                        'currency': 'usd',
                        'product_data': {
                            'name': f"Credit Package: {package.name}" if session.get('language') == 'en' else f"Пакет кредитов: {package.name}",
                            'description': f"{package.credits} credits for FaceForm Bot" if session.get('language') == 'en' else f"{package.credits} кредитов для FaceForm Bot",
                        },
                        'unit_amount': int(package.price * 100),  # Цена в центах
                    },
                    'quantity': 1,
                },
            ],
            mode='payment',
            success_url=f'https://{YOUR_DOMAIN}/success?session_id={{CHECKOUT_SESSION_ID}}',
            cancel_url=f'https://{YOUR_DOMAIN}/cancel',
            metadata={
                'package_id': package_id,
            },
        )
        
        # Сохраняем информацию о заказе в базе данных
        user_id = session.get('user_id')
        order = Order(
            session_id=checkout_session.id,
            package_id=package_id,
            user_id=user_id if user_id else None,
            amount=package.price,
            status='pending'
        )
        db.session.add(order)
        db.session.commit()
        
        # Редирект на страницу оплаты Stripe
        return redirect(checkout_session.url, code=303)
    except Exception as e:
        logger.error(f"Ошибка при создании сессии Stripe: {str(e)}")
        flash('Произошла ошибка при создании сессии оплаты. Пожалуйста, попробуйте позже.', 'error')
        return redirect(url_for('pricing'))

@app.route('/success')
def success():
    """Страница успешной оплаты"""
    session_id = request.args.get('session_id')
    
    if not session_id:
        flash('Ошибка: Идентификатор сессии не найден', 'error')
        return redirect(url_for('index'))
    
    try:
        # Получаем данные сессии из Stripe
        checkout_session = stripe.checkout.Session.retrieve(session_id)
        
        # Обновляем статус заказа в базе данных
        order = Order.query.filter_by(session_id=session_id).first()
        if order:
            order.status = 'completed'
            db.session.commit()
        
        return render_template('success.html', session_id=session_id)
    except Exception as e:
        logger.error(f"Ошибка при обработке успешного платежа: {str(e)}")
        flash('Произошла ошибка при обработке платежа', 'error')
        return redirect(url_for('index'))

@app.route('/cancel')
def cancel():
    """Страница отмены оплаты"""
    return render_template('cancel.html')

@app.route('/webhook', methods=['POST'])
def webhook():
    """Обработчик вебхуков от Stripe"""
    payload = request.get_data(as_text=True)
    sig_header = request.headers.get('Stripe-Signature')
    endpoint_secret = os.environ.get('STRIPE_WEBHOOK_SECRET')
    
    try:
        if endpoint_secret:
            event = stripe.Webhook.construct_event(
                payload, sig_header, endpoint_secret
            )
        else:
            data = json.loads(payload)
            event = stripe.Event.construct_from(data, stripe.api_key)
        
        # Обработка событий платежей
        if event['type'] == 'checkout.session.completed':
            session = event['data']['object']
            
            # Обновляем статус заказа
            order = Order.query.filter_by(session_id=session.id).first()
            if order:
                order.status = 'completed'
                db.session.commit()
                
                logger.info(f"Платеж успешно обработан: {session.id}")
        
        return jsonify(success=True)
    except Exception as e:
        logger.error(f"Ошибка обработки вебхука: {str(e)}")
        return jsonify(success=False, error=str(e)), 400

@app.route('/contact')
def contact():
    """Страница контактов"""
    return render_template('contact.html')

@app.route('/download')
def download():
    """Страница для скачивания бота"""
    return render_template('download.html')

# Создаем директорию для загруженных изображений
UPLOAD_FOLDER = 'static/uploads'
if not os.path.exists(UPLOAD_FOLDER):
    os.makedirs(UPLOAD_FOLDER)
app.config['UPLOAD_FOLDER'] = UPLOAD_FOLDER
app.config['MAX_CONTENT_LENGTH'] = 16 * 1024 * 1024  # Максимальный размер файла (16MB)

@app.route('/set-language/<lang>', methods=['GET', 'POST'])
def set_language(lang):
    """Установка языка интерфейса"""
    if lang not in ['ru', 'en']:
        lang = 'ru'  # По умолчанию русский
    
    # Сохраняем выбранный язык в сессии
    session['language'] = lang
    
    # Перенаправляем пользователя обратно на страницу, с которой он пришел
    # или на главную, если информация о предыдущей странице недоступна
    next_page = request.args.get('next') or request.referrer or url_for('index')
    return redirect(next_page)

@app.route('/en')
def index_en():
    """Английская версия главной страницы"""
    session['language'] = 'en'
    return render_template('index_en.html')

@app.route('/try-on', methods=['GET', 'POST'])
def try_on():
    """Страница для виртуальной примерки причесок"""
    if request.method == 'POST':
        # Проверяем, есть ли файл в запросе
        if 'photo' not in request.files:
            flash('No file part', 'error')
            return redirect(request.url)
        
        file = request.files['photo']
        
        # Если пользователь не выбрал файл
        if file.filename == '':
            flash('No selected file', 'error')
            return redirect(request.url)
        
        if file:
            # Генерируем безопасное имя файла с уникальным идентификатором
            filename = secure_filename(file.filename)
            unique_filename = f"{uuid.uuid4()}_{filename}"
            filepath = os.path.join(app.config['UPLOAD_FOLDER'], unique_filename)
            
            # Сохраняем файл
            file.save(filepath)
            
            # Выбор прически (в данном случае, просто демонстрация)
            hairstyle_id = request.form.get('hairstyle_id', '1')
            
            # Примерка прически (имитация)
            try:
                result_image_path = apply_virtual_hairstyle(filepath, hairstyle_id)
                
                # Сохраняем результат в сессии
                session['result_image'] = result_image_path
                session['original_image'] = filepath
                
                return redirect(url_for('try_on_result'))
            except Exception as e:
                logger.error(f"Ошибка при применении прически: {str(e)}")
                flash('Ошибка при обработке изображения', 'error')
                return redirect(request.url)
    
    # Получаем доступные прически
    hairstyles = [
        {'id': '1', 'name': 'Классическая стрижка', 'name_en': 'Classic Haircut', 'image': 'static/img/hairstyles/classic.jpg'},
        {'id': '2', 'name': 'Боб', 'name_en': 'Bob', 'image': 'static/img/hairstyles/bob.jpg'},
        {'id': '3', 'name': 'Длинные волосы', 'name_en': 'Long Hair', 'image': 'static/img/hairstyles/long.jpg'},
        {'id': '4', 'name': 'Кудри', 'name_en': 'Curly', 'image': 'static/img/hairstyles/curly.jpg'},
    ]
    
    language = session.get('language', 'ru')
    return render_template('try_on.html', hairstyles=hairstyles, language=language)

@app.route('/try-on/result')
def try_on_result():
    """Страница с результатом виртуальной примерки"""
    result_image = session.get('result_image')
    original_image = session.get('original_image')
    
    if not result_image:
        flash('Результат не найден', 'error')
        return redirect(url_for('try_on'))
    
    language = session.get('language', 'ru')
    return render_template('try_on_result.html', 
                          result_image=result_image, 
                          original_image=original_image,
                          language=language)

def apply_virtual_hairstyle(image_path, hairstyle_id):
    """
    Применяет виртуальную прическу к изображению
    
    Args:
        image_path (str): Путь к загруженному изображению
        hairstyle_id (str): ID выбранной прически
        
    Returns:
        str: Путь к обработанному изображению
    """
    try:
        # Загружаем изображение
        image = cv2.imread(image_path)
        if image is None:
            raise ValueError("Не удалось загрузить изображение")
        
        # Преобразуем в RGB (OpenCV использует BGR)
        image = cv2.cvtColor(image, cv2.COLOR_BGR2RGB)
        
        # Находим лицо с помощью каскадов Хаара
        face_cascade = cv2.CascadeClassifier(cv2.data.haarcascades + 'haarcascade_frontalface_default.xml')
        gray = cv2.cvtColor(image, cv2.COLOR_RGB2GRAY)
        faces = face_cascade.detectMultiScale(gray, 1.3, 5)
        
        if len(faces) == 0:
            raise ValueError("Лицо не обнаружено на изображении")
        
        # Берем наибольшее лицо
        (x, y, w, h) = sorted(faces, key=lambda x: x[2] * x[3], reverse=True)[0]
        
        # Определяем цвет прически на основе ID
        hairstyle_colors = {
            '1': (139, 69, 19),  # коричневый
            '2': (0, 0, 0),      # черный
            '3': (218, 165, 32), # золотой
            '4': (139, 0, 0)     # темно-красный
        }
        color = hairstyle_colors.get(hairstyle_id, (0, 0, 0))
        
        # Рисуем прическу (упрощенная демонстрация)
        # Это просто схематичное изображение для демонстрации функциональности
        hair_y = max(0, y - int(h * 0.4))
        hair_h = int(h * 0.8)
        hair_w = int(w * 1.2)
        hair_x = max(0, x - int((hair_w - w) / 2))
        
        # Создаем маску для волос
        hair_mask = np.zeros_like(image)
        
        if hairstyle_id == '1':  # Классическая стрижка
            # Короткие волосы - рисуем по форме головы
            cv2.ellipse(hair_mask, (x + w//2, y), (w//2 + 10, h//2), 0, 0, 180, color, -1)
        elif hairstyle_id == '2':  # Боб
            # Градуированный боб
            cv2.rectangle(hair_mask, (hair_x, hair_y), (hair_x + hair_w, y + h//3), color, -1)
            pts = np.array([[hair_x, y + h//3], 
                            [hair_x + hair_w, y + h//3], 
                            [hair_x + hair_w - 20, y + h//2], 
                            [hair_x + 20, y + h//2]], np.int32)
            cv2.fillPoly(hair_mask, [pts], color)
        elif hairstyle_id == '3':  # Длинные волосы
            # Длинные прямые волосы
            hair_h = int(h * 1.5)
            cv2.rectangle(hair_mask, (hair_x, hair_y), (hair_x + hair_w, y + hair_h), color, -1)
        elif hairstyle_id == '4':  # Кудри
            # Кудрявые волосы
            for i in range(20):
                cx = hair_x + np.random.randint(0, hair_w)
                cy = hair_y + np.random.randint(0, h)
                cv2.circle(hair_mask, (cx, cy), np.random.randint(5, 15), color, -1)
            cv2.rectangle(hair_mask, (hair_x, hair_y), (hair_x + hair_w, y + int(h * 0.8)), color, -1)
        
        # Накладываем волосы на исходное изображение с альфа-смешиванием
        alpha = 0.7
        mask_area = (hair_mask > 0)
        image[mask_area] = cv2.addWeighted(image[mask_area], 1 - alpha, hair_mask[mask_area], alpha, 0)
        
        # Преобразуем обратно в BGR для сохранения
        image = cv2.cvtColor(image, cv2.COLOR_RGB2BGR)
        
        # Сохраняем результат
        result_path = os.path.join(app.config['UPLOAD_FOLDER'], f"result_{os.path.basename(image_path)}")
        cv2.imwrite(result_path, image)
        
        return result_path
    
    except Exception as e:
        logger.error(f"Ошибка при обработке изображения: {str(e)}")
        raise

# Глобальная функция для определения текущего языка
@app.context_processor
def inject_language():
    """Добавляет переменную language во все шаблоны"""
    language = session.get('language', 'ru')
    return dict(language=language)

# Запуск приложения
if __name__ == '__main__':
    app.run(host='0.0.0.0', port=5000, debug=True)