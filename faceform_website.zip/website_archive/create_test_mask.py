import os
import cv2
import numpy as np
from PIL import Image, ImageDraw
import io
import logging

# Configure logging
logging.basicConfig(level=logging.INFO, 
                   format='%(asctime)s - %(name)s - %(levelname)s - %(message)s')
logger = logging.getLogger(__name__)

def create_simple_mask(image_path, mask_path, mask_area='center'):
    """
    Создает простую маску для тестирования API Replace
    
    Args:
        image_path (str): Путь к исходному изображению
        mask_path (str): Путь для сохранения маски
        mask_area (str): Область маски ('center', 'background', 'all')
    
    Returns:
        bool: True если успешно, False если ошибка
    """
    try:
        # Загрузка изображения с помощью OpenCV
        image = cv2.imread(image_path)
        if image is None:
            logger.error(f"Не удалось загрузить изображение: {image_path}")
            return False
            
        # Получение размеров изображения
        height, width = image.shape[:2]
        logger.info(f"Размер изображения: {width}x{height}")
        
        # Создание пустой маски (черное изображение)
        mask = np.zeros((height, width), dtype=np.uint8)
        
        # Заполнение маски в зависимости от выбранной области
        if mask_area == 'center':
            # Создаем белый прямоугольник в центре изображения (30% от размеров)
            center_x, center_y = width // 2, height // 2
            rect_width, rect_height = int(width * 0.3), int(height * 0.3)
            x1, y1 = center_x - rect_width // 2, center_y - rect_height // 2
            x2, y2 = center_x + rect_width // 2, center_y + rect_height // 2
            
            # Рисуем белый прямоугольник на маске
            cv2.rectangle(mask, (x1, y1), (x2, y2), 255, -1)
            logger.info(f"Создана маска с белым прямоугольником в центре: ({x1},{y1}) - ({x2},{y2})")
            
        elif mask_area == 'background':
            # Создаем простую маску фона: белый внешний периметр, черная центральная часть
            margin = int(min(width, height) * 0.2)  # 20% отступ от края
            
            # Заполняем весь фон белым
            mask.fill(255)
            
            # Рисуем черный прямоугольник в центре
            cv2.rectangle(mask, (margin, margin), (width - margin, height - margin), 0, -1)
            logger.info(f"Создана маска с белой границей и черным центром")
            
        elif mask_area == 'all':
            # Вся маска белая (для замены всего изображения)
            mask.fill(255)
            logger.info("Создана полностью белая маска")
        
        # Сохранение маски
        cv2.imwrite(mask_path, mask)
        logger.info(f"Маска сохранена в файл: {mask_path}")
        
        return True
        
    except Exception as e:
        logger.error(f"Ошибка при создании маски: {e}")
        return False

if __name__ == "__main__":
    # Тестовое изображение
    test_images = [
        os.path.join(".", "demo_base_face.jpg"),
        os.path.join(".", "test_hairstyle_result.jpg"),
        os.path.join(".", "vis_IMG_6834.png")
    ]
    
    # Находим первое доступное изображение
    image_path = None
    for test_path in test_images:
        if os.path.exists(test_path):
            image_path = test_path
            logger.info(f"Используем тестовое изображение: {image_path}")
            break
    
    if not image_path:
        logger.error("Не найдено ни одно тестовое изображение")
        exit(1)
    
    # Создаем несколько типов масок для тестирования
    mask_types = ['center', 'background', 'all']
    
    for mask_type in mask_types:
        mask_path = f"test_mask_{mask_type}.jpg"
        success = create_simple_mask(image_path, mask_path, mask_type)
        
        if success:
            logger.info(f"✅ Успешно создана маска типа '{mask_type}': {mask_path}")
        else:
            logger.error(f"❌ Не удалось создать маску типа '{mask_type}'")