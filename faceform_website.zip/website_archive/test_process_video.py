import process_video_with_grid
import logging

# Настройка логирования
logging.basicConfig(level=logging.DEBUG)
logger = logging.getLogger(__name__)

def test_process_video():
    try:
        # Открываем тестовое видео
        logger.info("Открываем тестовое видео...")
        with open("test_face_video.mp4", "rb") as f:
            video_data = f.read()
        
        # Определяем функцию обратного вызова для отображения прогресса
        def update_progress(percent, stage):
            logger.info(f"Прогресс: {percent}%, этап: {stage}")
        
        # Обрабатываем видео
        logger.info("Начинаем обработку видео...")
        processed_video, analysis_results = process_video_with_grid.process_video_with_grid(
            video_data, 
            progress_callback=update_progress,
            return_analysis=True
        )
        
        # Проверяем результаты
        logger.info(f"Видео успешно обработано. Размер результата: {len(processed_video)} байт")
        logger.info(f"Результаты анализа: {analysis_results}")
        
        # Сохраняем обработанное видео
        with open("test_processed_video.mp4", "wb") as f:
            f.write(processed_video)
        
        logger.info("Обработанное видео сохранено в test_processed_video.mp4")
        
        return True
    except Exception as e:
        logger.error(f"Ошибка при обработке видео: {str(e)}")
        import traceback
        logger.error(f"Детали ошибки: {traceback.format_exc()}")
        return False

if __name__ == "__main__":
    test_process_video()