# FaceForm Bot Website

Многоязычный веб-сайт для FaceForm Bot с интегрированной системой оплаты Stripe.

## Описание

Сайт представляет собой многоязычное веб-приложение (русский и английский языки) для продвижения и продажи услуг FaceForm Bot - интеллектуального Telegram-бота для анализа лица с использованием компьютерного зрения и AI.

### Основные функции сайта:

- Многоязычный интерфейс (русский и английский)
- Информация о функциях и возможностях бота
- Страница тарифов с пакетами кредитов
- Интегрированная система оплаты Stripe
- Виртуальная примерка причесок
- Поддержка мобильных устройств (адаптивный дизайн)
- Информационные страницы (О нас, Контакты, FAQ)

## Установка и настройка

### Требования

- Python 3.10+
- PostgreSQL
- Stripe аккаунт и API ключи

### Шаги установки

1. Клонировать репозиторий:
```bash
git clone <url-репозитория>
cd website_archive
```

2. Создать и активировать виртуальное окружение:
```bash
python -m venv venv
source venv/bin/activate  # для Linux/Mac
venv\Scripts\activate     # для Windows
```

3. Установить зависимости:
```bash
pip install -r requirements.txt
```

4. Настроить переменные окружения в файле `.env`:
```
FLASK_SECRET_KEY=your_secret_key
DATABASE_URL=postgresql://username:password@localhost/faceform_db
STRIPE_SECRET_KEY=your_stripe_secret_key
STRIPE_PUBLISHABLE_KEY=your_stripe_publishable_key
```

5. Инициализировать базу данных:
```bash
python init_db.py
```

6. Запустить приложение:
```bash
gunicorn --bind 0.0.0.0:5000 main:app
```

## Структура проекта

- `app.py` - основные настройки Flask-приложения
- `main.py` - основные маршруты и функции сайта
- `models.py` - модели базы данных
- `init_db.py` - скрипт инициализации базы данных
- `templates/` - HTML-шаблоны страниц
- `static/` - статические файлы (CSS, JS, изображения)

## Интеграция с Stripe

Сайт использует Stripe для обработки платежей. Для настройки вам потребуется:

1. Зарегистрироваться в [Stripe](https://stripe.com)
2. Получить API-ключи (публичный и секретный)
3. Указать эти ключи в файле `.env`
4. Для обработки webhook-уведомлений настроить endpoint `/webhook`

## Настройка Stripe Webhook

1. В панели управления Stripe создайте Webhook endpoint, указав URL: `https://ваш-домен/webhook`
2. Выберите события для отслеживания: `checkout.session.completed`
3. Получите Webhook Secret Key и добавьте его в `.env` файл:
```
STRIPE_WEBHOOK_SECRET=your_webhook_secret
```

## Лицензия

© 2025 FaceForm Bot. Все права защищены.