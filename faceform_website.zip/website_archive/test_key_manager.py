#!/usr/bin/env python
"""
Скрипт для тестирования менеджера ключей LightX и проверки всех доступных ключей
"""

import os
import sys
import logging
import json

# Настройка логирования
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(name)s - %(levelname)s - %(message)s')
logger = logging.getLogger(__name__)

# Импортируем необходимые модули
try:
    from lightx_key_manager import LightXKeyManager
except ImportError as e:
    logger.error(f"Ошибка импорта: {e}")
    sys.exit(1)

def main():
    """
    Основная функция тестирования
    """
    # Инициализируем менеджер ключей
    key_manager = LightXKeyManager()
    
    # Получаем текущий ключ
    current_key = key_manager.get_current_key()
    try:
        key_str = str(current_key)
        key_display = key_str[:8] + "..." if current_key and len(key_str) > 8 else key_str
    except:
        key_display = "[недоступен]"
    
    logger.info(f"Текущий ключ API: {key_display}")
    
    # Проверяем работоспособность текущего ключа
    test_result = key_manager.test_current_key()
    logger.info(f"Результат проверки текущего ключа: {'успешно' if test_result else 'неудачно'}")
    
    # Тестируем все доступные ключи
    logger.info("\n--- Тестирование всех доступных ключей ---")
    test_results = key_manager.test_all_keys()
    
    # Выводим результаты тестирования
    for key, status in test_results.items():
        logger.info(f"Ключ {key}: {'✓' if status else '✗'}")
    
    # Выводим статистику использования ключей
    logger.info("\n--- Статистика использования ключей ---")
    stats = key_manager.get_key_stats()
    print(json.dumps(stats, indent=2, ensure_ascii=False))
    
    # Тестируем смену ключа
    logger.info("\n--- Тест смены ключа ---")
    new_key = key_manager.switch_to_next_key()
    try:
        key_str = str(new_key)
        key_display = key_str[:8] + "..." if new_key and len(key_str) > 8 else key_str
    except:
        key_display = "[недоступен]"
    logger.info(f"Новый ключ после смены: {key_display}")
    
    # Возвращаемся к исходному ключу, если он был доступен
    if test_result:
        key_manager.current_key = current_key
        logger.info(f"Восстановлен исходный ключ: {current_key[:8]}...")

if __name__ == "__main__":
    main()