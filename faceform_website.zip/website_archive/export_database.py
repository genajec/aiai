#!/usr/bin/env python3
"""
Скрипт для экспорта базы данных SQLite в SQL-команды, которые можно импортировать на другом сервере.
"""

import os
import sqlite3
import datetime

def export_database(db_path, output_file):
    """
    Экспортирует базу данных SQLite в файл SQL.
    
    Args:
        db_path (str): Путь к файлу базы данных SQLite
        output_file (str): Путь к выходному SQL-файлу
    """
    print(f"Экспорт базы данных {db_path} в {output_file}")
    
    # Проверяем существование файла базы данных
    if not os.path.exists(db_path):
        print(f"Ошибка: Файл базы данных {db_path} не найден!")
        return False
    
    # Подключаемся к базе данных
    try:
        conn = sqlite3.connect(db_path)
        cursor = conn.cursor()
    except sqlite3.Error as e:
        print(f"Ошибка при подключении к базе данных: {e}")
        return False
    
    # Открываем файл для записи SQL
    try:
        with open(output_file, 'w') as f:
            # Заголовок файла
            f.write("-- Экспорт базы данных FaceForm Bot\n")
            f.write(f"-- Дата: {datetime.datetime.now()}\n\n")
            
            # Получаем список всех таблиц
            cursor.execute("SELECT name FROM sqlite_master WHERE type='table';")
            tables = cursor.fetchall()
            
            # Для каждой таблицы создаем SQL для ее создания и заполнения данными
            for table in tables:
                table_name = table[0]
                
                # Пропускаем системные таблицы SQLite
                if table_name.startswith('sqlite_'):
                    continue
                
                print(f"Экспорт таблицы {table_name}...")
                
                # Получаем структуру таблицы (CREATE TABLE statement)
                cursor.execute(f"SELECT sql FROM sqlite_master WHERE type='table' AND name='{table_name}';")
                create_table_sql = cursor.fetchone()[0]
                
                # Записываем команду создания таблицы
                f.write(f"-- Структура таблицы {table_name}\n")
                f.write("DROP TABLE IF EXISTS " + table_name + ";\n")
                f.write(create_table_sql + ";\n\n")
                
                # Получаем данные таблицы
                cursor.execute(f"SELECT * FROM {table_name};")
                rows = cursor.fetchall()
                
                if len(rows) > 0:
                    # Получаем имена столбцов
                    cursor.execute(f"PRAGMA table_info({table_name});")
                    columns_info = cursor.fetchall()
                    columns = [col[1] for col in columns_info]
                    
                    # Записываем команды INSERT для данных
                    f.write(f"-- Данные таблицы {table_name}\n")
                    for row in rows:
                        # Преобразуем значения в строки с правильным экранированием
                        values = []
                        for value in row:
                            if value is None:
                                values.append("NULL")
                            elif isinstance(value, (int, float)):
                                values.append(str(value))
                            else:
                                # Экранируем кавычки в строках
                                values.append("'" + str(value).replace("'", "''") + "'")
                        
                        # Формируем и записываем команду INSERT
                        f.write(f"INSERT INTO {table_name} ({', '.join(columns)}) VALUES ({', '.join(values)});\n")
                    
                    f.write("\n")
            
            # Добавляем команду для сохранения изменений
            f.write("-- Сохраняем изменения\n")
            f.write("COMMIT;\n")
            
            print(f"Экспорт успешно завершен. Файл сохранен: {output_file}")
            return True
                
    except Exception as e:
        print(f"Ошибка при экспорте базы данных: {e}")
        return False
    finally:
        # Закрываем соединение с базой данных
        conn.close()

if __name__ == "__main__":
    # Пути по умолчанию
    db_path = "faceform_bot.db"
    output_file = "faceform_bot_db_export.sql"
    
    # Экспортируем базу данных
    export_database(db_path, output_file)