import sys
import os
import logging
import tempfile
import io
from PIL import Image
import numpy as np
import cv2
import telebot
from face_analyzer import FaceAnalyzer
from hairstyle_recommender import HairstyleRecommender

# Настройка логирования
logging.basicConfig(level=logging.INFO, 
                    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s')
logger = logging.getLogger(__name__)

# Используем оригинальную конфигурацию
from config import TELEGRAM_API_TOKEN, BOT_MESSAGES, FACE_SHAPE_CRITERIA

class TestFaceShapeBot:
    def __init__(self):
        # Инициализация Telegram бота
        self.bot = telebot.TeleBot(TELEGRAM_API_TOKEN)
        self.analyzer = FaceAnalyzer()
        self.recommender = HairstyleRecommender()
        
        # Регистрация обработчиков сообщений
        @self.bot.message_handler(commands=['start'])
        def handle_start(message):
            self.start(message)
            
        @self.bot.message_handler(commands=['help'])
        def handle_help(message):
            self.help_command(message)
            
        @self.bot.message_handler(content_types=['photo'])
        def handle_photo(message):
            self.process_photo(message)
            
        @self.bot.message_handler(func=lambda m: True)
        def handle_text(message):
            self.handle_message(message)
    
    def start(self, message):
        """Send a message when the command /start is issued."""
        self.bot.reply_to(message, BOT_MESSAGES["start"])
        
    def help_command(self, message):
        """Send a message when the command /help is issued."""
        self.bot.reply_to(message, BOT_MESSAGES["help"])
        
    def process_photo(self, message):
        """Process the user photo and send face shape analysis with recommendations."""
        logger.info(f"Получено фото от пользователя {message.from_user.id}")
        
        # Отправляем сообщение о начале обработки
        self.bot.reply_to(message, BOT_MESSAGES["processing"])
        
        try:
            # Получаем фото с наилучшим качеством
            file_id = message.photo[-1].file_id
            file_info = self.bot.get_file(file_id)
            downloaded_file = self.bot.download_file(file_info.file_path)
            
            # Анализируем форму лица
            face_shape, vis_image, measurements = self.analyzer.analyze_face_shape(downloaded_file)
            
            if face_shape:
                # Получаем рекомендации на основе формы лица
                face_shape_desc, recommendations = self.recommender.get_recommendations(face_shape)
                
                # Формируем сообщение с результатами
                result_message = f"🔍 *Анализ завершен!*\n\n"
                result_message += f"✅ Форма лица: *{face_shape_desc}*\n\n"
                
                # Добавляем данные измерений для отладки
                result_message += f"📏 Соотношения:\n"
                result_message += f"- Ширина/Длина: {measurements['width_to_length_ratio']:.2f}\n"
                result_message += f"- Лоб/Челюсть: {measurements['forehead_to_jawline_ratio']:.2f}\n"
                result_message += f"- Скулы/Челюсть: {measurements['cheekbone_to_jawline_ratio']:.2f}\n\n"
                
                # Добавляем баллы для каждой формы лица (для отладки)
                if hasattr(self.analyzer, '_last_shape_scores') and self.analyzer._last_shape_scores:
                    result_message += "📊 Баллы по формам:\n"
                    for shape, score in self.analyzer._last_shape_scores.items():
                        result_message += f"- {FACE_SHAPE_CRITERIA[shape]['description']}: {score}\n"
                    result_message += "\n"
                
                # Добавляем рекомендации
                result_message += "💇‍♀️ *Рекомендации по прическам:*\n"
                for rec in recommendations:
                    result_message += f"{rec}\n"
                
                # Отправляем сообщение с результатами
                self.bot.reply_to(message, result_message, parse_mode="Markdown")
                
                # Отправляем изображение с визуализацией
                if vis_image:
                    self.bot.send_photo(message.chat.id, vis_image, caption="Визуализация анализа лица")
            else:
                # Сообщаем, если лицо не обнаружено
                self.bot.reply_to(message, BOT_MESSAGES["no_face"])
                
        except Exception as e:
            # Обрабатываем ошибки
            logger.error(f"Ошибка при обработке фото: {e}")
            self.bot.reply_to(message, BOT_MESSAGES["error"])
    
    def handle_message(self, message):
        """Handle non-photo messages."""
        if message.text:
            logger.info(f"Получено текстовое сообщение от {message.from_user.id}: {message.text}")
        self.bot.reply_to(message, BOT_MESSAGES["non_photo"])
        
    def run(self):
        """Run the bot."""
        logger.info("Тестовый бот запущен...")
        # Запуск бота
        self.bot.polling(none_stop=True)

# Обновляем класс FaceAnalyzer для сохранения баллов форм лица
def monkey_patch_face_analyzer():
    """Модифицируем класс FaceAnalyzer для сохранения баллов для отладки"""
    original_determine_face_shape = FaceAnalyzer._determine_face_shape
    
    def patched_determine_face_shape(self, width_to_length_ratio, forehead_to_jawline_ratio, cheekbone_to_jawline_ratio):
        # Вызываем оригинальный метод
        result = original_determine_face_shape(self, width_to_length_ratio, forehead_to_jawline_ratio, cheekbone_to_jawline_ratio)
        
        # Сохраняем последние баллы, если они есть
        if hasattr(self, 'scores'):
            self._last_shape_scores = self.scores
        
        return result
    
    # Применяем патч
    FaceAnalyzer._determine_face_shape = patched_determine_face_shape

if __name__ == "__main__":
    # Применяем патч для сохранения баллов
    monkey_patch_face_analyzer()
    
    print("Удаляем webhook для предотвращения конфликтов...")
    try:
        import requests
        requests.get(f"https://api.telegram.org/bot{TELEGRAM_API_TOKEN}/deleteWebhook")
        print("Webhook успешно удален")
    except Exception as e:
        print(f"Ошибка при удалении webhook: {e}")
    
    # Создаем и запускаем бот
    test_bot = TestFaceShapeBot()
    test_bot.run()