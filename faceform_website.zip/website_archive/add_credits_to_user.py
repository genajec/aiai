#!/usr/bin/env python3
"""
Скрипт для добавления кредитов конкретному пользователю.
"""

import sqlite3
import datetime

def add_credits_to_user(db_path, telegram_id, credits_amount):
    """
    Добавляет указанное количество кредитов пользователю с заданным Telegram ID.
    
    Args:
        db_path (str): Путь к файлу базы данных
        telegram_id (int): Telegram ID пользователя
        credits_amount (int): Количество кредитов для добавления
    
    Returns:
        bool: True если операция успешна, False в случае ошибки
    """
    try:
        conn = sqlite3.connect(db_path)
        cursor = conn.cursor()
        
        # Получаем текущее количество кредитов пользователя
        cursor.execute("SELECT username, credits FROM users WHERE telegram_id = ?;", (telegram_id,))
        user = cursor.fetchone()
        
        if not user:
            print(f"Пользователь с Telegram ID {telegram_id} не найден в базе данных!")
            return False
            
        username, current_credits = user
        current_credits = current_credits if current_credits is not None else 0
        new_credits = current_credits + credits_amount
        
        # Обновляем количество кредитов
        cursor.execute("UPDATE users SET credits = ? WHERE telegram_id = ?;", (new_credits, telegram_id))
        conn.commit()
        
        print(f"Обновлены кредиты для пользователя {username} (Telegram ID: {telegram_id}):")
        print(f"  Текущие кредиты: {current_credits}")
        print(f"  Добавлено кредитов: {credits_amount}")
        print(f"  Новое количество кредитов: {new_credits}")
        
        # Добавляем запись в лог использования кредитов (если такая таблица существует)
        try:
            cursor.execute("SELECT name FROM sqlite_master WHERE type='table' AND name='credit_usages';")
            if cursor.fetchone():
                cursor.execute(
                    "INSERT INTO credit_usages (user_id, amount, reason, timestamp) VALUES (?, ?, ?, ?);",
                    (telegram_id, credits_amount, "Ручное начисление", datetime.datetime.now())
                )
                conn.commit()
                print("Добавлена запись в историю транзакций.")
        except sqlite3.Error as e:
            print(f"Предупреждение: Не удалось добавить запись в лог: {e}")
        
        return True
    
    except sqlite3.Error as e:
        print(f"Ошибка при работе с базой данных: {e}")
        return False
    finally:
        if 'conn' in locals():
            conn.close()

def add_credits_to_multiple_users(db_path, users_credits):
    """
    Добавляет кредиты нескольким пользователям.
    
    Args:
        db_path (str): Путь к файлу базы данных
        users_credits (dict): Словарь {telegram_id: credits_amount}
    
    Returns:
        int: Количество успешно обработанных пользователей
    """
    success_count = 0
    print(f"Начало пакетного начисления кредитов ({len(users_credits)} пользователей)...")
    
    for telegram_id, credits_amount in users_credits.items():
        print(f"\n--- Обработка пользователя с Telegram ID {telegram_id} ---")
        if add_credits_to_user(db_path, telegram_id, credits_amount):
            success_count += 1
    
    print(f"\nИтого: успешно обработано {success_count} из {len(users_credits)} пользователей.")
    return success_count

if __name__ == "__main__":
    # Настройки скрипта
    db_path = "faceform_bot.db"
    
    # Словарь {telegram_id: credits_amount}
    users_credits = {
        6139328506: 20,   # Lukyanov99 (вы)
        624741160: 20,    # gapparov_rustam
        1105122666: 3,    # @noname65368
        5394916101: 20,   # другой ваш ID
        999999: 3,        # test_user
        123456789: 3      # test_user
    }
    
    # Добавляем кредиты пользователям
    add_credits_to_multiple_users(db_path, users_credits)
    print("Операция завершена!")