import cv2
import numpy as np
import mediapipe as mp
import random
import logging

# Configure logging
logging.basicConfig(level=logging.INFO, 
                   format='%(asctime)s - %(name)s - %(levelname)s - %(message)s')
logger = logging.getLogger(__name__)

class FaceAttractiveness:
    """
    Класс для анализа привлекательности лица на основе симметрии,
    пропорций и расположения черт лица
    """
    
    def __init__(self):
        """Инициализация анализатора привлекательности лица"""
        # Инициализация MediaPipe Face Mesh
        self.mp_face_mesh = mp.solutions.face_mesh
        self.face_mesh = self.mp_face_mesh.FaceMesh(
            static_image_mode=True,
            max_num_faces=1,
            min_detection_confidence=0.5
        )
        
        # Ключевые индексы точек для расчета метрик
        # Eyes landmarks
        self.LEFT_EYE = [33, 133]  # Левый глаз, индексы внешнего и внутреннего уголков
        self.RIGHT_EYE = [362, 263]  # Правый глаз, индексы внешнего и внутреннего уголков
        
        # Nose landmarks
        self.NOSE_TIP = 1  # Кончик носа
        self.NOSE_BOTTOM = 94  # Низ носа
        
        # Lips landmarks
        self.UPPER_LIP = 13  # Верхняя губа центр
        self.LOWER_LIP = 14  # Нижняя губа центр
        
        # Face contour landmarks
        self.CHIN = 152  # Подбородок
        self.LEFT_CHEEK = 234  # Левая щека
        self.RIGHT_CHEEK = 454  # Правая щека
        self.FOREHEAD = 10  # Лоб/центр бровей
        
        # Symmetry points - pairs of points that should be symmetrical
        self.SYMMETRY_PAIRS = [
            # Глаза
            (33, 263),    # Внешние уголки глаз
            (133, 362),   # Внутренние уголки глаз
            (159, 386),   # Верхние точки глаз
            (145, 374),   # Нижние точки глаз
            
            # Брови
            (70, 300),    # Внешние концы бровей
            (107, 336),   # Внутренние концы бровей
            
            # Нос
            (129, 358),   # Крылья носа
            
            # Губы
            (61, 291),    # Уголки губ
            (78, 308),    # Верхняя губа
            (95, 325),    # Нижняя губа
            
            # Контур лица
            (234, 454),   # Скулы
            (139, 368),   # Линия челюсти верхние точки
            (136, 365),   # Линия челюсти нижние точки
            (172, 397)    # Подбородок боковые точки
        ]
    
    def analyze_attractiveness(self, image_data):
        """
        Анализирует привлекательность лица и возвращает оценку
        
        Args:
            image_data: Данные изображения в байтах
            
        Returns:
            tuple: (оценка, комментарий, визуализированное изображение)
        """
        try:
            # Конвертируем данные изображения в numpy массив
            nparr = np.frombuffer(image_data, np.uint8)
            image = cv2.imdecode(nparr, cv2.IMREAD_COLOR)
            
            # Конвертируем в RGB для MediaPipe
            image_rgb = cv2.cvtColor(image, cv2.COLOR_BGR2RGB)
            
            # Обрабатываем изображение для получения лицевых ориентиров
            results = self.face_mesh.process(image_rgb)
            
            # Проверяем, было ли обнаружено лицо
            if not results.multi_face_landmarks:
                logger.warning("No face detected in the image")
                return None, "Лицо не обнаружено на изображении", image
            
            # Получаем первое обнаруженное лицо
            face_landmarks = results.multi_face_landmarks[0]
            
            # Извлекаем ориентиры из результатов
            height, width, _ = image.shape
            landmarks = []
            for landmark in face_landmarks.landmark:
                x, y = int(landmark.x * width), int(landmark.y * height)
                landmarks.append((x, y))
            
            # Рассчитываем метрики
            symmetry_score = self._calculate_symmetry(landmarks, width)
            proportion_score = self._calculate_proportions(landmarks)
            features_score = self._calculate_features_placement(landmarks)
            
            # Итоговая оценка (с небольшим элементом случайности)
            raw_score = (
                symmetry_score * 0.4 +  # Симметрия - наиболее важная метрика
                proportion_score * 0.3 +  # Пропорции
                features_score * 0.3 +  # Расположение черт лица
                random.uniform(-0.3, 0.3)  # Случайная вариация для естественности
            )
            
            # Приводим к диапазону 0-10 и ограничиваем
            final_score = min(max(raw_score * 10, 3.0), 10.0)
            
            # Округляем до одного десятичного знака
            final_score = round(final_score, 1)
            
            # Формируем комментарий
            comment = self._get_comment(final_score)
            
            # Создаем визуализацию для отображения результатов
            visualization = self._create_visualization(image.copy(), landmarks, final_score)
            
            return final_score, comment, visualization
            
        except Exception as e:
            logger.error(f"Error analyzing attractiveness: {e}")
            return None, f"Произошла ошибка при анализе: {e}", image
    
    def _calculate_symmetry(self, landmarks, image_width):
        """
        Рассчитывает симметрию лица, сравнивая точки с обеих сторон
        
        Args:
            landmarks: Список ориентиров лица
            image_width: Ширина изображения
            
        Returns:
            float: Оценка симметрии (0-1)
        """
        # Находим центральную вертикальную линию лица
        center_x = image_width / 2
        
        # Найдем центр лица по ключевым точкам
        nose_tip = landmarks[self.NOSE_TIP]
        face_center_x = nose_tip[0]
        
        # Корректируем наши пары симметрии с учетом реального центра лица
        center_offset = face_center_x - center_x
        
        # Рассчитываем симметрию на основе заданных пар точек
        symmetry_scores = []
        for left_idx, right_idx in self.SYMMETRY_PAIRS:
            left_point = landmarks[left_idx]
            right_point = landmarks[right_idx]
            
            # Расстояние от центра до каждой точки
            left_dist = abs(face_center_x - left_point[0])
            right_dist = abs(right_point[0] - face_center_x)
            
            # Разница в расстояниях (идеально симметричные будут равны)
            dist_diff = abs(left_dist - right_dist)
            
            # Разница в вертикальном положении (должны быть на одной высоте)
            y_diff = abs(left_point[1] - right_point[1])
            
            # Нормализуем разницы относительно ширины лица
            face_width = abs(landmarks[self.LEFT_CHEEK][0] - landmarks[self.RIGHT_CHEEK][0])
            norm_dist_diff = dist_diff / (face_width / 2)
            norm_y_diff = y_diff / (face_width / 2)
            
            # Оценка симметрии для этой пары точек (1 - идеальная симметрия)
            pair_symmetry = 1 - ((norm_dist_diff * 0.7 + norm_y_diff * 0.3) / 2)
            symmetry_scores.append(pair_symmetry)
        
        # Общая оценка симметрии - среднее по всем парам
        return sum(symmetry_scores) / len(symmetry_scores) if symmetry_scores else 0
    
    def _calculate_proportions(self, landmarks):
        """
        Рассчитывает пропорции лица с учетом золотого сечения
        
        Args:
            landmarks: Список ориентиров лица
            
        Returns:
            float: Оценка пропорций (0-1)
        """
        # Идеальные пропорции по золотому сечению (phi = 1.618)
        golden_ratio = 1.618
        
        # Рассчитываем ключевые пропорции
        
        # 1. Отношение высоты к ширине лица
        face_height = self._distance(landmarks[self.FOREHEAD], landmarks[self.CHIN])
        face_width = self._distance(landmarks[self.LEFT_CHEEK], landmarks[self.RIGHT_CHEEK])
        height_width_ratio = face_height / face_width if face_width else 0
        
        # Идеальное отношение высоты к ширине около 1.5-1.618
        ideal_hw_ratio = 1.5
        hw_ratio_score = 1 - min(abs(height_width_ratio - ideal_hw_ratio) / ideal_hw_ratio, 1)
        
        # 2. Отношение расстояния между глазами к ширине лица
        eye_distance = self._distance(landmarks[self.LEFT_EYE[1]], landmarks[self.RIGHT_EYE[0]])
        eye_face_ratio = eye_distance / face_width if face_width else 0
        
        # Идеальное отношение расстояния между глазами к ширине лица около 0.3
        ideal_eye_ratio = 0.3
        eye_ratio_score = 1 - min(abs(eye_face_ratio - ideal_eye_ratio) / ideal_eye_ratio, 1)
        
        # 3. Отношение длины носа к высоте лица
        nose_length = self._distance(landmarks[self.FOREHEAD], landmarks[self.NOSE_BOTTOM])
        nose_face_ratio = nose_length / face_height if face_height else 0
        
        # Идеальное отношение длины носа к высоте лица около 0.33
        ideal_nose_ratio = 0.33
        nose_ratio_score = 1 - min(abs(nose_face_ratio - ideal_nose_ratio) / ideal_nose_ratio, 1)
        
        # 4. Отношение высоты губ к высоте нижней части лица
        lips_height = self._distance(landmarks[self.UPPER_LIP], landmarks[self.LOWER_LIP])
        lower_face_height = self._distance(landmarks[self.NOSE_BOTTOM], landmarks[self.CHIN])
        lips_lower_face_ratio = lips_height / lower_face_height if lower_face_height else 0
        
        # Идеальное отношение высоты губ к высоте нижней части лица около 0.2
        ideal_lips_ratio = 0.2
        lips_ratio_score = 1 - min(abs(lips_lower_face_ratio - ideal_lips_ratio) / ideal_lips_ratio, 1)
        
        # Вычисляем общую оценку пропорций с весами
        proportion_score = (
            hw_ratio_score * 0.3 +
            eye_ratio_score * 0.25 +
            nose_ratio_score * 0.25 +
            lips_ratio_score * 0.2
        )
        
        return proportion_score
    
    def _calculate_features_placement(self, landmarks):
        """
        Рассчитывает оценку размещения черт лица
        
        Args:
            landmarks: Список ориентиров лица
            
        Returns:
            float: Оценка размещения черт (0-1)
        """
        # Общая оценка размещения черт лица
        placement_scores = []
        
        # 1. Расположение глаз - должны быть на уровне 1/3 сверху
        face_height = self._distance(landmarks[self.FOREHEAD], landmarks[self.CHIN])
        eye_level = (landmarks[self.LEFT_EYE[0]][1] + landmarks[self.RIGHT_EYE[1]][1]) / 2
        forehead_y = landmarks[self.FOREHEAD][1]
        chin_y = landmarks[self.CHIN][1]
        
        ideal_eye_level = forehead_y + face_height / 3
        eye_placement_score = 1 - min(abs(eye_level - ideal_eye_level) / (face_height / 3), 1)
        placement_scores.append(eye_placement_score)
        
        # 2. Расположение носа - должен быть на уровне 2/3 сверху
        nose_level = landmarks[self.NOSE_TIP][1]
        ideal_nose_level = forehead_y + face_height * 2/3
        nose_placement_score = 1 - min(abs(nose_level - ideal_nose_level) / (face_height / 3), 1)
        placement_scores.append(nose_placement_score)
        
        # 3. Расположение губ - должны быть пропорционально между носом и подбородком
        lips_level = (landmarks[self.UPPER_LIP][1] + landmarks[self.LOWER_LIP][1]) / 2
        lower_third_height = face_height / 3
        ideal_lips_level = forehead_y + face_height * 0.75  # немного ниже 2/3
        lips_placement_score = 1 - min(abs(lips_level - ideal_lips_level) / (lower_third_height / 2), 1)
        placement_scores.append(lips_placement_score)
        
        # 4. Размер глаз относительно лица
        left_eye_width = self._distance(landmarks[self.LEFT_EYE[0]], landmarks[self.LEFT_EYE[1]])
        right_eye_width = self._distance(landmarks[self.RIGHT_EYE[0]], landmarks[self.RIGHT_EYE[1]])
        avg_eye_width = (left_eye_width + right_eye_width) / 2
        face_width = self._distance(landmarks[self.LEFT_CHEEK], landmarks[self.RIGHT_CHEEK])
        
        eye_width_ratio = avg_eye_width / face_width if face_width else 0
        ideal_eye_width_ratio = 0.15  # Примерно 15% от ширины лица
        eye_width_score = 1 - min(abs(eye_width_ratio - ideal_eye_width_ratio) / ideal_eye_width_ratio, 1)
        placement_scores.append(eye_width_score)
        
        # Вычисляем общую оценку размещения
        return sum(placement_scores) / len(placement_scores) if placement_scores else 0
    
    def _distance(self, point1, point2):
        """Вычисляет евклидово расстояние между двумя точками"""
        return np.sqrt((point1[0] - point2[0])**2 + (point1[1] - point2[1])**2)
    
    def _get_comment(self, score):
        """
        Возвращает комментарий на основе оценки
        
        Args:
            score: Числовая оценка привлекательности (0-10)
            
        Returns:
            str: Текстовый комментарий
        """
        if score >= 9:
            return "Ваша внешность приближена к золотому стандарту симметрии. Очень высокие баллы!"
        elif score >= 7:
            return "Ваше лицо сбалансировано и гармонично"
        elif score >= 5:
            return "Небольшие отклонения от симметрии, но всё индивидуально красиво"
        else:
            return "Программа определила асимметрию — но уникальность в этом и есть шарм!"
    
    def _create_visualization(self, image, landmarks, score):
        """
        Создает визуализацию результатов анализа
        
        Args:
            image: Исходное изображение
            landmarks: Список ориентиров лица
            score: Оценка привлекательности
            
        Returns:
            numpy.ndarray: Изображение с визуализацией
        """
        height, width, _ = image.shape
        
        # Создаем копию изображения для визуализации
        vis_image = image.copy()
        
        # Определяем основные точки для анализа формы лица
        forehead = landmarks[self.FOREHEAD]
        chin = landmarks[self.CHIN]
        left_cheek = landmarks[self.LEFT_CHEEK]
        right_cheek = landmarks[self.RIGHT_CHEEK]
        nose_tip = landmarks[self.NOSE_TIP]
        
        # Находим габариты лица
        face_top = forehead[1]
        face_bottom = chin[1]
        face_left = left_cheek[0]
        face_right = right_cheek[0]
        
        face_height = face_bottom - face_top
        face_width = face_right - face_left
        
        # Центральная линия симметрии
        center_x = nose_tip[0]
        cv2.line(vis_image, (center_x, face_top - int(0.1 * face_height)), 
                 (center_x, face_bottom + int(0.1 * face_height)), (0, 255, 0), 2)
        
        # Горизонтальные линии (разделение на трети)
        y1 = face_top + face_height // 3
        y2 = face_top + 2 * face_height // 3
        
        cv2.line(vis_image, (face_left - int(0.1 * face_width), y1), 
                 (face_right + int(0.1 * face_width), y1), (0, 255, 0), 2)
        cv2.line(vis_image, (face_left - int(0.1 * face_width), y2), 
                 (face_right + int(0.1 * face_width), y2), (0, 255, 0), 2)
        
        # Внешний контур лица - более толстая линия
        jaw_points = [landmarks[i] for i in [162, 21, 54, 103, 67, 109, 10, 338, 297, 332, 284, 251, 389]]
        for i in range(len(jaw_points) - 1):
            cv2.line(vis_image, jaw_points[i], jaw_points[i + 1], (0, 165, 255), 3)
            
        # Добавляем измерения
        # Высота лица
        cv2.line(vis_image, (face_left - int(0.15 * face_width), face_top), 
                 (face_left - int(0.15 * face_width), face_bottom), (255, 0, 255), 2)
        
        # Ширина лица
        cv2.line(vis_image, (face_left, face_bottom + int(0.1 * face_height)), 
                 (face_right, face_bottom + int(0.1 * face_height)), (255, 0, 255), 2)
        
        # Расстояния для пропорций
        # Ширина лба
        forehead_left = landmarks[70]
        forehead_right = landmarks[300]
        cv2.line(vis_image, forehead_left, forehead_right, (255, 255, 0), 2)
        
        # Ширина челюсти
        jaw_left = landmarks[172]
        jaw_right = landmarks[397]
        cv2.line(vis_image, jaw_left, jaw_right, (255, 255, 0), 2)
        
        # Рисуем ключевые точки симметрии
        for left_idx, right_idx in self.SYMMETRY_PAIRS:
            left_point = landmarks[left_idx]
            right_point = landmarks[right_idx]
            
            # Рисуем точки
            cv2.circle(vis_image, left_point, 2, (0, 0, 255), -1)
            cv2.circle(vis_image, right_point, 2, (0, 0, 255), -1)
            
            # Соединяем симметричные точки линией
            cv2.line(vis_image, left_point, right_point, (255, 0, 0), 1)
        
        # Ключевые точки для глаз
        left_eye_outer = landmarks[self.LEFT_EYE[0]]
        left_eye_inner = landmarks[self.LEFT_EYE[1]]
        right_eye_inner = landmarks[self.RIGHT_EYE[0]]
        right_eye_outer = landmarks[self.RIGHT_EYE[1]]
        
        cv2.line(vis_image, left_eye_outer, left_eye_inner, (0, 255, 255), 2)
        cv2.line(vis_image, right_eye_inner, right_eye_outer, (0, 255, 255), 2)
        cv2.line(vis_image, left_eye_inner, right_eye_inner, (0, 255, 255), 2)
        
        # Линия носа
        nose_bottom = landmarks[self.NOSE_BOTTOM]
        cv2.line(vis_image, forehead, nose_bottom, (255, 0, 255), 2)
        
        # Губы
        upper_lip = landmarks[self.UPPER_LIP]
        lower_lip = landmarks[self.LOWER_LIP]
        cv2.line(vis_image, upper_lip, lower_lip, (0, 255, 255), 2)
        
        # Определение формы лица на основе измерений
        # Вычисляем соотношения для определения формы
        width_to_length_ratio = face_width / face_height if face_height else 0
        
        # Определяем форму лица на основе соотношения ширины к высоте
        face_shape = "Неопределенная"
        if width_to_length_ratio >= 0.8 and width_to_length_ratio <= 0.85:
            face_shape = "Квадратное"
        elif width_to_length_ratio > 0.85:
            face_shape = "Круглое"
        elif width_to_length_ratio >= 0.7 and width_to_length_ratio < 0.8:
            face_shape = "Сердцевидное"
        elif width_to_length_ratio < 0.7:
            face_shape = "Овальное/Продолговатое"
        
        # Добавляем информацию о форме лица
        shape_text = f"Форма лица: {face_shape}"
        cv2.putText(vis_image, shape_text, (10, height - 30), cv2.FONT_HERSHEY_SIMPLEX,
                   0.7, (0, 0, 255), 2, cv2.LINE_AA)
        
        # Добавляем соотношение ширины к высоте
        ratio_text = f"Соотношение ширины к высоте: {width_to_length_ratio:.2f}"
        cv2.putText(vis_image, ratio_text, (10, height - 60), cv2.FONT_HERSHEY_SIMPLEX,
                   0.7, (0, 0, 255), 2, cv2.LINE_AA)
        
        # Добавляем текст с оценкой привлекательности
        score_text = f"Оценка привлекательности: {score:.1f}/10"
        cv2.putText(vis_image, score_text, (10, 30), cv2.FONT_HERSHEY_SIMPLEX, 
                    1, (0, 0, 255), 2, cv2.LINE_AA)
        
        return vis_image


# Пример использования
if __name__ == "__main__":
    import sys
    
    if len(sys.argv) < 2:
        print("Использование: python face_attractiveness.py <путь_к_изображению>")
        sys.exit(1)
        
    image_path = sys.argv[1]
    
    try:
        with open(image_path, "rb") as img_file:
            image_data = img_file.read()
            
        analyzer = FaceAttractiveness()
        score, comment, visualization = analyzer.analyze_attractiveness(image_data)
        
        if score is not None:
            print(f"Оценка привлекательности: {score:.1f}/10")
            print(f"Комментарий: {comment}")
            
            # Сохраняем визуализацию
            output_path = "result_" + image_path.split("/")[-1]
            cv2.imwrite(output_path, visualization)
            print(f"Визуализация сохранена в {output_path}")
        else:
            print(f"Ошибка: {comment}")
    
    except Exception as e:
        print(f"Произошла ошибка: {e}")