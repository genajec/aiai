import os
import sys
import cv2
import numpy as np
from PIL import Image, ImageDraw, ImageFont
import io

# Установите модуль конфигурации для тестирования
sys.modules['config'] = __import__('config')
from config import FACE_SHAPE_CRITERIA
from face_analyzer import FaceAnalyzer

def create_demo_image():
    """
    Создает демонстрационное изображение, которое показывает все типы сеток и визуализаций для разных форм лица
    """
    print("Создание демонстрационных визуализаций для разных форм лица...")
    
    # Создаем демо-изображение для каждой формы лица
    demo_size = (400, 500)  # Размер демо-изображения (ширина, высота)
    demo_image = np.zeros((demo_size[1], demo_size[0], 3), dtype=np.uint8)
    
    # Заполняем его серым цветом
    demo_image.fill(200)  # Светло-серый
    
    # Рисуем овальную форму лица
    center = (demo_size[0] // 2, demo_size[1] // 2)
    axes = (120, 160)  # Полуоси эллипса (a, b)
    
    # Рисуем овал (лицо)
    cv2.ellipse(demo_image, center, axes, 0, 0, 360, (240, 240, 240), -1)
    
    # Рисуем глаза
    eye_y = center[1] - 30
    left_eye = (center[0] - 50, eye_y)
    right_eye = (center[0] + 50, eye_y)
    cv2.circle(demo_image, left_eye, 15, (255, 255, 255), -1)
    cv2.circle(demo_image, right_eye, 15, (255, 255, 255), -1)
    
    cv2.circle(demo_image, left_eye, 5, (70, 70, 70), -1)
    cv2.circle(demo_image, right_eye, 5, (70, 70, 70), -1)
    
    # Рисуем нос
    nose_bottom = (center[0], center[1] + 30)
    nose_top = (center[0], center[1] - 10)
    nose_width = 20
    nose_points = np.array([
        [nose_top[0], nose_top[1]],
        [nose_bottom[0] - nose_width//2, nose_bottom[1]],
        [nose_bottom[0] + nose_width//2, nose_bottom[1]]
    ], np.int32)
    cv2.fillPoly(demo_image, [nose_points], (220, 220, 220))
    
    # Рисуем рот
    mouth_y = center[1] + 70
    mouth_width = 70
    mouth_height = 15
    cv2.ellipse(demo_image, (center[0], mouth_y), (mouth_width, mouth_height), 0, 0, 180, (150, 150, 150), -1)
    
    # Сохраняем базовое изображение лица
    cv2.imwrite('demo_base_face.jpg', demo_image)
    
    # Создаем визуализации для каждой формы лица
    # Модифицируем базовое лицо для каждого типа
    shape_images = {}
    
    # Овальное лицо (базовое)
    shape_images["OVAL"] = demo_image.copy()
    
    # Круглое лицо
    round_face = demo_image.copy()
    # Уменьшаем высоту и увеличиваем ширину
    round_axes = (130, 140)
    cv2.ellipse(round_face, center, round_axes, 0, 0, 360, (240, 240, 240), -1)
    cv2.ellipse(round_face, (center[0], mouth_y), (mouth_width-10, mouth_height), 0, 0, 180, (150, 150, 150), -1)
    shape_images["ROUND"] = round_face
    
    # Квадратное лицо
    square_face = demo_image.copy()
    # Рисуем более угловатое лицо
    jaw_width = 130
    jaw_height = 160
    cv2.rectangle(square_face, 
                 (center[0] - jaw_width//2, center[1] - jaw_height//2),
                 (center[0] + jaw_width//2, center[1] + jaw_height//2),
                 (240, 240, 240), -1)
    # Закругляем верх
    cv2.ellipse(square_face, (center[0], center[1] - jaw_height//2 + 50), 
               (jaw_width//2, 80), 0, 180, 360, (240, 240, 240), -1)
    shape_images["SQUARE"] = square_face
    
    # Сердцевидное лицо
    heart_face = demo_image.copy()
    # Верхняя часть шире
    top_width = 140
    bottom_width = 90
    top_points = np.array([
        [center[0] - top_width//2, center[1] - 70],
        [center[0] + top_width//2, center[1] - 70],
        [center[0] + bottom_width//2, center[1] + 120],
        [center[0] - bottom_width//2, center[1] + 120],
    ], np.int32)
    cv2.fillPoly(heart_face, [top_points], (240, 240, 240))
    # Закругляем верх
    cv2.ellipse(heart_face, (center[0], center[1] - 70), 
               (top_width//2, 80), 0, 180, 360, (240, 240, 240), -1)
    shape_images["HEART"] = heart_face
    
    # Продолговатое лицо
    oblong_face = demo_image.copy()
    # Увеличиваем высоту и уменьшаем ширину
    oblong_axes = (100, 180)
    cv2.ellipse(oblong_face, center, oblong_axes, 0, 0, 360, (240, 240, 240), -1)
    shape_images["OBLONG"] = oblong_face
    
    # Ромбовидное лицо
    diamond_face = demo_image.copy()
    # Рисуем ромбовидное лицо
    diamond_points = np.array([
        [center[0], center[1] - 160],
        [center[0] + 120, center[1]],
        [center[0], center[1] + 160],
        [center[0] - 120, center[1]],
    ], np.int32)
    cv2.fillPoly(diamond_face, [diamond_points], (240, 240, 240))
    shape_images["DIAMOND"] = diamond_face
    
    # Визуализируем каждый тип лица с соответствующей сеткой и цветом
    analyzer = FaceAnalyzer()
    
    # Создаем составное изображение
    num_shapes = len(shape_images)
    grid_cols = 3
    grid_rows = (num_shapes + grid_cols - 1) // grid_cols
    
    grid_image_width = demo_size[0] * grid_cols
    grid_image_height = demo_size[1] * grid_rows
    
    grid_image = np.zeros((grid_image_height, grid_image_width, 3), dtype=np.uint8)
    grid_image.fill(240)  # Белый фон
    
    # Цвета для разных форм лица (BGR формат)
    shape_colors = {
        "OVAL": (0, 200, 0),       # Green
        "ROUND": (0, 165, 255),    # Orange
        "SQUARE": (255, 0, 0),     # Blue
        "HEART": (130, 0, 255),    # Purple
        "OBLONG": (255, 255, 0),   # Cyan
        "DIAMOND": (0, 0, 255)     # Red
    }
    
    row, col = 0, 0
    for shape, image in shape_images.items():
        # Определяем позицию в сетке
        x = col * demo_size[0]
        y = row * demo_size[1]
        
        # Копируем базовое изображение с лицом
        grid_image[y:y+demo_size[1], x:x+demo_size[0]] = image.copy()
        
        # Добавляем полупрозрачную сетку соответствующего цвета
        color = shape_colors.get(shape, (0, 255, 0))
        overlay = grid_image[y:y+demo_size[1], x:x+demo_size[0]].copy()
        
        # Здесь мы рисуем сетку для каждого типа лица
        # Вместо точного воспроизведения MediaPipe, создадим стилизованную сетку
        if shape == "OVAL":
            # Для овального лица - эллиптическая сетка
            for i in range(0, 180, 20):
                cv2.ellipse(overlay, center, (120-i//3, 160-i//3), 0, 0, 360, color, 1)
            # Вертикальные линии
            for i in range(-60, 61, 30):
                pt1 = (center[0] + i, center[1] - 160)
                pt2 = (center[0] + i, center[1] + 160)
                cv2.line(overlay, pt1, pt2, color, 1)
        
        elif shape == "ROUND":
            # Для круглого лица - более круглая сетка
            for i in range(0, 130, 20):
                cv2.circle(overlay, center, 130-i, color, 1)
            # Радиальные линии
            for angle in range(0, 180, 30):
                rad = np.radians(angle)
                pt1 = (int(center[0] + 130 * np.cos(rad)), int(center[1] + 130 * np.sin(rad)))
                pt2 = (int(center[0] - 130 * np.cos(rad)), int(center[1] - 130 * np.sin(rad)))
                cv2.line(overlay, pt1, pt2, color, 1)
                
        elif shape == "SQUARE":
            # Для квадратного лица - прямоугольная сетка с акцентом на челюсть
            for i in range(0, 120, 30):
                cv2.rectangle(overlay, 
                             (center[0] - jaw_width//2 + i//2, center[1] - jaw_height//2 + i//2),
                             (center[0] + jaw_width//2 - i//2, center[1] + jaw_height//2 - i//2),
                             color, 1)
            # Добавляем несколько линий на челюсти
            jaw_y = center[1] + jaw_height//2 - 20
            for x in range(center[0] - jaw_width//2, center[0] + jaw_width//2, 20):
                cv2.circle(overlay, (x, jaw_y), 2, color, -1)
                
        elif shape == "HEART":
            # Для сердцевидного лица - сетка, подчеркивающая широкий лоб и узкий подбородок
            for i in range(0, 120, 30):
                top_w = top_width - i
                bottom_w = bottom_width - i//2
                points = np.array([
                    [center[0] - top_w//2, center[1] - 70],
                    [center[0] + top_w//2, center[1] - 70],
                    [center[0] + bottom_w//2, center[1] + 120 - i//3],
                    [center[0] - bottom_w//2, center[1] + 120 - i//3],
                ], np.int32)
                cv2.polylines(overlay, [points], True, color, 1)
                
        elif shape == "OBLONG":
            # Для продолговатого лица - вытянутая вертикальная сетка
            for i in range(0, 180, 30):
                cv2.ellipse(overlay, center, (100-i//4, 180-i//2), 0, 0, 360, color, 1)
            # Горизонтальные линии
            for y_offset in range(-160, 161, 40):
                y = center[1] + y_offset
                cv2.line(overlay, (center[0] - 100, y), (center[0] + 100, y), color, 1)
                
        elif shape == "DIAMOND":
            # Для ромбовидного лица - ромбовидная сетка
            for i in range(0, 120, 30):
                points = np.array([
                    [center[0], center[1] - (160-i)],
                    [center[0] + (120-i), center[1]],
                    [center[0], center[1] + (160-i)],
                    [center[0] - (120-i), center[1]],
                ], np.int32)
                cv2.polylines(overlay, [points], True, color, 1)
                
        # Накладываем сетку полупрозрачно
        cv2.addWeighted(overlay, 0.3, grid_image[y:y+demo_size[1], x:x+demo_size[0]], 0.7, 0, 
                      grid_image[y:y+demo_size[1], x:x+demo_size[0]])
        
        # Добавляем заголовок с названием формы на английском
        # Использовать английские названия для надежности
        face_shape_english = {
            "OVAL": "Oval Face", 
            "ROUND": "Round Face", 
            "SQUARE": "Square Face", 
            "HEART": "Heart Face", 
            "OBLONG": "Oblong Face", 
            "DIAMOND": "Diamond Face"
        }
        
        face_shape_text = face_shape_english[shape]
        text_size = cv2.getTextSize(face_shape_text, cv2.FONT_HERSHEY_SIMPLEX, 0.7, 2)[0]
        text_x = x + (demo_size[0] - text_size[0]) // 2
        
        # Фон для текста
        cv2.rectangle(grid_image, 
                     (text_x - 5, y + 10), 
                     (text_x + text_size[0] + 5, y + 10 + text_size[1] + 10), 
                     (0, 0, 0), 
                     -1)
        
        # Добавляем текст
        cv2.putText(grid_image, 
                   face_shape_text, 
                   (text_x, y + 10 + text_size[1]), 
                   cv2.FONT_HERSHEY_SIMPLEX, 
                   0.7, 
                   color, 
                   2)
        
        # Переходим к следующей позиции в сетке
        col += 1
        if col >= grid_cols:
            col = 0
            row += 1
    
    # Сохраняем составное изображение
    cv2.imwrite("demo_face_shapes.jpg", grid_image)
    print("Демонстрационное изображение сохранено в demo_face_shapes.jpg")

if __name__ == "__main__":
    create_demo_image()