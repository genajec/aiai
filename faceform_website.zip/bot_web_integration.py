"""
Модуль для интеграции веб-приложения с Telegram ботом
"""
import os
import logging
import telebot
from config import TELEGRAM_API_TOKEN
from face_analyzer import FaceAnalyzer
import tempfile
import cv2
import numpy as np
import time

# Настройка логирования
logging.basicConfig(
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    level=logging.INFO
)
logger = logging.getLogger(__name__)

class BotWebIntegration:
    """Класс для интеграции функций Telegram бота с веб-приложением"""
    
    def __init__(self):
        """Инициализация интеграции"""
        # Создаем экземпляр бота
        self.bot = telebot.TeleBot(TELEGRAM_API_TOKEN, threaded=False)
        self.face_analyzer = FaceAnalyzer()
        
        try:
            # Проверяем соединение с ботом
            bot_info = self.bot.get_me()
            logger.info(f"Bot integration initialized: @{bot_info.username}")
            self.is_initialized = True
            
            # Удаляем существующие вебхуки для предотвращения конфликтов
            self.bot.remove_webhook()
            logger.info("Webhook removed to avoid conflicts")
        except Exception as e:
            logger.error(f"Failed to initialize bot integration: {e}")
            self.is_initialized = False
    
    def send_notification(self, user_id, message_text):
        """
        Отправляет уведомление пользователю через Telegram
        
        Args:
            user_id (int): Telegram ID пользователя
            message_text (str): Текст уведомления
            
        Returns:
            bool: True если отправка успешна, False в случае ошибки
        """
        if not self.is_initialized:
            logger.error("Bot integration not initialized")
            return False
            
        try:
            self.bot.send_message(chat_id=user_id, text=message_text)
            return True
        except Exception as e:
            logger.error(f"Error sending notification to user {user_id}: {e}")
            return False
    
    def process_hairstyle_request(self, image_data, face_shape, hairstyle_index, gender="male"):
        """
        Обрабатывает запрос на примерку прически через интерфейс бота
        
        Args:
            image_data (bytes): Данные изображения
            face_shape (str): Форма лица пользователя
            hairstyle_index (int): Индекс прически
            gender (str): Пол (male/female)
            
        Returns:
            bytes: Результат наложения прически или None в случае ошибки
        """
        try:
            # Проверяем, поддерживает ли метод параметр gender
            import inspect
            apply_hairstyle_params = inspect.signature(self.face_analyzer.apply_hairstyle).parameters
            
            # Если метод поддерживает параметр gender
            if 'gender' in apply_hairstyle_params:
                result_image_bytes = self.face_analyzer.apply_hairstyle(
                    image_data=image_data,
                    face_shape=face_shape,
                    hairstyle_index=hairstyle_index,
                    gender=gender
                )
            else:
                # Если не поддерживает, вызываем без этого параметра
                result_image_bytes = self.face_analyzer.apply_hairstyle(
                    image_data=image_data,
                    face_shape=face_shape,
                    hairstyle_index=hairstyle_index
                )
            
            return result_image_bytes
        except Exception as e:
            logger.error(f"Error processing hairstyle request: {e}")
            return None
    
    def analyze_face_shape(self, image_data):
        """
        Анализирует форму лица через интерфейс бота
        
        Args:
            image_data (bytes): Данные изображения
            
        Returns:
            tuple: (форма_лица, визуализация, измерения) или (None, None, None) в случае ошибки
        """
        try:
            # Используем тот же метод, что и в боте
            face_shape, vis_image_bytes, measurements = self.face_analyzer.analyze_face_shape(image_data)
            return face_shape, vis_image_bytes, measurements
        except Exception as e:
            logger.error(f"Error analyzing face shape: {e}")
            return None, None, None
    
    def send_image_result_to_user(self, user_id, image_bytes, caption=None):
        """
        Отправляет результат обработки изображения пользователю через Telegram
        
        Args:
            user_id (int): Telegram ID пользователя
            image_bytes (bytes): Данные изображения
            caption (str, optional): Подпись к изображению
            
        Returns:
            bool: True если отправка успешна, False в случае ошибки
        """
        if not self.is_initialized:
            logger.error("Bot integration not initialized")
            return False
            
        try:
            # Создаем временный файл
            with tempfile.NamedTemporaryFile(suffix=".jpg", delete=False) as temp_file:
                temp_file.write(image_bytes)
                temp_file_path = temp_file.name
            
            # Отправляем изображение
            with open(temp_file_path, 'rb') as photo:
                self.bot.send_photo(chat_id=user_id, photo=photo, caption=caption)
            
            # Удаляем временный файл
            os.unlink(temp_file_path)
            return True
        except Exception as e:
            logger.error(f"Error sending image to user {user_id}: {e}")
            return False

# Создаем глобальный экземпляр для использования в приложении
bot_integration = BotWebIntegration()