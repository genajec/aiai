#!/bin/bash

# Скрипт для быстрой настройки и запуска веб-приложения FaceForm

echo "Настройка веб-приложения FaceForm..."

# Создание виртуального окружения
python3 -m venv venv
source venv/bin/activate

# Установка зависимостей
pip install -r requirements.txt

# Проверка файла .env
if [ ! -f .env ]; then
    echo "Файл .env не найден. Создание примера..."
    cp .env.example .env
    echo "Файл .env.example скопирован как .env. Пожалуйста, отредактируйте его с вашими настройками."
fi

# Запуск приложения
echo "Запуск приложения..."
gunicorn --bind 0.0.0.0:5000 --workers 2 main:app

echo "Приложение запущено на http://localhost:5000"