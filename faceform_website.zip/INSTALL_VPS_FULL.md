# Руководство по установке FaceForm Bot + Сайт на VPS

## Подготовка сервера

1. Подключитесь к серверу по SSH:
```bash
ssh faceform@faceform.vps.webdock.cloud
```

2. Обновите пакеты и установите необходимые инструменты:
```bash
sudo apt update
sudo apt upgrade -y
sudo apt install -y python3-pip python3-venv nginx certbot python3-certbot-nginx git supervisor
```

## Установка бота и сайта

1. Создайте директорию проекта:
```bash
mkdir -p ~/faceform_bot
cd ~/faceform_bot
```

2. Клонируйте репозиторий из GitHub (если он есть) или загрузите исходные файлы:
```bash
git clone https://github.com/username/faceform_bot.git .
```

   Или можно загрузить файлы с локального компьютера через SCP:
```bash
# На локальном компьютере:
scp -r /path/to/faceform_files/* faceform@faceform.vps.webdock.cloud:~/faceform_bot/
```

3. Создайте файл .env с настройками:
```bash
nano .env
```

4. Добавьте в файл следующие настройки:
```
# Telegram Bot
TELEGRAM_BOT_TOKEN=7586536261:AAFWtwOsRY390hEKJBzCS1grQtCO8fTHaXc
TELEGRAM_BOT_NAME=Faceform_bot

# Stripe API
STRIPE_SECRET_KEY=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
STRIPE_PUBLIC_KEY=pk_live_51RFWPbIXP9qWqMx9mFcESigNDB705oZNH8glzwdnzxkxHoBINjgfXZHfNJrJQMuDLEyCnP1jtO1YVLdUSKEyKTzs00DP5wzGaS

# LightX API Keys
LIGHTX_API_KEYS=33dc337eefda49ab92fd29f43da336bf_ac9ec1f895af47948c32513640a0136a_andoraitools,4e0057d083f3420dbe043d00c1986d9a_d7d8ea58f693480cba99ebcbc9998bc5_andoraitools,d7d8e6a124b94ae2a1369229e247f920_aad315a2e1f64b778c49cf8b75d7a413_andoraitools,ee03d7f4abbe489ebf52f6a6898a2e58_1bf285878c8a4950bca2d0e28ce08a27_andoraitools,2614471723e34e30a5c53ab682c88c52_415cd730394e4aedb0c7c377890321c7_andoraitools,b9043dfb51af4e3d9a787bb7e6858ece_9814ff95790f49e6b23ca71195799f3f_andoraitools

# DeepL API
DEEPL_API_KEY=7fe9dd7a-990a-4bf1-86af-a216b1b993a1:fx

# Server Config
SESSION_SECRET=faceform_session_secret_123456789abc
REPLIT_DOMAINS=faceform.vps.webdock.cloud
DATABASE_URL=sqlite:///faceform_bot.db
```

5. Создайте и активируйте виртуальное окружение Python:
```bash
python3 -m venv venv
source venv/bin/activate
```

6. Установите необходимые зависимости:
```bash
pip install flask flask-sqlalchemy gunicorn python-dotenv pytelegrambotapi stripe opencv-python numpy mediapipe psycopg2-binary requests pillow
```

## Настройка Nginx

1. Создайте конфигурационный файл для сайта:
```bash
sudo nano /etc/nginx/sites-available/faceform
```

2. Добавьте следующую конфигурацию:
```
server {
    listen 80;
    server_name faceform.vps.webdock.cloud;

    location / {
        proxy_pass http://localhost:5000;
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto $scheme;
    }

    # Для вебхуков Stripe
    location /stripe-webhook {
        proxy_pass http://localhost:5000/stripe-webhook;
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto $scheme;
    }

    # Для вебхуков Telegram (если вы используете webhook вместо polling)
    location /webhook {
        proxy_pass http://localhost:5000/webhook;
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto $scheme;
    }
}
```

3. Создайте символическую ссылку на конфигурацию:
```bash
sudo ln -s /etc/nginx/sites-available/faceform /etc/nginx/sites-enabled/
sudo nginx -t  # Проверка синтаксиса
sudo systemctl restart nginx
```

4. Настройте SSL с помощью Let's Encrypt:
```bash
sudo certbot --nginx -d faceform.vps.webdock.cloud
```

## Настройка Supervisor

1. Создайте конфигурационный файл для supervisor:
```bash
sudo nano /etc/supervisor/conf.d/faceform.conf
```

2. Добавьте следующую конфигурацию:
```
[program:faceform]
command=/home/faceform/faceform_bot/venv/bin/gunicorn --bind 127.0.0.1:5000 main:app
directory=/home/faceform/faceform_bot
user=faceform
autostart=true
autorestart=true
stderr_logfile=/var/log/faceform/faceform.err.log
stdout_logfile=/var/log/faceform/faceform.out.log
```

3. Создайте директорию для логов и запустите сервис:
```bash
sudo mkdir -p /var/log/faceform
sudo supervisorctl reread
sudo supervisorctl update
sudo supervisorctl start faceform
```

## Настройка вебхуков Stripe

1. Войдите в панель управления Stripe
2. Перейдите в раздел "Developers" -> "Webhooks"
3. Добавьте конечную точку: `https://faceform.vps.webdock.cloud/stripe-webhook`
4. Выберите события для отслеживания:
   - `checkout.session.completed`
   - `payment_intent.succeeded`
   - `payment_intent.payment_failed`
5. Скопируйте "Signing Secret" и добавьте его в файл `.env` как `STRIPE_WEBHOOK_SECRET`

## Проверка работы

1. Проверьте, что веб-сайт доступен по адресу `https://faceform.vps.webdock.cloud`
2. Проверьте работу бота отправив сообщение в Telegram
3. Проверьте логи:
```bash
sudo tail -f /var/log/faceform/faceform.out.log
sudo tail -f /var/log/faceform/faceform.err.log
```

## Устранение неполадок

1. **Ошибка: Сайт не доступен**
   - Проверьте статус Nginx: `sudo systemctl status nginx`
   - Проверьте логи Nginx: `sudo tail -f /var/log/nginx/error.log`
   - Проверьте, что сервис запущен: `sudo supervisorctl status faceform`

2. **Ошибка: Бот не отвечает**
   - Проверьте логи: `sudo tail -f /var/log/faceform/faceform.out.log`
   - Убедитесь, что токен бота правильно указан в `.env`
   - Перезапустите сервис: `sudo supervisorctl restart faceform`

3. **Ошибка: Не работают платежи Stripe**
   - Проверьте, что вебхуки правильно настроены в панели Stripe
   - Убедитесь, что в `.env` правильно указаны ключи STRIPE_SECRET_KEY и STRIPE_PUBLIC_KEY
   - Проверьте логи на ошибки: `sudo tail -f /var/log/faceform/faceform.out.log`

## Управление сервисом

- Перезапуск: `sudo supervisorctl restart faceform`
- Остановка: `sudo supervisorctl stop faceform`
- Запуск: `sudo supervisorctl start faceform`
- Статус: `sudo supervisorctl status faceform`

## Структура проекта

Основные файлы, которые должны быть в директории проекта:

- `main.py` - Главный файл приложения Flask
- `bot.py` - Основной файл Telegram бота
- `config.py` - Файл конфигурации
- `database.py` - Файл для работы с базой данных
- `face_analyzer.py` - Модуль анализа лиц
- `stripe_payment.py` - Модуль для работы с платежами Stripe
- `templates/` - Директория с HTML-шаблонами
- `static/` - Директория со статическими файлами (CSS, JavaScript, изображения)