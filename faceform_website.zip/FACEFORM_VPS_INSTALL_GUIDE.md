# FaceForm VPS Installation Guide

## Files Included in the Archive

1. `faceform_deploy_vps.zip` - main application archive
2. `faceform_deploy_vps_env.txt` - sample environment variables file (rename to `.env` when installing)

## Installation Instructions

### 1. Prepare the VPS Server

SSH into your VPS server (IP: 92.113.145.171) and update the system:

```bash
sudo apt update
sudo apt upgrade -y
sudo apt install -y python3-pip python3-venv nginx libpq-dev python3-dev build-essential zip unzip
```

### 2. Create Application Directory

```bash
sudo mkdir -p /var/www/faceform
sudo chown $USER:$USER /var/www/faceform
cd /var/www/faceform
```

### 3. Upload and Extract Application Files

Upload the `faceform_deploy_vps.zip` file to your server using SCP or SFTP:

```bash
# From your local machine:
scp faceform_deploy_vps.zip user@92.113.145.171:/var/www/faceform/
scp faceform_deploy_vps_env.txt user@92.113.145.171:/var/www/faceform/
```

On the server, extract the files:

```bash
cd /var/www/faceform
unzip faceform_deploy_vps.zip
mv faceform_deploy_vps_env.txt .env
```

### 4. Set Up Python Environment

```bash
cd /var/www/faceform
python3 -m venv venv
source venv/bin/activate
pip install --upgrade pip
pip install -r requirements.txt
```

### 5. Configure Nginx

Edit the nginx configuration file:

```bash
sudo nano /etc/nginx/sites-available/faceform
```

Copy the content from the included `nginx_config.conf` file, making sure to update paths as needed.

Enable the site:

```bash
sudo ln -s /etc/nginx/sites-available/faceform /etc/nginx/sites-enabled/
sudo rm /etc/nginx/sites-enabled/default  # Optional: remove default site
sudo nginx -t  # Test configuration
sudo systemctl restart nginx
```

### 6. Set Up Systemd Service

Create a service file for the application:

```bash
sudo nano /etc/systemd/system/faceform.service
```

Add the following content:

```
[Unit]
Description=FaceForm Web Application
After=network.target

[Service]
User=www-data
Group=www-data
WorkingDirectory=/var/www/faceform
ExecStart=/var/www/faceform/venv/bin/gunicorn -c gunicorn_config.py main:app
Restart=always

[Install]
WantedBy=multi-user.target
```

Set proper permissions and start the service:

```bash
sudo chown -R www-data:www-data /var/www/faceform
sudo chmod +x /var/www/faceform/start.sh
sudo systemctl daemon-reload
sudo systemctl start faceform
sudo systemctl enable faceform
```

### 7. Configure Firewall

```bash
sudo ufw allow 'Nginx Full'
sudo ufw allow ssh
sudo ufw enable
```

### 8. Set Up SSL (Optional but Recommended)

Install Certbot and obtain an SSL certificate:

```bash
sudo apt install -y certbot python3-certbot-nginx
sudo certbot --nginx -d yourdomain.com
```

### 9. Test the Application

Visit your server IP address (92.113.145.171) in a web browser to verify the application is running correctly.

## Troubleshooting

If you encounter issues:

1. Check application logs:
   ```bash
   sudo journalctl -u faceform -f
   tail -f /var/www/faceform/error.log
   ```

2. Check nginx logs:
   ```bash
   sudo tail -f /var/log/nginx/error.log
   ```

3. Ensure all paths in nginx configuration are correct:
   ```bash
   sudo nano /etc/nginx/sites-available/faceform
   ```
   Update the `alias` directive for static files to point to the correct location.

4. Restart the application:
   ```bash
   sudo systemctl restart faceform
   ```

## Environment Variables

Make sure your `.env` file contains proper values for:

- `STRIPE_SECRET_KEY` - Your Stripe secret key
- `SESSION_SECRET` - A random string for session security
- `DATABASE_URL` - Optional, for PostgreSQL database (SQLite is used by default)

## Regular Maintenance

1. Keep the system updated:
   ```bash
   sudo apt update && sudo apt upgrade -y
   ```

2. Monitor logs regularly:
   ```bash
   sudo journalctl -u faceform -n 100
   ```

3. Back up the database regularly:
   ```bash
   cp /var/www/faceform/faceform_bot.db /var/backups/faceform_bot_$(date +%Y%m%d).db
   ```

4. Check disk space usage:
   ```bash
   df -h
   ```