#!/usr/bin/env python3
import os
import re
import time
import sys

print("==== Запуск полной очистки и исправления бота ====")

# 1. Останавливаем все процессы бота
print("\n[Шаг 1] Останавливаем все процессы бота")
os.system('sudo supervisorctl stop all')
time.sleep(2)
print("Все процессы остановлены")

# 2. Проверяем и убиваем любые оставшиеся процессы Python, связанные с ботом
print("\n[Шаг 2] Убиваем оставшиеся процессы")
os.system('pkill -f "python.*run_polling"')
os.system('pkill -f "python.*bot.py"')
time.sleep(1)
print("Все процессы очищены")

# 3. Создаем резервные копии файлов
print("\n[Шаг 3] Создаем резервные копии файлов")
os.system('cp face_analyzer.py face_analyzer.py.bak')
os.system('cp bot.py bot.py.bak')
print("Резервные копии созданы")

# 4. Исправляем файл face_analyzer.py
print("\n[Шаг 4] Исправляем визуализацию в face_analyzer.py")

# Читаем содержимое файла
with open('face_analyzer.py', 'r') as f:
    content = f.read()

# Удаляем вопросительные знаки напрямую
content = content.replace('"???"', '"Анализ лица"')
content = content.replace('"????????????????????"', '"Анализ пропорций лица"')
content = content.replace('"????????????????"', '"Анализ пропорций лица"')
content = content.replace('"???????????????"', '"Анализ пропорций лица"')
content = content.replace('"???????????????????????????????"', '"Анализ пропорций лица"')
content = content.replace('question_marks = "???" * 10', 'question_marks = "Анализ пропорций лица"')

# Записываем обновленный файл
with open('face_analyzer.py', 'w') as f:
    f.write(content)

print("Исправлены строки с вопросительными знаками")

# 5. Исправляем сообщения в bot.py
print("\n[Шаг 5] Улучшаем сообщения в bot.py")

# Читаем содержимое файла
with open('bot.py', 'r') as f:
    bot_content = f.read()

# Улучшаем сообщение при анализе фото
is_modified = False
process_photo_pattern = r'def process_photo\(self, message\):.*?except Exception as e:'
process_photo_match = re.search(process_photo_pattern, bot_content, re.DOTALL)

if process_photo_match:
    old_code = process_photo_match.group(0)
    # Проверяем, содержит ли код строки с caption
    if 'caption =' in old_code:
        # Заменяем caption на улучшенный вариант
        new_code = re.sub(
            r'caption = .*?(?=self\.bot\.send_photo|$)',
            '''caption = (
            f"✅ *Анализ завершен!*\\n\\n"
            f"📊 *Форма твоего лица: {face_shape}*\\n\\n"
            f"{face_shape_description}\\n\\n"
            f"💇‍♀️ *Рекомендуемые прически:*\\n{recommendations}\\n\\n"
            f"• Для виртуальной примерки прически, используй /try\\n"
            f"• Для просмотра всех доступных причесок, используй /hairstyles"
        )
        ''',
            old_code,
            flags=re.DOTALL
        )
        
        bot_content = bot_content.replace(old_code, new_code)
        is_modified = True
        print("Улучшено сообщение анализа в методе process_photo")

if not is_modified:
    print("Не удалось найти и изменить сообщение анализа, продолжаем без этого изменения")

# Записываем обновленный файл
with open('bot.py', 'w') as f:
    f.write(bot_content)

# 6. Перезапускаем только один экземпляр бота
print("\n[Шаг 6] Запускаем только один экземпляр бота (polling)")
os.system('sudo supervisorctl reread')
os.system('sudo supervisorctl update')
os.system('sudo supervisorctl start faceform_bot_polling')
time.sleep(2)

# 7. Проверяем статус
print("\n[Шаг 7] Проверяем статус бота")
os.system('sudo supervisorctl status')

print("\n==== Все исправления успешно применены ====")
print("Бот обновлен с улучшенным дизайном и без вопросительных знаков.")
print("Теперь работает только один экземпляр бота в режиме polling.")