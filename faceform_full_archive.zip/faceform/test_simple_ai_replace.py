import os
import logging
import requests
from lightx_client import LightXClient
from PIL import Image
import io

# Configure logging
logging.basicConfig(level=logging.INFO, 
                   format='%(asctime)s - %(name)s - %(levelname)s - %(message)s')
logger = logging.getLogger(__name__)

def create_simple_white_mask(image_data):
    """
    Создает простую белую маску для тестирования API Replace
    
    Args:
        image_data (bytes): Данные изображения
        
    Returns:
        bytes: Данные маски или None в случае ошибки
    """
    try:
        # Загружаем изображение
        input_buffer = io.BytesIO(image_data)
        with Image.open(input_buffer) as img:
            width, height = img.size
            # Создаем белую маску
            mask = Image.new('L', (width, height), 255)
            mask_buffer = io.BytesIO()
            mask.save(mask_buffer, format='JPEG')
            mask_buffer.seek(0)
            return mask_buffer.read()
    except Exception as e:
        logger.error(f"Ошибка при создании маски: {e}")
        return None

def test_ai_replace():
    """Простое тестирование функции замены элементов LightX API Replace"""
    logger.info("=== Простое тестирование функции AI Replace ===")
    
    # Инициализация клиента LightX
    lightx_client = LightXClient()
    
    # Проверка наличия API ключа
    if not lightx_client.api_key:
        logger.error("API ключ LightX не найден")
        return False
    
    # Загрузка тестового изображения
    test_image_path = "./demo_base_face.jpg"
    if not os.path.exists(test_image_path):
        logger.error(f"Тестовое изображение не найдено: {test_image_path}")
        return False
    
    with open(test_image_path, "rb") as f:
        image_data = f.read()
    
    # Создание простой белой маски
    mask_data = create_simple_white_mask(image_data)
    if not mask_data:
        logger.error("Не удалось создать маску")
        return False
    
    # Текстовый запрос для замены элементов
    text_prompt = "replace background with blue color"
    
    # Явный вызов метода загрузки изображений
    logger.info("Загрузка основного изображения...")
    image_url = lightx_client.upload_image(image_data)
    if not image_url:
        logger.error("Не удалось загрузить основное изображение")
        return False
    
    logger.info(f"Изображение загружено: {image_url}")
    
    logger.info("Загрузка маски...")
    mask_url = lightx_client.upload_image(mask_data)
    if not mask_url:
        logger.error("Не удалось загрузить маску")
        return False
    
    logger.info(f"Маска загружена: {mask_url}")
    
    # Подготовка данных запроса
    data = {
        "imageUrl": image_url,
        "maskedImageUrl": mask_url,
        "textPrompt": text_prompt
    }
    
    # Подготовка заголовков
    headers = {
        "Content-Type": "application/json",
        "x-api-key": lightx_client.api_key
    }
    
    # Отправка запроса
    logger.info(f"Отправка запроса к API Replace: {data}")
    response = requests.post(lightx_client.replace_url, headers=headers, json=data)
    
    # Проверка ответа
    if response.status_code != 200:
        logger.error(f"Ошибка запроса: {response.status_code} - {response.text}")
        return False
    
    # Анализ ответа
    result = response.json()
    logger.info(f"Ответ API: {result}")
    
    # Проверка статуса
    if result.get("statusCode") != 2000 or "body" not in result:
        logger.error(f"Неверный ответ от API: {result}")
        return False
    
    # Получение ID заказа
    order_id = result["body"].get("orderId")
    if not order_id:
        logger.error("Отсутствует ID заказа в ответе")
        return False
    
    logger.info(f"Заказ создан с ID: {order_id}")
    
    # Ожидание результата
    output_url = lightx_client.wait_for_result(order_id, max_retries=10, retry_interval=2)
    if not output_url:
        logger.error(f"Не удалось получить результат для заказа {order_id}")
        return False
    
    logger.info(f"Получен URL результата: {output_url}")
    
    # Загрузка результата
    response = requests.get(output_url)
    if response.status_code != 200:
        logger.error(f"Не удалось загрузить результат: {response.status_code}")
        return False
    
    # Сохранение результата
    output_path = "test_simple_ai_replace_result.jpg"
    with open(output_path, "wb") as f:
        f.write(response.content)
    
    logger.info(f"Результат сохранен в файл: {output_path}")
    return True

if __name__ == "__main__":
    success = test_ai_replace()
    if success:
        logger.info("✅ Тест успешно выполнен!")
    else:
        logger.error("❌ Тест не выполнен!")