import os
import logging
import requests
import random
import time
from datetime import datetime, timedelta

# Настройка логирования
logging.basicConfig(level=logging.INFO, 
                    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s')
logger = logging.getLogger(__name__)

class LightXKeyManager:
    """
    Менеджер API ключей LightX с поддержкой ротации ключей при ошибках.
    Позволяет автоматически переключаться между ключами при исчерпании лимитов.
    """
    
    def __init__(self, initial_key=None):
        """
        Инициализация менеджера ключей.
        
        Args:
            initial_key (str, optional): Начальный ключ API. Если None, берется из переменных окружения.
        """
        # API ключи (резервные)
        self.api_keys = [
            "33dc337eefda49ab92fd29f43da336bf_ac9ec1f895af47948c32513640a0136a_andoraitools",
            "4e0057d083f3420dbe043d00c1986d9a_d7d8ea58f693480cba99ebcbc9998bc5_andoraitools",
            "d7d8e6a124b94ae2a1369229e247f920_aad315a2e1f64b778c49cf8b75d7a413_andoraitools",
            "ee03d7f4abbe489ebf52f6a6898a2e58_1bf285878c8a4950bca2d0e28ce08a27_andoraitools",
            "2614471723e34e30a5c53ab682c88c52_415cd730394e4aedb0c7c377890321c7_andoraitools",
            "b9043dfb51af4e3d9a787bb7e6858ece_9814ff95790f49e6b23ca71195799f3f_andoraitools"
        ]
        
        # Сохраняем текущий ключ и историю использования
        self.current_key = initial_key or os.environ.get("LIGHTX_API_KEY")
        if not self.current_key or self.current_key not in self.api_keys:
            # Если текущий ключ не задан или не из списка, используем первый из списка
            self.current_key = self.api_keys[0]
        
        # Мапа для отслеживания статуса ключей (ключ -> {последняя ошибка, счетчик ошибок, время блокировки})
        self.key_status = {}
        for key in self.api_keys:
            self.key_status[key] = {
                "error_count": 0,  # счетчик последовательных ошибок
                "last_error": None,  # последний код ошибки
                "blocked_until": None,  # время блокировки ключа
                "success_count": 0,  # счетчик успешных вызовов
                "total_requests": 0  # общее количество запросов
            }
        
        logger.info(f"LightX Key Manager инициализирован с {len(self.api_keys)} ключами")
        
    def get_current_key(self):
        """
        Возвращает текущий активный API ключ.
        
        Returns:
            str: Текущий API ключ
        """
        return self.current_key
    
    def mark_request_success(self, key=None):
        """
        Отмечает успешный запрос для указанного ключа.
        
        Args:
            key (str, optional): API ключ. Если None, используется текущий.
        """
        key = key or self.current_key
        if key in self.key_status:
            self.key_status[key]["error_count"] = 0  # сбрасываем счетчик ошибок
            self.key_status[key]["success_count"] += 1
            self.key_status[key]["total_requests"] += 1
    
    def mark_request_error(self, error_code, key=None):
        """
        Отмечает ошибку запроса для указанного ключа.
        
        Args:
            error_code (int): Код ошибки HTTP
            key (str, optional): API ключ. Если None, используется текущий.
            
        Returns:
            bool: True если ключ нужно сменить, False если можно продолжать использовать
        """
        key = key or self.current_key
        if key not in self.key_status:
            return True  # неизвестный ключ, лучше заменить
        
        status = self.key_status[key]
        status["last_error"] = error_code
        status["error_count"] += 1
        status["total_requests"] += 1
        
        # Определяем, нужно ли блокировать ключ и на какое время
        if error_code == 403:  # Forbidden - ключ, скорее всего, истек или исчерпал лимит
            # Блокируем надолго (8 часов)
            status["blocked_until"] = datetime.now() + timedelta(hours=8)
            # Безопасное отображение ключа
            try:
                key_str = str(key)
                key_display = key_str[:8] + "..." if key and len(key_str) > 8 else key_str
            except:
                key_display = "[недоступен]"
            logger.warning(f"Ключ {key_display} заблокирован на 8 часов из-за ошибки 403 Forbidden")
            return True
        elif error_code == 429:  # Too Many Requests - превышен лимит запросов
            # Блокируем на 15 минут
            status["blocked_until"] = datetime.now() + timedelta(minutes=15)
            # Безопасное отображение ключа
            try:
                key_str = str(key)
                key_display = key_str[:8] + "..." if key and len(key_str) > 8 else key_str
            except:
                key_display = "[недоступен]"
            logger.warning(f"Ключ {key_display} заблокирован на 15 минут из-за ошибки 429 Too Many Requests")
            return True
        elif error_code >= 500:  # Серверные ошибки
            # Блокируем на короткое время (2 минуты)
            if status["error_count"] >= 3:  # если это третья подряд ошибка для этого ключа
                status["blocked_until"] = datetime.now() + timedelta(minutes=2)
                # Безопасное отображение ключа
                try:
                    key_str = str(key)
                    key_display = key_str[:8] + "..." if key and len(key_str) > 8 else key_str
                except:
                    key_display = "[недоступен]"
                logger.warning(f"Ключ {key_display} заблокирован на 2 минуты из-за повторяющихся серверных ошибок")
                return True
        
        # Для остальных ошибок, если их много подряд, тоже меняем ключ
        if status["error_count"] >= 5:
            status["blocked_until"] = datetime.now() + timedelta(minutes=5)
            # Безопасное отображение ключа
            try:
                key_str = str(key)
                key_display = key_str[:8] + "..." if key and len(key_str) > 8 else key_str
            except:
                key_display = "[недоступен]"
            logger.warning(f"Ключ {key_display} заблокирован на 5 минут из-за {status['error_count']} последовательных ошибок")
            return True
        
        return False  # можно продолжать использовать ключ
    
    def is_key_blocked(self, key=None):
        """
        Проверяет, заблокирован ли ключ.
        
        Args:
            key (str, optional): API ключ. Если None, используется текущий.
            
        Returns:
            bool: True если ключ заблокирован, False если можно использовать
        """
        key = key or self.current_key
        if key not in self.key_status:
            return False
        
        blocked_until = self.key_status[key]["blocked_until"]
        if blocked_until and datetime.now() < blocked_until:
            return True
        
        # Если время блокировки прошло, сбрасываем его
        if blocked_until:
            self.key_status[key]["blocked_until"] = None
        
        return False
    
    def switch_to_next_key(self):
        """
        Переключается на следующий доступный ключ.
        
        Returns:
            str: Новый API ключ или None если все ключи заблокированы
        """
        # Перемешиваем ключи для равномерности использования
        available_keys = [k for k in self.api_keys if not self.is_key_blocked(k)]
        
        if not available_keys:
            # Если все ключи заблокированы, выбираем тот, который скоро разблокируется
            soon_available = []
            for k in self.api_keys:
                blocked_until = self.key_status.get(k, {}).get("blocked_until")
                if blocked_until:
                    soon_available.append((k, blocked_until))
            
            # Сортируем по времени разблокировки
            if soon_available:
                soon_available.sort(key=lambda x: x[1])
                next_key = soon_available[0][0]
                wait_time = (soon_available[0][1] - datetime.now()).total_seconds()
                logger.warning(f"Все ключи заблокированы. Выбран ключ, который разблокируется через {int(wait_time)} секунд")
                # Пытаемся использовать ключ с наименьшим временем ожидания
                self.current_key = next_key
                return next_key
            
            logger.error("Все API ключи заблокированы и нет информации о времени разблокировки!")
            return None
        
        # Выбираем случайный ключ из доступных, исключая текущий
        available_keys = [k for k in available_keys if k != self.current_key]
        if not available_keys:
            # Если доступен только текущий ключ, продолжаем его использовать
            return self.current_key
        
        # Выбираем случайный ключ
        next_key = random.choice(available_keys)
        # Безопасное отображение ключа
        try:
            key_str = str(next_key)
            key_display = key_str[:8] + "..." if next_key and len(key_str) > 8 else key_str
        except:
            key_display = "[недоступен]"
        logger.info(f"Переключение на новый API ключ: {key_display}")
        self.current_key = next_key
        return next_key
    
    def handle_response(self, response, key=None):
        """
        Обрабатывает ответ API и решает, нужна ли смена ключа.
        
        Args:
            response (requests.Response): Ответ API
            key (str, optional): API ключ. Если None, используется текущий.
            
        Returns:
            tuple: (нужна ли смена ключа, новый ключ)
        """
        key = key or self.current_key
        
        # Проверяем ответ на содержание ошибки API_CREDITS_CONSUMED
        api_credits_consumed = False
        try:
            # Проверяем текст ответа на наличие строки API_CREDITS_CONSUMED
            if "API_CREDITS_CONSUMED" in response.text:
                api_credits_consumed = True
                logger.warning(f"Обнаружено исчерпание кредитов API в ответе для ключа {key[:8]}...")
            
            # Дополнительно проверяем JSON на наличие соответствующего кода ошибки
            if response.status_code == 200:
                json_data = response.json()
                if isinstance(json_data, dict):
                    status_code = json_data.get("statusCode")
                    message = str(json_data.get("message", ""))
                    
                    if status_code == 5040 or "API_CREDITS_CONSUMED" in message:
                        api_credits_consumed = True
                        logger.warning(f"Обнаружено исчерпание кредитов API в JSON ответе для ключа {key[:8]}...")
        except Exception as e:
            logger.error(f"Ошибка при проверке JSON ответа: {e}")
        
        # Если обнаружено исчерпание кредитов API, блокируем ключ на длительное время
        if api_credits_consumed:
            # Используем код 403 для длительной блокировки
            self.mark_request_error(403, key)
            # Пытаемся переключиться на следующий ключ
            new_key = self.switch_to_next_key()
            if new_key is None:
                # Если не удалось получить новый ключ, используем текущий
                return False, key
            return True, new_key
        
        # Стандартная проверка на основе кода ответа HTTP
        if response.status_code == 200:
            # Запрос успешен (и нет ошибки исчерпания кредитов в JSON)
            self.mark_request_success(key)
            return False, key
        else:
            # Произошла ошибка HTTP
            needs_switch = self.mark_request_error(response.status_code, key)
            if needs_switch:
                # Пытаемся переключиться на следующий ключ
                new_key = self.switch_to_next_key()
                if new_key is None:
                    # Если не удалось получить новый ключ, используем текущий
                    return False, key
                return True, new_key
            return False, key
    
    def test_current_key(self):
        """
        Проверяет работоспособность текущего ключа через простой API запрос.
        
        Returns:
            bool: True если ключ работает, False если нет
        """
        # Тестовый запрос к API (простой эндпоинт, не потребляющий много ресурсов)
        try:
            if not self.current_key:
                logger.error("Текущий ключ не установлен")
                return False
                
            url = "https://api.lightxeditor.com/external/api/v1/order-status"
            headers = {
                "Content-Type": "application/json",
                "x-api-key": self.current_key
            }
            data = {"orderId": "test-order-id"}  # Несуществующий ID для проверки аутентификации
            
            response = requests.post(url, headers=headers, json=data, timeout=5)
            
            # Коротка версия ключа для логов
            try:
                key_str = str(self.current_key)
                key_display = key_str[:8] + "..." if self.current_key and len(key_str) > 8 else key_str
            except:
                key_display = "[недоступен]"
            
            # Если код 401 или 404, это нормально для неправильного orderId,
            # главное, что нет 403 (Forbidden) из-за проблем с ключом
            if response.status_code not in [403, 429, 500, 502, 503, 504]:
                logger.info(f"Тест ключа API успешен: {key_display}")
                return True
            else:
                logger.warning(f"Тест ключа API не пройден: {response.status_code} - {response.text}")
                # Отмечаем ошибку и переключаемся на другой ключ
                self.mark_request_error(response.status_code)
                self.switch_to_next_key()
                return False
                
        except Exception as e:
            logger.error(f"Ошибка при тестировании ключа API: {e}")
            return False
    
    def get_key_stats(self):
        """
        Возвращает статистику использования ключей.
        
        Returns:
            dict: Статистика использования ключей
        """
        stats = {}
        for key, status in self.key_status.items():
            try:
                key_str = str(key)
                key_short = key_str[:8] + "..." if key and len(key_str) > 8 else key_str
            except:
                key_short = "None"
            success_count = status.get("success_count", 0)
            total_requests = status.get("total_requests", 0)
            blocked_until = status.get("blocked_until")
            
            stats[key_short] = {
                "success_rate": round(success_count / max(1, total_requests) * 100, 2),
                "total_requests": total_requests,
                "blocked": blocked_until is not None,
                "blocked_until": blocked_until.strftime("%Y-%m-%d %H:%M:%S") if blocked_until else None,
                "active": key == self.current_key
            }
        return stats
        
    def test_all_keys(self):
        """
        Тестирует все доступные ключи и возвращает их статус.
        
        Returns:
            dict: Статус каждого ключа (True - работает, False - не работает)
        """
        results = {}
        for key in self.api_keys:
            try:
                # Сохраняем текущий ключ
                current_key = self.current_key
                
                # Временно устанавливаем тестируемый ключ
                self.current_key = key
                
                # Выполняем тест
                result = self.test_current_key()
                
                # Безопасное отображение ключа
                try:
                    key_str = str(key)
                    key_display = key_str[:8] + "..." if key and len(key_str) > 8 else key_str
                except:
                    key_display = "[недоступен]"
                
                results[key_display] = result
                
                # Восстанавливаем исходный ключ
                self.current_key = current_key
                
            except Exception as e:
                logger.error(f"Ошибка при тестировании ключа: {e}")
                results[key_display] = False
                
        return results