import cv2
import numpy as np
import mediapipe as mp
import logging
import os
from config import FACE_SHAPE_CRITERIA, HAIRSTYLE_RECOMMENDATIONS
from perfectcorp_client import PerfectCorpClient
from lightx_client import LightXClient

# Configure logging
logging.basicConfig(level=logging.INFO, 
                   format='%(asctime)s - %(name)s - %(levelname)s - %(message)s')
logger = logging.getLogger(__name__)

class FaceAnalyzer:
    def __init__(self):
        # Initialize MediaPipe Face Mesh
        self.mp_face_mesh = mp.solutions.face_mesh
        self.face_mesh = self.mp_face_mesh.FaceMesh(
            static_image_mode=True,
            max_num_faces=1,
            min_detection_confidence=0.5
        )
        
        # Инициализируем атрибут landmarks
        self.landmarks = None
        
        # Initialize LightX API client if API key is available
        if os.environ.get("LIGHTX_API_KEY"):
            try:
                self.lightx_client = LightXClient()
                self.use_lightx = True
                logger.info("LightX API client initialized successfully")
            except Exception as e:
                logger.error(f"Failed to initialize LightX client: {e}")
                self.use_lightx = False
        else:
            logger.warning("LightX API key not found, LightX hairstyle generation disabled")
            self.use_lightx = False
        
        # Initialize PerfectCorp API client if API key is available
        if os.environ.get("PERFECTCORP_YCE_API_KEY"):
            try:
                self.perfectcorp_client = PerfectCorpClient()
                self.use_perfectcorp = True
                logger.info("PerfectCorp YCE API client initialized successfully")
            except Exception as e:
                logger.error(f"Failed to initialize PerfectCorp client: {e}")
                self.use_perfectcorp = False
        else:
            logger.warning("PerfectCorp YCE API key not found, PerfectCorp hairstyle try-on disabled")
            self.use_perfectcorp = False
        
    def analyze_face_shape(self, image_data):
        """
        Analyze face shape using facial landmarks from MediaPipe
        
        Args:
            image_data: Image bytes
            
        Returns:
            tuple: (face_shape, visualization_image, measurements)
            
        Note:
            This method also sets self.landmarks with the detected landmarks
            for later use by other methods in the class.
        """
        # Сбрасываем landmarks перед новым анализом
        self.landmarks = None
        try:
            # Convert image bytes to numpy array
            nparr = np.frombuffer(image_data, np.uint8)
            image = cv2.imdecode(nparr, cv2.IMREAD_COLOR)
            
            # Convert to RGB for MediaPipe
            image_rgb = cv2.cvtColor(image, cv2.COLOR_BGR2RGB)
            
            # Process the image to get facial landmarks
            results = self.face_mesh.process(image_rgb)
            
            # Check if a face was detected
            if not results.multi_face_landmarks:
                return None, None, None
                
            # Get the first face detected
            face_landmarks = results.multi_face_landmarks[0]
            
            # Extract key measurements from landmarks
            height, width, _ = image.shape
            landmarks = []
            for landmark in face_landmarks.landmark:
                x, y = int(landmark.x * width), int(landmark.y * height)
                landmarks.append((x, y))
            
            # Get key facial measurements
            # Forehead width (between temples)
            forehead_left = landmarks[67]
            forehead_right = landmarks[296]
            forehead_width = self._calculate_distance(forehead_left, forehead_right)
            
            # Jawline width
            jaw_left = landmarks[172]
            jaw_right = landmarks[397]
            jawline_width = self._calculate_distance(jaw_left, jaw_right)
            
            # Cheekbone width
            cheek_left = landmarks[123]
            cheek_right = landmarks[352]
            cheekbone_width = self._calculate_distance(cheek_left, cheek_right)
            
            # Face length (from chin to forehead)
            forehead_middle = landmarks[10]
            chin_point = landmarks[152]
            face_length = self._calculate_distance(forehead_middle, chin_point)
            
            # Calculate ratios
            width_to_length_ratio = cheekbone_width / face_length
            forehead_to_jawline_ratio = forehead_width / jawline_width
            cheekbone_to_jawline_ratio = cheekbone_width / jawline_width
            
            # Determine face shape based on ratios
            face_shape = self._determine_face_shape(
                width_to_length_ratio,
                forehead_to_jawline_ratio,
                cheekbone_to_jawline_ratio
            )
            
            # Create visualization based on determined face shape
            vis_image = self._create_custom_visualization(image.copy(), landmarks, face_shape)
            
            # Measurements for debugging and visualization
            measurements = {
                "width_to_length_ratio": width_to_length_ratio,
                "forehead_to_jawline_ratio": forehead_to_jawline_ratio,
                "cheekbone_to_jawline_ratio": cheekbone_to_jawline_ratio,
            }
            
            # Сохраняем landmarks для использования другими функциями
            self.landmarks = landmarks
            logger.info(f"Saved {len(landmarks)} landmarks for later use")
            
            # Encode the visualization image
            _, buffer = cv2.imencode('.jpg', vis_image)
            vis_image_bytes = buffer.tobytes()
            
            return face_shape, vis_image_bytes, measurements
            
        except Exception as e:
            print(f"Error in analyzing face: {e}")
            return None, None, None
            
    def _create_custom_visualization(self, image, landmarks, face_shape):
        """
        Create a custom visualization for the specific face shape
        
        Args:
            image: Original image
            landmarks: Face landmarks
            face_shape: Determined face shape
            
        Returns:
            Image with custom visualization
        """
        # Define colors for different face shapes (BGR format)
        shape_colors = {
            "OVAL": (0, 200, 0),       # Green
            "ROUND": (0, 165, 255),    # Orange
            "SQUARE": (255, 0, 0),     # Blue
            "HEART": (130, 0, 255),    # Purple
            "OBLONG": (255, 255, 0),   # Cyan
            "DIAMOND": (0, 0, 255)     # Red
        }
        
        # Get color for current face shape
        color = shape_colors.get(face_shape, (0, 200, 0))
        
        # Create a transparent overlay for the face mesh
        overlay = image.copy()
        mesh_overlay = image.copy()
        
        # Create a mask for important landmarks based on face shape
        if face_shape == "OVAL":
            # For oval face, highlight the oval shape
            # Draw key points with small circles
            key_points = [8, 10, 67, 296, 152, 123, 352, 172, 397]
            for idx in key_points:
                cv2.circle(overlay, landmarks[idx], 2, color, -1)
                
        elif face_shape == "ROUND":
            # For round face, highlight the circular shape
            # Emphasize the cheekbones and jawline
            key_points = [8, 10, 123, 352, 172, 397, 152]
            for idx in key_points:
                cv2.circle(overlay, landmarks[idx], 2, color, -1)
                
        elif face_shape == "SQUARE":
            # For square face, highlight the angular jawline
            # Draw more points along jawline
            key_points = [172, 140, 169, 170, 171, 175, 396, 369, 396, 397, 288, 397]
            for idx in key_points:
                if idx < len(landmarks):  # Check if index is valid
                    cv2.circle(overlay, landmarks[idx], 2, color, -1)
                    
        elif face_shape == "HEART":
            # For heart face, highlight the wider forehead and narrower jawline
            key_points = [10, 67, 296, 152, 172, 397]
            for idx in key_points:
                cv2.circle(overlay, landmarks[idx], 2, color, -1)
                
        elif face_shape == "OBLONG":
            # For oblong face, highlight the length
            key_points = [10, 8, 152, 123, 352]
            for idx in key_points:
                cv2.circle(overlay, landmarks[idx], 2, color, -1)
                
        elif face_shape == "DIAMOND":
            # For diamond face, highlight the cheekbones
            key_points = [10, 123, 352, 152]
            for idx in key_points:
                cv2.circle(overlay, landmarks[idx], 2, color, -1)
        
        # Draw face mesh with semi-transparency
        connections = self.mp_face_mesh.FACEMESH_TESSELATION
        for connection in connections:
            start_idx = connection[0]
            end_idx = connection[1]
            if start_idx < len(landmarks) and end_idx < len(landmarks):
                # Полупрозрачная линия
                cv2.line(mesh_overlay, landmarks[start_idx], landmarks[end_idx], color, 1)
        
        # Add transparent mesh overlay (30% opacity)
        cv2.addWeighted(mesh_overlay, 0.3, image, 0.7, 0, image)
        
        # Add text showing the detected face shape
        face_shape_text = FACE_SHAPE_CRITERIA[face_shape]["description"]
        
        # Создаем черную подложку для текста, чтобы он был лучше виден
        text_size = cv2.getTextSize(face_shape_text, cv2.FONT_HERSHEY_SIMPLEX, 1, 2)[0]
        cv2.rectangle(image, (10, 10), (10 + text_size[0], 40), (0, 0, 0), -1)
        
        # Добавляем текст
        cv2.putText(image, face_shape_text, (10, 35), cv2.FONT_HERSHEY_SIMPLEX, 1, color, 2)
        
        return image
            
    def _calculate_distance(self, point1, point2):
        """Calculate Euclidean distance between two points"""
        return np.sqrt((point1[0] - point2[0])**2 + (point1[1] - point2[1])**2)
        
    def apply_hairstyle(self, image_data, landmarks=None, face_shape=None, hairstyle_index=0):
        """
        Apply virtual hairstyle try-on based on face shape using LightX API
        
        Args:
            image_data (bytes): Original image data
            landmarks (list, optional): Facial landmarks from MediaPipe
            face_shape (str, optional): The determined face shape
            hairstyle_index (int): Index of the hairstyle to apply
            
        Returns:
            bytes: Image with hairstyle overlay applied or original image if there's an error
        """
        try:
            # Проверяем входные данные
            if not image_data:
                logger.error("No image data provided")
                return None
                
            # Если лицевые ориентиры не переданы, пытаемся проанализировать их
            if landmarks is None:
                logger.warning("No landmarks provided, trying to analyze face")
                try:
                    # Сохраняем текущие landmarks, если они есть
                    old_landmarks = self.landmarks if hasattr(self, 'landmarks') else None
                    
                    # Анализируем лицо для получения landmarks
                    # Если face_shape не указана, эта функция также определит её
                    temp_face_shape, _, _ = self.analyze_face_shape(image_data)
                    
                    # Если у нас теперь есть landmarks, используем их
                    if hasattr(self, 'landmarks') and self.landmarks is not None:
                        landmarks = self.landmarks
                        logger.info("Successfully obtained landmarks from face analysis")
                        
                        # Если face_shape не была передана, используем только что определенную
                        if not face_shape:
                            face_shape = temp_face_shape
                    else:
                        logger.warning("Could not obtain landmarks from face analysis")
                except Exception as e:
                    logger.error(f"Error analyzing face to obtain landmarks: {e}")
                    
            # Если face_shape не указана, пытаемся определить её
            if not face_shape:
                logger.warning("No face shape specified, trying to analyze face shape")
                try:
                    face_shape, _, _ = self.analyze_face_shape(image_data)
                    if not face_shape:
                        logger.error("Could not determine face shape")
                        return image_data
                except Exception as e:
                    logger.error(f"Error determining face shape: {e}")
                    return image_data
            
            # First try LightX API if available
            if self.use_lightx:
                try:
                    # Get hairstyle prompts for this face shape
                    hairstyle_prompts = self.lightx_client.get_hairstyle_prompts_by_face_shape(face_shape)
                    
                    if hairstyle_prompts:
                        # Make sure index is valid
                        if hairstyle_index >= len(hairstyle_prompts):
                            hairstyle_index = 0
                            
                        # Get selected hairstyle prompt
                        hairstyle = hairstyle_prompts[hairstyle_index]
                        hairstyle_prompt = hairstyle.get("prompt") if isinstance(hairstyle, dict) else None
                        
                        if not hairstyle_prompt:
                            logger.error("No hairstyle prompt found")
                            raise ValueError("Missing hairstyle prompt")
                        
                        logger.info(f"Applying hairstyle with LightX API: {hairstyle.get('name', 'Unknown')}")
                        
                        # ВАЖНО: Здесь API ожидает стиль в параметре prompt, а не style
                        # Исправим это и гарантируем, что API получит правильный параметр
                        if isinstance(hairstyle, dict) and "style" in hairstyle:
                            hairstyle_prompt = hairstyle["style"]
                            logger.info(f"Using hairstyle style: {hairstyle_prompt}")
                        
                        # Добавим логирование
                        logger.info(f"Sending image ({len(image_data)} bytes) to LightX API with prompt: {hairstyle_prompt}")
                        
                        # Apply the hairstyle using LightX API
                        result_image_bytes = self.lightx_client.apply_hairstyle(image_data, hairstyle_prompt)
                        
                        if result_image_bytes:
                            logger.info(f"Successfully generated hairstyle with LightX API. Result size: {len(result_image_bytes)} bytes")
                            return result_image_bytes
                        else:
                            logger.warning("LightX API returned no result, falling back to alternatives")
                except Exception as e:
                    logger.error(f"Error applying hairstyle via LightX API: {e}")
                    # Continue to next method if LightX fails
            
            # Try PerfectCorp API as a fallback
            if self.use_perfectcorp:
                try:
                    # Get hairstyles for this face shape
                    hairstyles = self.perfectcorp_client.get_hairstyles_by_face_shape(face_shape)
                    
                    if hairstyles:
                        # Make sure index is valid
                        if hairstyle_index >= len(hairstyles):
                            hairstyle_index = 0
                            
                        # Get hairstyle ID
                        hairstyle = hairstyles[hairstyle_index]
                        hairstyle_id = hairstyle.get("id") if isinstance(hairstyle, dict) else None
                        
                        logger.info(f"Applying hairstyle with PerfectCorp API (fallback): {hairstyle.get('name', 'Unknown')}")
                        
                        # Apply the hairstyle using PerfectCorp API
                        result_image_bytes = self.perfectcorp_client.apply_hairstyle(image_data, hairstyle_id)
                        
                        if result_image_bytes:
                            return result_image_bytes
                except Exception as e:
                    logger.error(f"Error applying hairstyle via PerfectCorp API: {e}")
            
            # If both APIs are unavailable or failed, create a demonstration image
            logger.info("All APIs failed, creating demo hairstyle visualization")
            try:
                demo_image = self._create_demo_hairstyle_image(image_data, face_shape, hairstyle_index)
                if demo_image:
                    return demo_image
            except Exception as e:
                logger.error(f"Error creating demo visualization: {e}")
            
            # If everything else fails, return the original image
            logger.warning("Returning original image as fallback")
            return image_data
                
        except Exception as e:
            logger.error(f"Error applying hairstyle: {e}")
            return image_data  # Return original image if there's an error
            
    def _create_demo_hairstyle_image(self, image_data, face_shape, hairstyle_index=0):
        """
        Create a demonstration image with hairstyle information overlay
        
        Args:
            image_data (bytes): Original image data
            face_shape (str): Face shape
            hairstyle_index (int): Index of the hairstyle
            
        Returns:
            bytes: Modified image with hairstyle information
        """
        try:
            # Получаем список причесок для этой формы лица
            hairstyles = self._get_demo_hairstyles(face_shape)
            
            # Проверяем валидность индекса
            if hairstyle_index >= len(hairstyles):
                hairstyle_index = 0
                
            # Получаем выбранную прическу
            hairstyle = hairstyles[hairstyle_index]
            hairstyle_name = hairstyle.get("name", f"Прическа {hairstyle_index+1}")
            
            # Конвертируем изображение в numpy array
            import numpy as np
            import cv2
            from PIL import Image, ImageDraw, ImageFont
            import io
            
            # Преобразуем байты в изображение
            nparr = np.frombuffer(image_data, np.uint8)
            img = cv2.imdecode(nparr, cv2.IMREAD_COLOR)
            
            # Создаем копию изображения для наложения информации
            result_img = img.copy()
            
            # Получаем размеры изображения
            height, width, _ = result_img.shape
            
            # Создаем область в верхней части изображения для текста
            text_area_height = 60
            text_overlay = np.zeros((text_area_height, width, 3), dtype=np.uint8)
            text_overlay[:, :] = (255, 255, 255)  # Белый фон
            
            # Добавляем текст с названием прически
            font = cv2.FONT_HERSHEY_SIMPLEX
            cv2.putText(text_overlay, f"Демонстрация: {hairstyle_name}", 
                       (10, 30), font, 0.7, (0, 0, 0), 2)
            
            # Создаем рамку вокруг изображения
            border_size = 3
            bordered_img = cv2.copyMakeBorder(result_img, 0, 0, border_size, border_size, 
                                            cv2.BORDER_CONSTANT, value=(0, 180, 255))
            
            # Убедимся, что обе части изображения имеют одинаковую ширину
            if text_overlay.shape[1] != bordered_img.shape[1]:
                logger.info(f"Размеры не совпадают: текст {text_overlay.shape}, изображение {bordered_img.shape}")
                # Изменяем размер текстового наложения в соответствии с шириной изображения
                text_overlay = cv2.resize(text_overlay, (bordered_img.shape[1], text_overlay.shape[0]))
                logger.info(f"После изменения размера: текст {text_overlay.shape}, изображение {bordered_img.shape}")
            
            # Объединяем текстовую область с изображением
            final_img = np.vstack((text_overlay, bordered_img))
            
            # Сохраняем результат в буфер
            is_success, buffer = cv2.imencode(".jpg", final_img)
            if not is_success:
                logger.error("Failed to encode result image")
                return image_data
                
            # Возвращаем байты
            return buffer.tobytes()
            
        except Exception as e:
            logger.error(f"Error creating demo hairstyle image: {e}")
            return image_data
    
    def get_available_hairstyles(self, face_shape_param, gender_param=None):
        """
        Get list of available hairstyles for a face shape with optional gender filtering
        
        Args:
            face_shape_param (str): The determined face shape
            gender_param (str, optional): Gender filter ("male" or "female")
            
        Returns:
            list: List of hairstyle objects with id, name, etc.
        """
        # Для обратной совместимости
        face_shape = face_shape_param
        gender = gender_param
        try:
            # Сначала пробуем использовать LightX API, если он доступен
            if self.use_lightx:
                try:
                    # Получаем прически от LightX API c фильтрацией по полу, если указан
                    hairstyles = self.lightx_client.get_hairstyle_prompts_by_face_shape(face_shape, gender)
                    if hairstyles:
                        logger.info(f"Using {len(hairstyles)} hairstyles from LightX API for face shape {face_shape}" +
                                  (f" and gender {gender}" if gender else ""))
                        return hairstyles
                except Exception as e:
                    logger.error(f"Error getting hairstyles from LightX API: {e}")
            
            # Если LightX API недоступен или произошла ошибка, пробуем PerfectCorp API
            if self.use_perfectcorp:
                try:
                    # Тут нет фильтрации по полу, так как старый API perfectcorp не поддерживает это
                    hairstyles = self.perfectcorp_client.get_hairstyles_by_face_shape(face_shape)
                    if hairstyles:
                        # Попытка ручной фильтрации, если указан пол
                        if gender:
                            gender_marker = "мужск" if gender == "male" else "женск"
                            filtered_hairstyles = [h for h in hairstyles if gender_marker.lower() in h.get("name", "").lower()]
                            if filtered_hairstyles:
                                logger.info(f"Filtered {len(filtered_hairstyles)}/{len(hairstyles)} hairstyles by gender {gender}")
                                hairstyles = filtered_hairstyles
                                
                        logger.info(f"Using {len(hairstyles)} hairstyles from PerfectCorp API")
                        return hairstyles
                except Exception as e:
                    logger.error(f"Error getting hairstyles from PerfectCorp API: {e}")
                    
            # Если оба API недоступны или произошла ошибка, используем локальные демонстрационные прически
            logger.info(f"Using demo hairstyles for {face_shape}" + (f" and gender {gender}" if gender else ""))
            return self._get_demo_hairstyles(face_shape, gender)
                
        except Exception as e:
            logger.error(f"Error getting hairstyles: {e}")
            # В случае ошибки тоже используем демонстрационные прически
            return self._get_demo_hairstyles(face_shape, gender)
            
    def _get_demo_hairstyles(self, face_shape, gender=None):
        """
        Get demo hairstyles for a specific face shape when API is not available
        
        Args:
            face_shape (str): The determined face shape (OVAL, ROUND, SQUARE, etc.)
            gender (str, optional): Gender filter ("male" or "female")
            
        Returns:
            list: List of hairstyle objects
        """
        # Демонстрационные прически для разных форм лица с пометками пола
        demo_hairstyles = {
            "OVAL": [
                {"id": "oval_m_1", "name": "Классическая короткая стрижка (M)"},
                {"id": "oval_m_2", "name": "Стрижка с выбритыми висками (M)"},
                {"id": "oval_m_3", "name": "Текстурированный кроп (M)"},
                {"id": "oval_f_1", "name": "Классический боб (Ж)"},
                {"id": "oval_f_2", "name": "Длинные прямые волосы (Ж)"},
                {"id": "oval_f_3", "name": "Многослойные волны (Ж)"}
            ],
            "ROUND": [
                {"id": "round_m_1", "name": "Стрижка с объемом сверху (M)"},
                {"id": "round_m_2", "name": "Укороченные бока с удлиненным верхом (M)"},
                {"id": "round_m_3", "name": "Многослойная мужская стрижка (M)"},
                {"id": "round_f_1", "name": "Удлиненное каре (Ж)"},
                {"id": "round_f_2", "name": "Асимметричный боб (Ж)"},
                {"id": "round_f_3", "name": "Длинные слои с пробором (Ж)"}
            ],
            "SQUARE": [
                {"id": "square_m_1", "name": "Стрижка с градуировкой (M)"},
                {"id": "square_m_2", "name": "Помпадур (M)"},
                {"id": "square_m_3", "name": "Андеркат (M)"},
                {"id": "square_f_1", "name": "Мягкие волны (Ж)"},
                {"id": "square_f_2", "name": "Слоистая стрижка с челкой (Ж)"},
                {"id": "square_f_3", "name": "Длинное каре с боковым пробором (Ж)"}
            ],
            "HEART": [
                {"id": "heart_m_1", "name": "Классическая стрижка с боковым пробором (M)"},
                {"id": "heart_m_2", "name": "Короткие волосы с длинной челкой (M)"},
                {"id": "heart_m_3", "name": "Стрижка с объемным верхом (M)"},
                {"id": "heart_f_1", "name": "Средняя длина с многослойными прядями (Ж)"},
                {"id": "heart_f_2", "name": "Длинное каре с боковым пробором (Ж)"},
                {"id": "heart_f_3", "name": "Стрижки с объемом на уровне подбородка (Ж)"}
            ],
            "OBLONG": [
                {"id": "oblong_m_1", "name": "Короткая многослойная стрижка (M)"},
                {"id": "oblong_m_2", "name": "Стрижка с горизонтальной челкой (M)"},
                {"id": "oblong_m_3", "name": "Квифф (M)"},
                {"id": "oblong_f_1", "name": "Волнистые волосы средней длины (Ж)"},
                {"id": "oblong_f_2", "name": "Многослойные стрижки с объемом у макушки (Ж)"},
                {"id": "oblong_f_3", "name": "Боб с густой челкой (Ж)"}
            ],
            "DIAMOND": [
                {"id": "diamond_m_1", "name": "Стрижка с удлиненной челкой (M)"},
                {"id": "diamond_m_2", "name": "Многослойная стрижка средней длины (M)"},
                {"id": "diamond_m_3", "name": "Текстурированная стрижка с боковым пробором (M)"},
                {"id": "diamond_f_1", "name": "Объемная укладка с боковым пробором (Ж)"},
                {"id": "diamond_f_2", "name": "Многослойная стрижка средней длины (Ж)"},
                {"id": "diamond_f_3", "name": "Волнистый боб с челкой (Ж)"}
            ]
        }
        
        # Получаем прически для указанной формы лица
        # Если нет данных для такой формы, используем прически для овального лица
        hairstyles = demo_hairstyles.get(face_shape, demo_hairstyles["OVAL"])
        
        # Фильтруем по полу, если параметр указан
        if gender:
            gender_marker = "(M)" if gender == "male" else "(Ж)"
            opposite_marker = "(Ж)" if gender == "male" else "(M)"
            
            # Находим прически с нужной меткой пола
            filtered_hairstyles = [h for h in hairstyles if gender_marker in h.get("name", "")]
            
            # Находим универсальные прически (без меток пола)
            universal_hairstyles = [h for h in hairstyles 
                                  if gender_marker not in h.get("name", "") and 
                                  opposite_marker not in h.get("name", "")]
            
            # Если есть прически с нужной меткой пола, добавляем к ним универсальные
            if filtered_hairstyles:
                combined_hairstyles = filtered_hairstyles + universal_hairstyles
                logger.info(f"Filtered hairstyles by gender {gender}: {len(filtered_hairstyles)} gender-specific + {len(universal_hairstyles)} universal styles")
                return combined_hairstyles
            
            # Если нет причесок с нужной меткой пола, возвращаем универсальные
            if universal_hairstyles:
                logger.info(f"No gender-specific hairstyles found, returning {len(universal_hairstyles)} universal styles")
                return universal_hairstyles
        
        return hairstyles
    
    def get_hairstyle_names(self, face_shape_param, gender_param=None):
        """
        Get list of hairstyle names for display to user
        
        Args:
            face_shape_param (str): The determined face shape
            gender_param (str, optional): Gender filter ("male" or "female")
            
        Returns:
            list: List of hairstyle names as strings
        """
        hairstyles = self.get_available_hairstyles(face_shape_param, gender_param)
        return [h.get("name", f"Style {i+1}") for i, h in enumerate(hairstyles)]
        
    def create_sample_hairstyles(self):
        """Initialize the API clients if available"""
        # Проверяем доступность LightX API
        if self.use_lightx:
            try:
                # Получаем прически для овального лица как тест
                hairstyles = self.lightx_client.get_hairstyle_prompts_by_face_shape("OVAL")
                if hairstyles:
                    logger.info(f"Successfully retrieved {len(hairstyles)} hairstyles from LightX API")
                else:
                    logger.warning("No hairstyles available from LightX API")
            except Exception as e:
                logger.error(f"Failed to retrieve hairstyles from LightX API: {e}")
        
        # Проверяем доступность PerfectCorp API как запасной вариант
        if self.use_perfectcorp:
            try:
                hairstyles = self.perfectcorp_client.get_available_hairstyles()
                if hairstyles:
                    logger.info(f"Successfully retrieved {len(hairstyles)} hairstyles from PerfectCorp API")
                else:
                    logger.warning("No hairstyles available from PerfectCorp API")
            except Exception as e:
                logger.error(f"Failed to retrieve hairstyles from PerfectCorp API: {e}")
        
        # Если ни один API не доступен, используем демонстрационные прически
        if not self.use_lightx and not self.use_perfectcorp:
            logger.warning("No API available, using demo hairstyles")
        
    def _determine_face_shape(self, width_to_length_ratio, forehead_to_jawline_ratio, cheekbone_to_jawline_ratio):
        """
        Determine face shape based on facial measurements and ratios using a scoring system
        Modified to prioritize the ratio method that correctly identifies square faces
        """
        # Print measurements for debugging
        print(f"FACE MEASUREMENTS: width/length: {width_to_length_ratio:.2f}, forehead/jaw: {forehead_to_jawline_ratio:.2f}, cheek/jaw: {cheekbone_to_jawline_ratio:.2f}")
        
        # Используем точный метод идентификации квадратной формы лица
        # По запросу пользователя, приоритизируем параметры, которые точно определяют квадратную форму

        # Квадратная форма лица приоритетно определяется по соотношению ширины к длине
        # и близким значениям ширины лба и челюсти
        is_square_width_to_length = (0.75 <= width_to_length_ratio <= 0.85)
        is_square_forehead_jaw = (0.95 <= forehead_to_jawline_ratio <= 1.05)
        
        # Используем систему очков для всех форм, но с модифицированными весами
        self.scores = {}
        
        for shape, criteria in FACE_SHAPE_CRITERIA.items():
            width_length_range = criteria["ratio_width_to_length"]
            forehead_jaw_range = criteria["forehead_to_jawline_ratio"]
            cheek_jaw_range = criteria["cheekbone_to_jawline_ratio"]
            
            # Initialize score for this shape
            self.scores[shape] = 0
            
            # Check width to length ratio - most important
            if width_length_range[0] <= width_to_length_ratio <= width_length_range[1]:
                self.scores[shape] += 3
            else:
                # Calculate how far it is from the range
                min_distance = min(abs(width_to_length_ratio - width_length_range[0]), 
                                  abs(width_to_length_ratio - width_length_range[1]))
                if min_distance < 0.1:  # Close to the range
                    self.scores[shape] += 1
            
            # Check forehead to jawline ratio
            if forehead_jaw_range[0] <= forehead_to_jawline_ratio <= forehead_jaw_range[1]:
                self.scores[shape] += 2
            else:
                min_distance = min(abs(forehead_to_jawline_ratio - forehead_jaw_range[0]), 
                                  abs(forehead_to_jawline_ratio - forehead_jaw_range[1]))
                if min_distance < 0.1:
                    self.scores[shape] += 1
            
            # Check cheekbone to jawline ratio
            if cheek_jaw_range[0] <= cheekbone_to_jawline_ratio <= cheek_jaw_range[1]:
                self.scores[shape] += 2
            else:
                min_distance = min(abs(cheekbone_to_jawline_ratio - cheek_jaw_range[0]), 
                                  abs(cheekbone_to_jawline_ratio - cheek_jaw_range[1]))
                if min_distance < 0.1:
                    self.scores[shape] += 1
        
        # Если соотношения соответствуют квадратной форме, усиливаем её оценку
        if is_square_width_to_length and is_square_forehead_jaw:
            self.scores["SQUARE"] += 3
        
        # Print scores for debugging
        print(f"FACE SHAPE SCORES: {self.scores}")
        
        # Save last shape scores for reference
        self._last_shape_scores = self.scores.copy()
        
        # Find shape with highest score
        best_shape = max(self.scores, key=self.scores.get)
        best_score = self.scores[best_shape]
        
        # If the best score is too low, default to OVAL
        if best_score < 2:
            return "OVAL"
            
        return best_shape
