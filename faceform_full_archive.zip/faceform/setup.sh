#!/bin/bash

# Скрипт для автоматической установки FaceForm бота на VPS
echo "=== Начинаем установку FaceForm бота ==="

# Создаем виртуальное окружение
python3 -m venv venv
source venv/bin/activate

# Устанавливаем зависимости
pip install -r vps_requirements.txt

# Настраиваем Supervisor
echo "Настраиваем автозапуск через Supervisor..."
sudo mkdir -p /var/log/faceform_bot
sudo chown -R $(whoami):$(whoami) /var/log/faceform_bot

# Получаем текущую директорию и пользователя
CURRENT_DIR=$(pwd)
CURRENT_USER=$(whoami)

# Создаем конфигурационный файл для Supervisor с правильными путями
cat > faceform_bot_supervisor_updated.conf << EOSUP
[program:faceform_bot_polling]
command=${CURRENT_DIR}/venv/bin/python ${CURRENT_DIR}/run_vps.py
directory=${CURRENT_DIR}
user=${CURRENT_USER}
autostart=true
autorestart=true
stderr_logfile=/var/log/faceform_bot/stderr.log
stdout_logfile=/var/log/faceform_bot/stdout.log
environment=PYTHONUNBUFFERED=1
EOSUP

# Устанавливаем конфигурацию Supervisor
sudo cp faceform_bot_supervisor_updated.conf /etc/supervisor/conf.d/faceform_bot_polling.conf

# Применяем изменения в Supervisor
sudo supervisorctl reread
sudo supervisorctl update

# Запускаем бота
echo "Запускаем бота..."
sudo supervisorctl start faceform_bot_polling

echo "=== Установка завершена! ==="
echo "Для проверки статуса бота выполните: sudo supervisorctl status faceform_bot_polling"
echo "Для просмотра логов выполните: sudo tail -f /var/log/faceform_bot/stderr.log"