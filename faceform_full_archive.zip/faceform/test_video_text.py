import sys
import os
import logging
import tempfile

# Настройка логирования
logging.basicConfig(level=logging.DEBUG, 
                    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s')
logger = logging.getLogger(__name__)

# Импортируем функцию для обработки видео из нашего основного модуля
from process_video_with_grid import process_video_with_grid

def test_video_processing():
    """
    Тестирует функцию обработки видео с добавлением текста.
    
    Для теста используется видеофайл, указанный в аргументах командной строки,
    или ищется первый доступный видеофайл с расширением .mp4 в текущей директории.
    """
    # Проверяем, был ли передан путь к видеофайлу как аргумент
    if len(sys.argv) > 1:
        video_path = sys.argv[1]
        if not os.path.exists(video_path):
            logger.error(f"Файл {video_path} не найден")
            return
    else:
        # Если аргументы не переданы, ищем любой видеофайл в текущей директории
        video_files = [f for f in os.listdir('.') if f.endswith(('.mp4', '.avi', '.mov'))]
        if not video_files:
            logger.error("Не найдено видеофайлов для тестирования")
            return
        
        video_path = video_files[0]
        logger.info(f"Используем первый найденный видеофайл: {video_path}")
    
    # Открываем и читаем видеофайл
    try:
        with open(video_path, 'rb') as f:
            video_data = f.read()
        
        logger.info(f"Загружен видеофайл размером {len(video_data)/1024/1024:.2f} MB")
        
        # Обрабатываем видео
        logger.info("Начинаем обработку видео...")
        processed_video_data = process_video_with_grid(video_data)
        
        if processed_video_data:
            # Сохраняем обработанное видео
            output_path = os.path.splitext(video_path)[0] + "_processed" + os.path.splitext(video_path)[1]
            with open(output_path, 'wb') as f:
                f.write(processed_video_data)
            
            logger.info(f"Обработанное видео сохранено в {output_path}")
            logger.info(f"Размер обработанного видео: {len(processed_video_data)/1024/1024:.2f} MB")
            return output_path
        else:
            logger.error("Ошибка при обработке видео")
    
    except Exception as e:
        logger.error(f"Произошла ошибка: {e}")
        import traceback
        logger.error(traceback.format_exc())

if __name__ == "__main__":
    output_path = test_video_processing()
    if output_path:
        logger.info(f"Тестирование завершено успешно. Результат: {output_path}")
    else:
        logger.error("Тестирование завершилось с ошибкой")