#!/bin/bash
# Скрипт установки FaceForm Bot на VPS сервер
# Запускайте с sudo: sudo bash setup_vps.sh

# Цвета для вывода
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m' # No Color

# Проверка прав суперпользователя
if [ "$EUID" -ne 0 ]; then
  echo -e "${RED}Пожалуйста, запустите этот скрипт с правами суперпользователя (sudo)${NC}"
  exit 1
fi

# Приветствие
echo -e "${BLUE}=== Установка FaceForm Bot на VPS сервер ===${NC}"
echo -e "${YELLOW}Этот скрипт настроит ваш сервер для работы FaceForm Bot.${NC}"
echo -e "${YELLOW}Убедитесь, что у вас есть все необходимые данные:${NC}"
echo -e "- Telegram API Token"
echo -e "- LightX API Key (необязательно)"
echo -e "- Stripe Secret Key (необязательно)"
echo -e "- Telegram ID администратора (для уведомлений)"
echo
echo -e "${YELLOW}Нажмите Enter для продолжения или Ctrl+C для отмены...${NC}"
read

# Настройка переменных
echo -e "${BLUE}=== Настройка переменных ===${NC}"
read -p "Введите имя пользователя для бота (по умолчанию: faceform): " BOT_USER
BOT_USER=${BOT_USER:-faceform}

BOT_HOME="/home/$BOT_USER/faceform_bot"

# Шаг 1: Обновление системы
echo -e "${BLUE}=== Шаг 1: Обновление системы ===${NC}"
apt update && apt upgrade -y

# Шаг 2: Установка зависимостей
echo -e "${BLUE}=== Шаг 2: Установка зависимостей ===${NC}"
apt install -y python3-pip python3-venv supervisor git ffmpeg libsm6 libxext6 libgl1 python3-opencv sqlite3 htop

# Шаг 3: Создание пользователя для бота
echo -e "${BLUE}=== Шаг 3: Создание пользователя для бота ===${NC}"
if id "$BOT_USER" &>/dev/null; then
    echo -e "${YELLOW}Пользователь $BOT_USER уже существует.${NC}"
else
    adduser --gecos "" $BOT_USER
    usermod -aG sudo $BOT_USER
    echo -e "${GREEN}Пользователь $BOT_USER создан.${NC}"
fi

# Проверка наличия репозитория
echo -e "${BLUE}=== Шаг 4: Настройка репозитория ===${NC}"
if [ -d "$BOT_HOME" ]; then
    echo -e "${YELLOW}Директория $BOT_HOME уже существует.${NC}"
    read -p "Хотите ли вы использовать существующую директорию? (y/n): " USE_EXISTING
    if [[ $USE_EXISTING != "y" && $USE_EXISTING != "Y" ]]; then
        read -p "Введите новое имя директории для бота: " NEW_BOT_DIR
        BOT_HOME="/home/$BOT_USER/$NEW_BOT_DIR"
    fi
fi

if [ ! -d "$BOT_HOME" ]; then
    echo -e "${YELLOW}Директория $BOT_HOME не существует и будет создана.${NC}"
    mkdir -p $BOT_HOME
    chown $BOT_USER:$BOT_USER $BOT_HOME
fi

# Переключение на пользователя бота и настройка окружения
echo -e "${BLUE}=== Шаг 5: Настройка окружения бота ===${NC}"

# Создаем скрипт для выполнения от имени пользователя бота
cat > /tmp/bot_setup.sh << EOF
#!/bin/bash
cd $BOT_HOME

# Создание виртуального окружения
if [ ! -d "$BOT_HOME/venv" ]; then
    echo "Создание виртуального окружения..."
    python3 -m venv venv
fi

# Активация виртуального окружения
source venv/bin/activate

# Создание структуры каталогов
mkdir -p logs
mkdir -p attached_assets
mkdir -p extracted_frames
mkdir -p hairstyles

# Создание файла requirements.txt, если его нет
if [ ! -f "$BOT_HOME/requirements.txt" ]; then
    echo "Создание файла requirements.txt..."
    cat > requirements.txt << 'REQS'
telebot==0.0.5
pytelegrambotapi==4.12.0
python-telegram-bot==13.15
opencv-python==4.8.0.76
mediapipe==0.10.2
numpy==1.24.3
matplotlib==3.7.2
sqlalchemy==2.0.19
flask==2.3.2
flask-sqlalchemy==3.0.5
python-dotenv==1.0.0
pillow==9.5.0
psutil==5.9.5
requests==2.31.0
pysqlite3==0.5.1
stripe==5.5.0
gunicorn==21.2.0
email-validator==2.0.0.post2
psycopg2-binary==2.9.6
trafilatura==1.6.0
REQS
fi

# Установка зависимостей
echo "Установка зависимостей Python..."
pip install --upgrade pip
pip install -r requirements.txt

# Создание файла .env, если его нет
if [ ! -f "$BOT_HOME/.env" ]; then
    echo "Создание файла .env..."
    cat > .env << 'ENVFILE'
# Основные настройки
TELEGRAM_API_TOKEN=your_telegram_token_here
ADMIN_USER_ID=your_telegram_id_here

# LightX API
LIGHTX_API_KEY=your_lightx_api_key_here

# Stripe платежи
STRIPE_SECRET_KEY=your_stripe_secret_key_here
STRIPE_PUBLISHABLE_KEY=your_stripe_publishable_key_here

# Настройки режима работы
USE_WEBHOOK=false
WEBHOOK_URL=https://your-domain.com/webhook
WEBHOOK_PORT=8443
POLLING_INTERVAL=3

# Другие настройки
DEBUG_MODE=false
ENVFILE
fi

# Создание файла run_vps.py, если его нет
if [ ! -f "$BOT_HOME/run_vps.py" ]; then
    echo "Скачиваем файлы установки..."
    touch keep_files
fi

echo "Настройка завершена!"
EOF

# Делаем скрипт исполняемым и запускаем его от имени пользователя бота
chmod +x /tmp/bot_setup.sh
su - $BOT_USER -c "bash /tmp/bot_setup.sh"

# Создание файла конфигурации supervisor
echo -e "${BLUE}=== Шаг 6: Настройка Supervisor ===${NC}"
SUPERVISOR_CONF="/etc/supervisor/conf.d/faceform_bot.conf"

if [ -f "$SUPERVISOR_CONF" ]; then
    echo -e "${YELLOW}Файл конфигурации Supervisor уже существует.${NC}"
    read -p "Заменить его? (y/n): " REPLACE_SUPERVISOR
    if [[ $REPLACE_SUPERVISOR != "y" && $REPLACE_SUPERVISOR != "Y" ]]; then
        echo -e "${YELLOW}Пропускаем создание конфигурации Supervisor.${NC}"
    else
        # Создаем конфигурацию Supervisor
        cat > $SUPERVISOR_CONF << EOF
[program:faceform_bot]
command=/home/$BOT_USER/venv/bin/python /home/$BOT_USER/faceform_bot/run_vps.py
directory=/home/$BOT_USER/faceform_bot
user=$BOT_USER
autostart=true
autorestart=true
startsecs=10
startretries=3
stopwaitsecs=10
stderr_logfile=/home/$BOT_USER/faceform_bot/logs/stderr.log
stdout_logfile=/home/$BOT_USER/faceform_bot/logs/stdout.log
environment=PYTHONUNBUFFERED=1,PYTHONIOENCODING="UTF-8"

[group:faceform]
programs=faceform_bot
priority=999

[program:faceform_monitor]
command=/home/$BOT_USER/venv/bin/python /home/$BOT_USER/faceform_bot/monitor.py
directory=/home/$BOT_USER/faceform_bot
user=$BOT_USER
autostart=true
autorestart=true
startsecs=10
startretries=3
stderr_logfile=/home/$BOT_USER/faceform_bot/logs/monitor_stderr.log
stdout_logfile=/home/$BOT_USER/faceform_bot/logs/monitor_stdout.log
environment=PYTHONUNBUFFERED=1,PYTHONIOENCODING="UTF-8"
EOF
        echo -e "${GREEN}Файл конфигурации Supervisor создан.${NC}"
    fi
else
    # Создаем конфигурацию Supervisor
    cat > $SUPERVISOR_CONF << EOF
[program:faceform_bot]
command=/home/$BOT_USER/venv/bin/python /home/$BOT_USER/faceform_bot/run_vps.py
directory=/home/$BOT_USER/faceform_bot
user=$BOT_USER
autostart=true
autorestart=true
startsecs=10
startretries=3
stopwaitsecs=10
stderr_logfile=/home/$BOT_USER/faceform_bot/logs/stderr.log
stdout_logfile=/home/$BOT_USER/faceform_bot/logs/stdout.log
environment=PYTHONUNBUFFERED=1,PYTHONIOENCODING="UTF-8"

[group:faceform]
programs=faceform_bot
priority=999

[program:faceform_monitor]
command=/home/$BOT_USER/venv/bin/python /home/$BOT_USER/faceform_bot/monitor.py
directory=/home/$BOT_USER/faceform_bot
user=$BOT_USER
autostart=true
autorestart=true
startsecs=10
startretries=3
stderr_logfile=/home/$BOT_USER/faceform_bot/logs/monitor_stderr.log
stdout_logfile=/home/$BOT_USER/faceform_bot/logs/monitor_stdout.log
environment=PYTHONUNBUFFERED=1,PYTHONIOENCODING="UTF-8"
EOF
    echo -e "${GREEN}Файл конфигурации Supervisor создан.${NC}"
fi

# Перезагрузка Supervisor
echo -e "${BLUE}=== Шаг 7: Перезагрузка Supervisor ===${NC}"
supervisorctl reread
supervisorctl update

# Настройка конфигурации бота
echo -e "${BLUE}=== Шаг 8: Настройка конфигурации бота ===${NC}"
echo -e "${YELLOW}Теперь вам нужно настроить конфигурацию бота:${NC}"
echo -e "1. Отредактируйте файл .env: ${BLUE}sudo nano $BOT_HOME/.env${NC}"
echo -e "2. Загрузите код бота в директорию: ${BLUE}$BOT_HOME${NC}"
echo -e "3. Перезапустите бота: ${BLUE}sudo supervisorctl restart faceform_bot${NC}"

echo -e "${GREEN}Установка завершена!${NC}"
echo -e "${YELLOW}Проверьте статус бота:${NC} ${BLUE}sudo supervisorctl status${NC}"