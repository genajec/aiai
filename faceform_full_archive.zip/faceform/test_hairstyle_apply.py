#!/usr/bin/env python
"""
Скрипт для тестирования функции применения прически с ротацией ключей
"""

import os
import sys
import logging
import requests
from io import BytesIO
from PIL import Image

# Настройка логирования
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(name)s - %(levelname)s - %(message)s')
logger = logging.getLogger(__name__)

# Импортируем необходимые модули
try:
    from lightx_client import LightXClient
    from lightx_key_manager import LightXKeyManager
except ImportError as e:
    logger.error(f"Ошибка импорта: {e}")
    sys.exit(1)

def load_test_image(image_path):
    """
    Загружает тестовое изображение для проверки
    
    Args:
        image_path (str): Путь к изображению
        
    Returns:
        bytes: Данные изображения
    """
    try:
        if not os.path.exists(image_path):
            logger.error(f"Изображение не найдено: {image_path}")
            return None
            
        with open(image_path, 'rb') as f:
            image_data = f.read()
            
        logger.info(f"Загружено изображение: {image_path} ({len(image_data)} байт)")
        return image_data
    except Exception as e:
        logger.error(f"Ошибка при загрузке изображения: {e}")
        return None

def save_result_image(image_data, output_path):
    """
    Сохраняет результат применения прически
    
    Args:
        image_data (bytes): Данные изображения
        output_path (str): Путь для сохранения
        
    Returns:
        bool: True если сохранение успешно, False в случае ошибки
    """
    try:
        if not image_data:
            logger.error("Нет данных для сохранения")
            return False
            
        # Сохраняем изображение
        with open(output_path, 'wb') as f:
            f.write(image_data)
            
        logger.info(f"Результат сохранен: {output_path}")
        
        # Для дополнительной проверки открываем изображение с помощью PIL
        image = Image.open(BytesIO(image_data))
        logger.info(f"Размер изображения: {image.size[0]}x{image.size[1]}, формат: {image.format}")
        
        return True
    except Exception as e:
        logger.error(f"Ошибка при сохранении результата: {e}")
        return False

def main():
    """
    Основная функция тестирования
    """
    # Проверяем наличие переменных окружения
    if not os.environ.get("LIGHTX_API_KEY"):
        logger.warning("Переменная окружения LIGHTX_API_KEY не найдена")
    
    # Загружаем тестовое изображение 
    test_images = [
        'attached_assets/IMG_7894.png',  # Лицо для анализа
    ]
    
    # Промпты для причесок
    hairstyle_prompts = [
        "short black hair",
        "long blonde hair",
        "medium length brown hair, wavy"
    ]
    
    # Создаем клиент LightX
    client = LightXClient()
    
    # Проверяем, что клиент успешно инициализирован
    current_key = client.key_manager.get_current_key()
    logger.info(f"Текущий ключ API: {'установлен' if current_key else 'не установлен'}")
    
    # Тестируем ключ
    if current_key:
        key_status = client.key_manager.test_current_key()
        logger.info(f"Проверка ключа: {'успешно' if key_status else 'неудачно'}")
    
    # Проверяем каждое изображение с каждым промптом
    for image_path in test_images:
        image_data = load_test_image(image_path)
        if not image_data:
            continue
        
        for i, prompt in enumerate(hairstyle_prompts):
            logger.info(f"\n------ Тест {i+1}: {prompt} ------")
            result = client.apply_hairstyle(image_data, prompt)
            
            if result:
                output_path = f"hairstyle_result_{i+1}.jpg"
                save_result_image(result, output_path)
            else:
                logger.error(f"Не удалось применить прическу: {prompt}")
    
    # Выводим статистику использования ключей
    stats = client.key_manager.get_key_stats()
    logger.info("\n------ Статистика использования ключей ------")
    for key, key_stats in stats.items():
        status = "АКТИВЕН" if key_stats["active"] else ("ЗАБЛОКИРОВАН" if key_stats["blocked"] else "ДОСТУПЕН")
        logger.info(f"Ключ {key}: {status}, успешность: {key_stats['success_rate']}%, запросов: {key_stats['total_requests']}")
        if key_stats["blocked_until"]:
            logger.info(f"  Заблокирован до: {key_stats['blocked_until']}")

if __name__ == "__main__":
    main()