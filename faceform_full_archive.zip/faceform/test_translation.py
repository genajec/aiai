#!/usr/bin/env python3
# -*- coding: utf-8 -*-

import logging
import requests
import io
import sys
import os
from lightx_client import LightXClient
from PIL import Image

# Enable logging
logging.basicConfig(format='%(asctime)s - %(name)s - %(levelname)s - %(message)s', level=logging.INFO)
logger = logging.getLogger(__name__)

def translate_with_deepl(text, source_lang="RU", target_lang="EN"):
    """
    Переводит текст с помощью DeepL API
    
    Args:
        text (str): Исходный текст для перевода
        source_lang (str): Язык исходного текста (по умолчанию "RU" - русский)
        target_lang (str): Язык, на который нужно перевести (по умолчанию "EN" - английский)
        
    Returns:
        str: Переведенный текст или None при ошибке
    """
    try:
        # Ключ API DeepL
        api_key = "7fe9dd7a-990a-4bf1-86af-a216b1b993a1:fx"
        
        # URL DeepL API
        url = "https://api-free.deepl.com/v2/translate"
        
        # Данные для запроса
        data = {
            "text": [text],
            "source_lang": source_lang,
            "target_lang": target_lang
        }
        
        # Заголовки с ключом API
        headers = {
            "Authorization": f"DeepL-Auth-Key {api_key}",
            "Content-Type": "application/json"
        }
        
        logger.info(f"Sending translation request to DeepL API for text: '{text}'")
        
        # Отправляем запрос
        response = requests.post(url, json=data, headers=headers)
        
        # Подробное логирование ответа для отладки
        logger.info(f"DeepL API response status: {response.status_code}")
        logger.info(f"DeepL API response headers: {response.headers}")
        
        # Проверяем успешность запроса
        if response.status_code == 200:
            result = response.json()
            logger.info(f"DeepL API response: {result}")
            
            if "translations" in result and len(result["translations"]) > 0:
                translated_text = result["translations"][0]["text"]
                logger.info(f"DeepL translation successful: '{text}' -> '{translated_text}'")
                return translated_text
            else:
                logger.warning(f"DeepL API returned 200 but no translations found in response: {result}")
        
        # Если запрос неуспешен или ответ не содержит перевода,
        # логируем ошибку и возвращаем None
        logger.warning(f"DeepL API error: {response.status_code} - {response.text}")
        return None
    except Exception as e:
        logger.error(f"Error in DeepL API: {e}")
        return None

def main():
    if len(sys.argv) > 1:
        text_to_translate = ' '.join(sys.argv[1:])
    else:
        print("Использование: python test_translation.py <текст для перевода>")
        # Используем тестовый текст по умолчанию
        text_to_translate = "Фантастический пейзаж с парящими островами и водопадами"
    
    print(f"\nПереводим русский текст: '{text_to_translate}'")
    
    # Переводим с помощью DeepL API
    translated = translate_with_deepl(text_to_translate)
    
    if translated:
        print(f"✓ Успешный перевод через DeepL API: '{translated}'")
        
        # Если перевод успешен, пробуем сгенерировать изображение
        try:
            print("\nИнициализация LightX API клиента...")
            lightx_client = LightXClient()
            print("✓ LightX API клиент успешно инициализирован")
            
            print(f"\nГенерация изображения с промптом: '{translated}'...")
            result_image = lightx_client.generate_from_text(translated)
            
            if result_image:
                print("✓ Изображение успешно сгенерировано!")
                
                # Сохраняем изображение в файл
                output_path = "generated_image.jpg"
                with open(output_path, "wb") as f:
                    f.write(result_image)
                print(f"Изображение сохранено в файл: {output_path}")
                
                # Показываем информацию о размере сгенерированного изображения
                img = Image.open(io.BytesIO(result_image))
                print(f"Размер изображения: {img.width}x{img.height}")
            else:
                print("✖ Ошибка генерации изображения через LightX API")
        except Exception as e:
            print(f"✖ Ошибка при работе с LightX API: {e}")
    else:
        print("✖ Ошибка перевода через DeepL API")

if __name__ == "__main__":
    main()