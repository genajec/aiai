#!/usr/bin/env python
"""
Скрипт для запуска бота в режиме polling
"""

import logging
import telebot
import os
from bot import FaceShapeBot
from dotenv import load_dotenv

# Загрузка переменных окружения
load_dotenv()

# Настраиваем логирование
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    filename='bot_polling.log',
    filemode='a'
)
logger = logging.getLogger(__name__)

# Также выводим логи в консоль
console = logging.StreamHandler()
console.setLevel(logging.INFO)
formatter = logging.Formatter('%(asctime)s - %(name)s - %(levelname)s - %(message)s')
console.setFormatter(formatter)
logger.addHandler(console)

def main():
    """
    Запуск бота в режиме polling
    """
    logger.info("Запуск бота в режиме polling")
    
    # Получаем токен напрямую из переменных окружения
    token = os.getenv("TELEGRAM_BOT_TOKEN")
    
    if not token:
        logger.error("Токен Telegram API не найден в переменных окружения")
        return
    
    # Удаляем старый webhook перед запуском polling
    try:
        logger.info("Удаляем webhook для предотвращения конфликтов...")
        bot = telebot.TeleBot(token)
        webhook_info = bot.get_webhook_info()
        logger.info(f"Текущая информация о webhook: {webhook_info}")
        
        if webhook_info.url:
            bot.delete_webhook(drop_pending_updates=True)
            logger.info("Webhook удален")
    except Exception as e:
        logger.error(f"Ошибка при удалении webhook: {e}")
        
        # Вывод дополнительной информации
        try:
            response = bot.get_me()
            logger.info(f"Информация о боте: {response}")
        except Exception as bot_error:
            logger.error(f"Ошибка при получении информации о боте: {bot_error}")
    
    # Создаем экземпляр бота
    face_shape_bot = FaceShapeBot(use_webhook=False)
    
    # Выводим информацию о запуске
    logger.info("Бот запущен. Нажмите Ctrl+C для остановки")
    
    try:
        # Запускаем бота в режиме polling
        face_shape_bot.run()
    except Exception as e:
        logger.error(f"Ошибка при запуске бота: {e}")
    except KeyboardInterrupt:
        logger.info("Бот остановлен по запросу пользователя")

if __name__ == "__main__":
    main()