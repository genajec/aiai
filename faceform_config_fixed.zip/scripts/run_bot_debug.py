#!/usr/bin/env python
"""
Отладочный скрипт для запуска бота в режиме polling с подробным логированием
"""

import os
import sys
import logging
import telebot
from dotenv import load_dotenv

# Настраиваем подробное логирование
logging.basicConfig(
    level=logging.DEBUG,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    stream=sys.stdout
)
logger = logging.getLogger(__name__)

def main():
    """
    Отладочный запуск бота
    """
    logger.info("Запуск отладочного скрипта для бота")
    
    # Загружаем переменные окружения
    load_dotenv()
    
    # Получаем токен напрямую
    token = os.getenv("TELEGRAM_BOT_TOKEN")
    
    if not token:
        logger.error("Токен Telegram API не найден в переменных окружения")
        return
    
    logger.info(f"Используется токен: {token[:10]}...")
    
    try:
        # Создаем экземпляр бота напрямую
        bot = telebot.TeleBot(token)
        
        # Тестируем подключение к API
        me = bot.get_me()
        logger.info(f"Успешное подключение к API. Информация о боте: {me}")
        
        # Удаляем webhook для перехода в режиме polling
        bot.delete_webhook()
        logger.info("Webhook удален успешно")
        
        # Простой обработчик для команды /start
        @bot.message_handler(commands=['start'])
        def handle_start(message):
            bot.send_message(message.chat.id, "Привет! Я бот для анализа формы лица.")
        
        # Запускаем polling
        logger.info("Запускаем polling...")
        bot.polling(none_stop=True, interval=0)
    except Exception as e:
        logger.exception(f"Произошла ошибка: {e}")

if __name__ == "__main__":
    main()