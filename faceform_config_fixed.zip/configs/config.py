#!/usr/bin/env python
"""
Конфигурационный файл для бота FaceForm
"""

import os
import json
from dotenv import load_dotenv

# Загрузка переменных окружения из .env файла
load_dotenv()

# Telegram API
TELEGRAM_API_TOKEN = os.getenv("TELEGRAM_BOT_TOKEN")
TELEGRAM_BOT_NAME = os.getenv("TELEGRAM_BOT_NAME", "Faceform_bot")

# Stripe API
STRIPE_SECRET_KEY = os.getenv("STRIPE_SECRET_KEY")
STRIPE_PUBLIC_KEY = os.getenv("STRIPE_PUBLIC_KEY")

# LightX API
LIGHTX_API_KEY = os.getenv("LIGHTX_API_KEY")
LIGHTX_API_KEYS = os.getenv("LIGHTX_API_KEYS", "").split(",")

# DeepL API
DEEPL_API_KEY = os.getenv("DEEPL_API_KEY")

# CryptoBot API
CRYPTO_BOT_TOKEN = os.getenv("CRYPTO_BOT_TOKEN", "")

# Другие настройки
SERVER_IP = os.getenv("SERVER_IP", "92.113.145.171")

# Сообщения бота
BOT_MESSAGES = {
    "start": "👋 Привет! Я FaceForm бот!\n\nЯ могу помочь тебе определить форму твоего лица и подобрать подходящие прически, проанализировать симметрию и многое другое.\n\nОтправь мне качественное селфи, и я проведу анализ.",
    "help": "🔍 *Как пользоваться ботом:*\n\n1. Отправь мне фронтальное селфи (без наклона головы, волосы убраны от лица)\n2. Получи анализ формы лица и рекомендации по прическам\n3. Используй команды в меню для дополнительных функций\n\n*Доступные команды:*\n/menu - Показать главное меню\n/faceshape - Определить форму лица\n/symmetry - Проверить симметрию лица\n/try - Примерить прически\n/hairstyles - Список доступных причесок",
    "menu": "📋 *Главное меню:*\n\n*Основные функции:*\n/faceshape - Определить форму лица\n/symmetry - Проверить симметрию\n/try - Примерить прически\n/hairstyles - Список причесок\n\n*Дополнительно:*\n/beauty - Анализ привлекательности\n/video - Анализ видео с лицом\n/credits - Баланс кредитов\n/buy - Купить кредиты",
    "photo_request": "📸 Отправь мне фронтальное селфи, и я проанализирую форму твоего лица.",
    "processing": "⏳ Обрабатываю твое фото... Это займет несколько секунд.",
    "face_not_found": "😕 Не могу найти лицо на фото. Пожалуйста, отправь другое изображение с четким изображением лица.",
    "error": "😟 Произошла ошибка при обработке запроса. Пожалуйста, попробуй еще раз позже.",
    "low_quality": "🔍 Изображение слишком низкого качества для точного анализа. Пожалуйста, отправь более четкое фото.",
    "too_many_faces": "👥 Обнаружено несколько лиц на фото. Пожалуйста, отправь селфи только с твоим лицом.",
    "face_not_centered": "🎯 Лицо не расположено по центру или под углом. Для точного анализа отправь фронтальное селфи без наклона головы.",
    "try_instruction": "📸 Отправь мне свое фото, чтобы примерить различные прически.",
    "no_user_photo": "❗ У меня нет твоего фото для анализа. Пожалуйста, отправь селфи сначала.",
    "select_hairstyle": "💇 Выбери прическу, которую хочешь примерить:",
    "hairstyle_generation": "⏳ Генерирую изображение с выбранной прической... Это займет около 30 секунд.",
    "no_credits": "💳 У тебя недостаточно кредитов для этой операции. Используй команду /buy чтобы приобрести кредиты.",
    "credits_info": "💳 *Твой баланс:* {} кредитов\n\nКредиты используются для доступа к премиум-функциям:\n- Примерка причесок: 1 кредит\n- Проверка симметрии: 1 кредит\n- Анализ привлекательности: 2 кредита\n- Анализ видео: 5 кредитов\n\nИспользуй /buy чтобы приобрести кредиты."
}

# Критерии определения формы лица
FACE_SHAPE_CRITERIA = {
    "OVAL": {
        "description": "Овальная форма",
        "ratio_width_height": (0.65, 0.75),  # Соотношение ширины к высоте
        "jaw_forehead_ratio": (0.95, 1.05),  # Соотношение челюсти к лбу
        "cheekbone_jaw_ratio": (1.05, 1.15),  # Соотношение скул к челюсти
    },
    "ROUND": {
        "description": "Круглая форма",
        "ratio_width_height": (0.8, 0.9),
        "jaw_forehead_ratio": (0.95, 1.05),
        "cheekbone_jaw_ratio": (1.0, 1.1),
    },
    "SQUARE": {
        "description": "Квадратная форма",
        "ratio_width_height": (0.75, 0.85),
        "jaw_forehead_ratio": (0.95, 1.05),
        "cheekbone_jaw_ratio": (0.95, 1.05),
    },
    "HEART": {
        "description": "Сердцевидная форма",
        "ratio_width_height": (0.7, 0.8),
        "jaw_forehead_ratio": (0.8, 0.9),
        "cheekbone_jaw_ratio": (1.1, 1.2),
    },
    "DIAMOND": {
        "description": "Ромбовидная форма",
        "ratio_width_height": (0.7, 0.8),
        "jaw_forehead_ratio": (0.95, 1.05),
        "cheekbone_jaw_ratio": (1.1, 1.2),
    },
    "RECTANGULAR": {
        "description": "Прямоугольная форма",
        "ratio_width_height": (0.6, 0.7),
        "jaw_forehead_ratio": (0.95, 1.05),
        "cheekbone_jaw_ratio": (0.95, 1.05),
    },
    "TRIANGLE": {
        "description": "Треугольная форма",
        "ratio_width_height": (0.7, 0.8),
        "jaw_forehead_ratio": (1.1, 1.2),
        "cheekbone_jaw_ratio": (0.9, 1.0),
    }
}

# Сообщения для премиум-функций
PREMIUM_MESSAGES = {
    "beauty_analysis": "🔍 *Анализ привлекательности лица*\n\nЭта функция проводит комплексный анализ привлекательности лица по нескольким параметрам.\n\n*Стоимость:* 2 кредита\n\n📸 Отправь мне качественное селфи для анализа.",
    "video_analysis": "🎬 *Анализ видео с лицом*\n\nЭта функция обрабатывает короткое видео (до 15 секунд) с твоим лицом, добавляет сетку для анализа лицевых пропорций и возвращает обработанное видео с детальным отчетом.\n\n*Стоимость:* 5 кредитов\n\n📹 Отправь мне короткое видео для анализа.",
    "buy_intro": "💳 *Приобретение кредитов*\n\nКредиты используются для доступа к премиум-функциям.\nВыбери пакет кредитов:",
    "package_1": "💼 Стартовый: 10 кредитов - 199 руб.",
    "package_2": "💼 Оптимальный: 25 кредитов - 399 руб.",
    "package_3": "💼 Премиум: 50 кредитов - 699 руб.",
    "payment_methods": "Выбери способ оплаты:",
    "payment_card": "💳 Банковская карта",
    "payment_crypto": "💰 Криптовалюта",
    "payment_process": "⏳ Оформляю платеж...",
    "payment_link": "🔗 Перейди по ссылке для оплаты:\n{}\n\nПосле успешной оплаты кредиты будут начислены автоматически.",
    "payment_success": "✅ Оплата успешно проведена! Твой баланс пополнен на {} кредитов.",
    "payment_cancel": "❌ Платеж был отменен."
}

# Конфигурация причесок для разных типов лица
HAIRSTYLES = {
    "OVAL": [
        {
            "name": "Каре с челкой",
            "style": "bob haircut with bangs, shoulder length, face framing, oval face shape hairstyle, keep same face, focus on hair only",
            "colors": [
                {"name": "Темно-коричневый", "value": "dark brown"},
                {"name": "Блонд", "value": "blonde"},
                {"name": "Черный", "value": "black"},
                {"name": "Рыжий", "value": "red"}
            ],
            "lengths": [
                {"name": "До подбородка", "value": "chin length"},
                {"name": "До плеч", "value": "shoulder length"}
            ],
            "textures": [
                {"name": "Прямые", "value": "straight"},
                {"name": "Волнистые", "value": "wavy"},
                {"name": "Текстурные", "value": "textured"}
            ]
        },
        {
            "name": "Длинные слои",
            "style": "long layered haircut, face framing layers, oval face shape hairstyle, keep same face, focus on hair only",
            "colors": [
                {"name": "Темно-коричневый", "value": "dark brown"},
                {"name": "Блонд", "value": "blonde"},
                {"name": "Черный", "value": "black"},
                {"name": "Медовый", "value": "honey blonde"}
            ],
            "lengths": [
                {"name": "До плеч", "value": "shoulder length"},
                {"name": "Ниже плеч", "value": "below shoulder"},
                {"name": "Длинные", "value": "long"}
            ],
            "textures": [
                {"name": "Прямые", "value": "straight"},
                {"name": "Волнистые", "value": "wavy"},
                {"name": "Кудрявые", "value": "curly"}
            ]
        }
    ],
    "ROUND": [
        {
            "name": "Удлиненное каре",
            "style": "long bob, a-line cut, longer in front, textured ends, perfect for round face shape, keep same face, focus on hair only",
            "colors": [
                {"name": "Темно-коричневый", "value": "dark brown"},
                {"name": "Блонд", "value": "blonde"},
                {"name": "Черный", "value": "black"},
                {"name": "Пепельный", "value": "ash blonde"}
            ],
            "lengths": [
                {"name": "До подбородка", "value": "chin length"},
                {"name": "До плеч", "value": "shoulder length"}
            ],
            "textures": [
                {"name": "Прямые", "value": "straight"},
                {"name": "Слегка волнистые", "value": "slightly wavy"},
                {"name": "Гладкие", "value": "sleek and polished"}
            ]
        }
    ],
    "SQUARE": [
        {
            "name": "Мягкие волны с боковым пробором",
            "style": "soft waves with deep side part, face-framing layers, medium length, softening strong jawline of square face, keep same face, focus on hair only",
            "colors": [
                {"name": "Темно-коричневый", "value": "dark brown"},
                {"name": "Русый", "value": "medium blonde"},
                {"name": "Черный", "value": "black"},
                {"name": "Медный", "value": "copper"}
            ],
            "lengths": [
                {"name": "До подбородка", "value": "chin length"},
                {"name": "До плеч", "value": "shoulder length"}
            ],
            "textures": [
                {"name": "Легкие волны", "value": "soft waves"},
                {"name": "Выраженные волны", "value": "defined waves"},
                {"name": "Текстурные", "value": "textured"}
            ]
        }
    ],
    "HEART": [
        {
            "name": "Небрежный боб с челкой",
            "style": "tousled bob with side-swept bangs, layered, textured, balancing wide forehead of heart-shaped face, keep same face, focus on hair only",
            "colors": [
                {"name": "Темно-коричневый", "value": "dark brown"},
                {"name": "Медовый блонд", "value": "honey blonde"},
                {"name": "Черный", "value": "black"},
                {"name": "Шоколадный", "value": "chocolate brown"}
            ],
            "lengths": [
                {"name": "Короткий", "value": "short bob"},
                {"name": "Классический", "value": "classic bob"}
            ],
            "textures": [
                {"name": "Текстурные", "value": "textured"},
                {"name": "Небрежные", "value": "tousled"},
                {"name": "Взъерошенные", "value": "messy"}
            ]
        }
    ],
    "DIAMOND": [
        {
            "name": "Длинные слои с пробором",
            "style": "long layered hair with middle part, face-framing layers starting at cheekbones, balancing diamond face shape, keep same face, focus on hair only",
            "colors": [
                {"name": "Темно-коричневый", "value": "dark brown"},
                {"name": "Карамельный", "value": "caramel blonde"},
                {"name": "Черный", "value": "black"},
                {"name": "Пепельный", "value": "ash brown"}
            ],
            "lengths": [
                {"name": "До плеч", "value": "shoulder length"},
                {"name": "Ниже плеч", "value": "below shoulder"},
                {"name": "Длинные", "value": "long"}
            ],
            "textures": [
                {"name": "Прямые", "value": "straight"},
                {"name": "Легкие волны", "value": "soft waves"},
                {"name": "Гладкие", "value": "sleek"}
            ]
        }
    ],
    "RECTANGULAR": [
        {
            "name": "Текстурный боб",
            "style": "textured bob with layers, soft fringe, face-framing, softening angles of rectangular face shape, keep same face, focus on hair only",
            "colors": [
                {"name": "Темно-коричневый", "value": "dark brown"},
                {"name": "Пепельный блонд", "value": "ash blonde"},
                {"name": "Черный", "value": "black"},
                {"name": "Каштановый", "value": "chestnut"}
            ],
            "lengths": [
                {"name": "Короткий", "value": "short bob"},
                {"name": "Удлиненный", "value": "long bob"}
            ],
            "textures": [
                {"name": "Текстурные", "value": "heavily textured"},
                {"name": "Слоистые", "value": "layered"},
                {"name": "Объемные", "value": "voluminous"}
            ]
        }
    ],
    "TRIANGLE": [
        {
            "name": "Лоб с челкой",
            "style": "lob haircut with curtain bangs, volume at top, balancing triangle face shape with wide jawline, keep same face, focus on hair only",
            "colors": [
                {"name": "Темно-коричневый", "value": "dark brown"},
                {"name": "Медовый блонд", "value": "honey blonde"},
                {"name": "Черный", "value": "black"},
                {"name": "Золотистый", "value": "golden brown"}
            ],
            "lengths": [
                {"name": "До плеч", "value": "shoulder length"},
                {"name": "Ниже плеч", "value": "below shoulder"}
            ],
            "textures": [
                {"name": "Текстурные", "value": "textured"},
                {"name": "Объемные", "value": "voluminous"},
                {"name": "Слоистые", "value": "layered"}
            ]
        }
    ]
}

# Конфигурация цен
PRICING = {
    "packages": {
        "basic": {"credits": 10, "price": 199},
        "standard": {"credits": 25, "price": 399},
        "premium": {"credits": 50, "price": 699}
    },
    "costs": {
        "try_hairstyle": 1,
        "symmetry_check": 1,
        "beauty_analysis": 2,
        "video_analysis": 5
    }
}

# Конфигурация платежей
PAYMENT_CONFIG = {
    "stripe": {
        "success_url": f"http://{os.getenv('SERVER_IP', '92.113.145.171')}/payment/success",
        "cancel_url": f"http://{os.getenv('SERVER_IP', '92.113.145.171')}/payment/cancel"
    },
    "crypto": {
        "webhook_url": f"http://{os.getenv('SERVER_IP', '92.113.145.171')}/crypto/webhook"
    }
}

# Стили причесок для LightX API
LIGHTX_HAIRSTYLE_STYLES = {
    "bob": "bob haircut, shoulder length, face framing, keep same face, focus on hair only",
    "long_layers": "long layered hair, face framing layers, keep same face, focus on hair only", 
    "pixie": "pixie haircut, short hair, textured, modern, face framing, keep same face, focus on hair only",
    "long_straight": "long straight hair, sleek, face framing, keep same face, focus on hair only",
    "curly": "curly hair, voluminous, natural curls, face framing, keep same face, focus on hair only",
    "wavy_bob": "wavy bob, textured, tousled, face framing, keep same face, focus on hair only",
    "blunt_bob": "blunt bob haircut, clean lines, sleek, face framing, keep same face, focus on hair only",
    "shag": "shag haircut, layers, textured, face framing, keep same face, focus on hair only",
    "side_part": "side part hairstyle, asymmetrical, face framing, keep same face, focus on hair only",
    "curtain_bangs": "curtain bangs, face framing, soft waves, keep same face, focus on hair only"
}

# Рекомендации по прическам для различных форм лица
HAIRSTYLE_RECOMMENDATIONS = {
    "OVAL": {
        "description": "У вас овальная форма лица — это идеальная и универсальная форма! Подходит практически любая прическа.",
        "recommend": [
            "Длинные распущенные волосы с легкими волнами",
            "Прямое каре любой длины",
            "Пикси с длинной челкой",
            "Боб с удлинением к лицу",
            "Кудрявые волосы любой длины"
        ],
        "avoid": [
            "Слишком объемные и пышные прически могут нарушить гармонию овального лица"
        ]
    },
    "ROUND": {
        "description": "У вас круглая форма лица с мягкими чертами и примерно одинаковой шириной и высотой.",
        "recommend": [
            "Удлиненное асимметричное каре",
            "Стрижки с удлиненной челкой набок",
            "Слоистые стрижки средней длины",
            "Высокий хвост с объемом на макушке",
            "Длинные прически с прямым пробором"
        ],
        "avoid": [
            "Очень короткие стрижки без объема на макушке",
            "Прически с округлыми контурами или пышными боковыми частями",
            "Прямая длинная челка до бровей",
            "Стрижки одной длины до подбородка"
        ]
    },
    "SQUARE": {
        "description": "У вас квадратная форма лица с сильным подбородком и широкой линией челюсти.",
        "recommend": [
            "Мягкие слоистые стрижки средней длины",
            "Длинные стрижки с волнами или кудрями",
            "Асимметричные прически",
            "Длинная косая челка",
            "Прически с объемом на макушке"
        ],
        "avoid": [
            "Прямые волосы одной длины до подбородка",
            "Геометрические стрижки с четкими линиями",
            "Прямой пробор",
            "Очень короткие и гладкие стрижки"
        ]
    },
    "HEART": {
        "description": "У вас сердцевидная форма лица с широким лбом и узким подбородком.",
        "recommend": [
            "Каре с удлинением к лицу",
            "Стрижки средней длины с объемом в области подбородка",
            "Стрижки с длинной челкой набок или многослойной челкой",
            "Прически, добавляющие объем по бокам в нижней части лица",
            "Низкий боковой хвост"
        ],
        "avoid": [
            "Слишком короткие стрижки, открывающие лоб",
            "Объемные прически на макушке",
            "Прямая густая челка",
            "Очень длинные волосы без слоев"
        ]
    },
    "DIAMOND": {
        "description": "У вас ромбовидная форма лица с выделяющимися скулами, узким лбом и подбородком.",
        "recommend": [
            "Средние и длинные стрижки с объемом в области лба и подбородка",
            "Боб с удлиненными передними прядями",
            "Каскадные стрижки средней длины",
            "Объемная челка или боковая челка",
            "Прически с пробором сбоку"
        ],
        "avoid": [
            "Гладкие прически, обтягивающие скулы",
            "Слишком короткие стрижки без объема по бокам",
            "Средняя длина волос без слоев",
            "Прически с прямым пробором"
        ]
    },
    "RECTANGULAR": {
        "description": "У вас прямоугольная форма лица — удлиненная версия квадратной формы.",
        "recommend": [
            "Стрижки средней длины с мягкими слоями",
            "Прически с объемной боковой или прямой челкой",
            "Волнистые или кудрявые текстуры",
            "Боб до подбородка",
            "Асимметричные стрижки"
        ],
        "avoid": [
            "Очень длинные прямые волосы без слоев",
            "Прически с объемом на макушке",
            "Отсутствие челки или зачесанные назад волосы",
            "Очень короткие стрижки"
        ]
    },
    "TRIANGLE": {
        "description": "У вас треугольная форма лица с узким лбом и широкой линией челюсти.",
        "recommend": [
            "Стрижки с объемом на макушке и у висков",
            "Удлиненная челка или длинная боковая челка",
            "Многослойные стрижки с объемом в верхней части",
            "Прически средней длины",
            "Пышные кудри или волны выше линии челюсти"
        ],
        "avoid": [
            "Прически с объемом в нижней части лица",
            "Длинные прямые волосы без слоев",
            "Прически, облегающие лицо по бокам",
            "Очень короткие стрижки, подчеркивающие челюсть"
        ]
    }
}