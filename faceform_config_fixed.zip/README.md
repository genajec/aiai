# FaceForm - Инструкция по установке на VPS

Этот архив содержит все необходимые файлы и инструкции для установки FaceForm бота на VPS-сервер.

## Содержимое архива

- `configs/` - Конфигурационные файлы
  - `config.py` - Основной конфигурационный файл бота
  - `.env` - Файл с переменными окружения
  - `systemd/` - Службы systemd для запуска бота и веб-сервера
  - `nginx/` - Конфигурация Nginx
- `scripts/` - Скрипты для запуска бота
  - `run_polling.py` - Скрипт для запуска бота в режиме polling
  - `run_bot_debug.py` - Отладочный скрипт для тестирования бота

## Инструкция по установке

### 1. Копирование конфигурационных файлов

```bash
# Копирование config.py
cp configs/config.py ~/faceform/config.py

# Копирование .env файла
cp configs/.env ~/faceform/.env

# Копирование скриптов запуска
cp scripts/run_polling.py ~/faceform/run_polling.py
cp scripts/run_bot_debug.py ~/faceform/run_bot_debug.py

# Установка прав на выполнение
chmod +x ~/faceform/run_polling.py
chmod +x ~/faceform/run_bot_debug.py
```

### 2. Настройка systemd служб

```bash
# Копирование и настройка служб systemd
sudo cp configs/systemd/faceform_bot.service /etc/systemd/system/
sudo cp configs/systemd/faceform_web.service /etc/systemd/system/

# Перезагрузка конфигурации systemd
sudo systemctl daemon-reload

# Запуск и настройка автозапуска служб
sudo systemctl enable faceform_bot
sudo systemctl enable faceform_web
sudo systemctl restart faceform_bot
sudo systemctl restart faceform_web
```

### 3. Настройка Nginx

```bash
# Копирование конфигурации Nginx
sudo cp configs/nginx/faceform.conf /etc/nginx/sites-available/

# Создание символической ссылки
sudo ln -sf /etc/nginx/sites-available/faceform.conf /etc/nginx/sites-enabled/

# Проверка конфигурации
sudo nginx -t

# Перезапуск Nginx
sudo systemctl restart nginx
```

### 4. Проверка работоспособности

```bash
# Проверка статуса бота
sudo systemctl status faceform_bot

# Проверка статуса веб-сервера
sudo systemctl status faceform_web

# Просмотр логов бота
sudo journalctl -u faceform_bot -n 50

# Просмотр логов веб-сервера
sudo journalctl -u faceform_web -n 50
```

## Устранение неполадок

Если бот не запускается, проверьте:

1. Логи systemd: `sudo journalctl -u faceform_bot -n 100`
2. Файл `.env` содержит все необходимые переменные окружения
3. Отсутствуют ошибки в файле `config.py`
4. Работу webhook: `curl "https://api.telegram.org/bot$TELEGRAM_BOT_TOKEN/getWebhookInfo"`
5. Попробуйте удалить webhook: `curl "https://api.telegram.org/bot$TELEGRAM_BOT_TOKEN/deleteWebhook?drop_pending_updates=true"`
6. Запустите отладочный скрипт: `python run_bot_debug.py`

## Поддержка

Если у вас возникли проблемы при установке или настройке, свяжитесь с поддержкой.