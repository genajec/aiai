#!/usr/bin/env python3
"""
Тестирование адаптера для process_video_with_grid
"""
import os
import logging
import process_video_with_grid
from process_video_adapter import process_video_with_grid_adapter

# Настройка логирования
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger(__name__)

def main():
    # Путь к тестовому видео
    input_video = "test_face_video.mp4"
    # Путь для сохранения результата
    output_video = "test_face_video_processed_new.mp4"
    
    if not os.path.exists(input_video):
        logger.error(f"Файл не найден: {input_video}")
        return
    
    # Загрузим видео в байтовый формат
    with open(input_video, 'rb') as f:
        video_data = f.read()
    
    def progress_callback(percent, stage):
        """Функция обратного вызова для отображения прогресса"""
        logger.info(f"Прогресс: {percent:.1f}% - Этап: {stage}")
    
    logger.info(f"Начинаем анализ видео через адаптер: {input_video}")
    # Используем адаптер вместо прямого вызова
    processed_video, analysis_results = process_video_with_grid_adapter(
        video_data, 
        progress_callback=progress_callback,
        return_analysis=True
    )
    
    if processed_video:
        # Сохраняем обработанное видео
        with open(output_video, 'wb') as f:
            f.write(processed_video)
        logger.info(f"Видео успешно обработано и сохранено: {output_video}")
        
        # Выводим результаты анализа
        logger.info(f"Результаты анализа формы лица:")
        logger.info(f"Форма лица: {analysis_results.get('face_shape', 'Не определена')}")
        logger.info(f"Соотношение ширины/длины: {analysis_results.get('width_to_length_ratio', 0):.2f}")
        logger.info(f"Соотношение лоб/линия челюсти: {analysis_results.get('forehead_to_jawline_ratio', 0):.2f}")
        logger.info(f"Соотношение скулы/линия челюсти: {analysis_results.get('cheekbone_to_jawline_ratio', 0):.2f}")
        
        if 'face_shape_counts' in analysis_results:
            logger.info("Распределение форм лица в кадрах:")
            for shape, count in analysis_results['face_shape_counts'].items():
                logger.info(f"  {shape}: {count}")
    else:
        logger.error("Ошибка при обработке видео")

if __name__ == "__main__":
    main()