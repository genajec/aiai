#!/usr/bin/env python3
# -*- coding: utf-8 -*-

import logging
import requests
import io
import sys
import os
from lightx_client import LightXClient
from PIL import Image

# Enable logging
logging.basicConfig(format='%(asctime)s - %(name)s - %(levelname)s - %(message)s', level=logging.INFO)
logger = logging.getLogger(__name__)

def main():
    # Получаем путь к изображению
    if len(sys.argv) < 2:
        print("Использование: python test_object_removal.py <путь_к_изображению>")
        print("Пример: python test_object_removal.py demo_base_face.jpg")
        return
    
    image_path = sys.argv[1]
    
    print(f"\n=== Тестирование функции удаления объектов ===")
    print(f"Исходное изображение: {image_path}")
    
    try:
        # Загружаем изображение
        if not os.path.exists(image_path):
            print(f"✖ Ошибка: Файл {image_path} не найден")
            return
            
        with open(image_path, "rb") as f:
            image_data = f.read()
            
        print(f"✓ Изображение успешно загружено, размер: {len(image_data)} байт")
        
        # Инициализируем LightX API клиент
        print("\nИнициализация LightX API клиента...")
        lightx_client = LightXClient()
        print("✓ LightX API клиент успешно инициализирован")
        
        # Удаляем объекты
        print(f"\nОтправка запроса на автоматическое удаление объектов...")
        result_image = lightx_client.remove_objects(image_data)
        
        if result_image:
            print("✓ Объекты успешно удалены!")
            
            # Сохраняем изображение в файл
            output_path = "objects_removed_image.jpg"
            with open(output_path, "wb") as f:
                f.write(result_image)
            print(f"Изображение с удаленными объектами сохранено в файл: {output_path}")
            
            # Показываем информацию о размере обработанного изображения
            img = Image.open(io.BytesIO(result_image))
            print(f"Размер изображения: {img.width}x{img.height}")
        else:
            print("✖ Ошибка при удалении объектов через LightX API")
    
    except Exception as e:
        print(f"✖ Ошибка при работе с LightX API: {e}")

if __name__ == "__main__":
    main()