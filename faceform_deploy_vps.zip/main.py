import os
import json
import stripe
import logging
from flask import Flask, render_template, request, redirect, jsonify, url_for, flash, session
from flask_wtf.csrf import CSRFProtect
from werkzeug.utils import secure_filename
import cv2
import numpy as np
from face_analyzer import FaceAnalyzer
from database import Session, User, Transaction
import time
from stripe_payment import StripePayment
from dotenv import load_dotenv

# Загрузка переменных окружения
load_dotenv()

# Настройка логирования
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(name)s - %(levelname)s - %(message)s')
logger = logging.getLogger(__name__)

# Инициализация Flask
app = Flask(__name__)
# Установка секретного ключа для сессий
session_secret = os.environ.get("SESSION_SECRET")
if not session_secret:
    # Генерируем секретный ключ и сохраняем его для будущих запусков
    session_secret = os.urandom(24).hex()
    # Если .env файл существует, добавляем ключ туда
    env_path = os.path.join(os.path.dirname(__file__), '.env')
    if os.path.exists(env_path):
        with open(env_path, 'a') as f:
            f.write(f"\nSESSION_SECRET={session_secret}\n")
        logger.info(f"Generated and saved new SESSION_SECRET to .env file")
    
app.secret_key = session_secret
logger.info(f"Flask application initialized with secret key")

# Инициализация CSRF защиты
csrf = CSRFProtect(app)
# Отключаем CSRF для webhook-маршрутов Stripe
csrf.exempt('stripe_webhook')

# Инициализация Stripe
stripe_payment = StripePayment()
stripe.api_key = os.environ.get("STRIPE_SECRET_KEY")

# Инициализация анализатора лиц
face_analyzer = FaceAnalyzer()

# Путь для загрузки файлов
UPLOAD_FOLDER = 'static/uploads'
os.makedirs(UPLOAD_FOLDER, exist_ok=True)
app.config['UPLOAD_FOLDER'] = UPLOAD_FOLDER

# Допустимые расширения файлов
ALLOWED_EXTENSIONS = {'png', 'jpg', 'jpeg'}

def allowed_file(filename):
    return '.' in filename and filename.rsplit('.', 1)[1].lower() in ALLOWED_EXTENSIONS

@app.route('/')
def home():
    return render_template('index.html')

@app.route('/about')
def about():
    return render_template('about.html')

@app.route('/services')
def services():
    return render_template('services.html')

@app.route('/hairstyles')
def hairstyles():
    # Получаем данные о доступных прическах для всех форм лица
    face_shapes = ["OVAL", "ROUND", "SQUARE", "HEART", "OBLONG", "DIAMOND"]
    all_hairstyles = {}
    
    for shape in face_shapes:
        male_hairstyles = face_analyzer.get_hairstyle_names(shape, "male")
        female_hairstyles = face_analyzer.get_hairstyle_names(shape, "female")
        all_hairstyles[shape] = {
            'male': male_hairstyles,
            'female': female_hairstyles
        }
        
    return render_template('hairstyles.html', all_hairstyles=all_hairstyles)

@app.route('/try-hairstyle', methods=['GET', 'POST'])
def try_hairstyle():
    if request.method == 'POST':
        # Проверяем, есть ли файл в запросе
        if 'file' not in request.files:
            flash('Файл не найден')
            return redirect(request.url)
            
        file = request.files['file']
        
        # Если пользователь не выбрал файл
        if file.filename == '':
            flash('Файл не выбран')
            return redirect(request.url)
            
        if file and allowed_file(file.filename):
            # Сохраняем файл
            filename = secure_filename(file.filename)
            file_path = os.path.join(app.config['UPLOAD_FOLDER'], filename)
            file.save(file_path)
            
            # Читаем изображение из файла вместо из памяти
            with open(file_path, 'rb') as image_file:
                image_data = image_file.read()
            
            # Анализируем форму лица
            face_shape, vis_image_bytes, measurements = face_analyzer.analyze_face_shape(image_data)
            
            if not face_shape:
                flash('Не удалось определить форму лица. Пожалуйста, загрузите другую фотографию.')
                return redirect(request.url)
                
            # Получаем доступные прически для данной формы лица
            male_hairstyles = face_analyzer.get_hairstyle_names(face_shape, "male")
            female_hairstyles = face_analyzer.get_hairstyle_names(face_shape, "female")
            
            # Сохраняем данные в сессии
            session['face_shape'] = face_shape
            session['original_image'] = file_path
            
            # Сохраняем изображение с визуализацией
            vis_image_path = os.path.join(app.config['UPLOAD_FOLDER'], 'vis_' + filename)
            with open(vis_image_path, 'wb') as f:
                f.write(vis_image_bytes)
            
            return render_template('try_hairstyle.html', 
                                  face_shape=face_shape, 
                                  original_image=file_path.replace('static/', ''),
                                  vis_image=vis_image_path.replace('static/', ''),
                                  male_hairstyles=male_hairstyles,
                                  female_hairstyles=female_hairstyles)
    
    return render_template('try_hairstyle.html')

@app.route('/apply-hairstyle', methods=['POST'])
def apply_hairstyle():
    # Получаем данные из запроса
    data = request.get_json()
    hairstyle_index = int(data.get('hairstyle_index', 0))
    gender = data.get('gender', 'male')
    
    # Получаем данные из сессии
    face_shape = session.get('face_shape')
    original_image_path = session.get('original_image')
    
    if not face_shape or not original_image_path:
        return jsonify({'error': 'Данные о лице отсутствуют, загрузите фото снова'})
    
    try:
        # Читаем изображение
        with open(original_image_path, 'rb') as f:
            image_data = f.read()
        
        # Применяем прическу
        result_image_bytes = face_analyzer.apply_hairstyle(
            image_data=image_data,
            face_shape=face_shape,
            hairstyle_index=hairstyle_index
        )
        
        if not result_image_bytes:
            return jsonify({'error': 'Не удалось применить прическу'})
        
        # Сохраняем результат
        result_filename = f"result_{time.time()}.jpg"
        result_path = os.path.join(app.config['UPLOAD_FOLDER'], result_filename)
        with open(result_path, 'wb') as f:
            f.write(result_image_bytes)
        
        return jsonify({'success': True, 'image_url': f"/static/uploads/{result_filename}"})
    
    except Exception as e:
        logger.error(f"Ошибка при применении прически: {e}")
        return jsonify({'error': f'Произошла ошибка: {str(e)}'})

@app.route('/pricing')
def pricing():
    packages = stripe_payment.get_credit_packages()
    return render_template('pricing.html', packages=packages)

@app.route('/create-checkout-session', methods=['POST'])
def create_checkout_session():
    try:
        # Получаем ID пакета из запроса
        package_id = request.form.get('package_id')
        logger.info(f"Получен запрос на создание сессии оплаты для пакета: {package_id}")
        
        if not package_id:
            logger.error("Package ID не был передан в форме")
            return jsonify({'error': 'Package ID is required'}), 400
        
        # Находим пакет по ID
        packages = stripe_payment.get_credit_packages()
        package = next((p for p in packages if p['id'] == package_id), None)
        
        if not package:
            logger.error(f"Пакет с ID {package_id} не найден в списке доступных пакетов")
            return jsonify({'error': 'Invalid package ID'}), 400
        
        # Получаем домен для URL успеха и отмены
        domain = stripe_payment._get_domain()
        logger.info(f"Домен для редиректа: {domain}")
        
        # Создаем сессию оплаты в Stripe
        logger.info(f"Создаем сессию оплаты для пакета {package['name']} стоимостью {package['price']}$")
        
        checkout_session = stripe.checkout.Session.create(
            payment_method_types=['card'],
            line_items=[
                {
                    'price_data': {
                        'currency': 'usd',
                        'product_data': {
                            'name': package['description'],
                        },
                        'unit_amount': int(package['price'] * 100),  # стоимость в центах
                    },
                    'quantity': 1,
                },
            ],
            mode='payment',
            success_url=f'https://{domain}/success?session_id={{CHECKOUT_SESSION_ID}}',
            cancel_url=f'https://{domain}/cancel',
            metadata={
                'package_id': package_id,
                'credits': package['credits'],
                'user_id': session.get('user_id', 'website_user')
            }
        )
        
        logger.info(f"Сессия оплаты создана успешно. ID: {checkout_session.id}")
        
        # Сохраняем транзакцию в базе данных
        db_session = Session()
        try:
            # Получаем или создаем пользователя для этой транзакции
            telegram_id = session.get('user_id', 0)
            logger.info(f"ID пользователя из сессии: {telegram_id}")
            
            # Используем функцию из database.py для получения или создания пользователя
            from database import get_or_create_user
            user = get_or_create_user(
                telegram_id=telegram_id,
                username="website_user"
            )
            
            logger.info(f"Пользователь получен/создан: ID в БД: {user.id}, telegram_id: {user.telegram_id}")
            
            # Создаем транзакцию с правильным user_id
            transaction = Transaction(
                user_id=user.id,  # Используем ID пользователя из БД
                payment_id=checkout_session.id,
                payment_method='stripe',
                amount=package['price'],
                credits=package['credits'],
                status='pending'
            )
            db_session.add(transaction)
            db_session.commit()
            
            # Сохраняем ID транзакции в сессии для отслеживания
            session['transaction_id'] = transaction.id
            logger.info(f"Транзакция создана и сохранена в БД. ID: {transaction.id}")
            
        except Exception as db_error:
            logger.error(f"Ошибка базы данных: {db_error}")
        finally:
            db_session.close()
        
        # Перенаправляем пользователя на страницу оплаты Stripe
        logger.info(f"Перенаправляем пользователя на страницу оплаты: {checkout_session.url}")
        return redirect(checkout_session.url, code=303)
    
    except Exception as e:
        logger.error(f"Ошибка при создании сессии оплаты: {str(e)}")
        import traceback
        logger.error(traceback.format_exc())
        
        # Возвращаем ошибку на страницу
        flash('Произошла ошибка при создании платежа. Пожалуйста, попробуйте позже.', 'danger')
        return redirect(url_for('pricing'))

@app.route('/success')
def payment_success():
    session_id = request.args.get('session_id')
    if session_id:
        try:
            # Retrieve the session from Stripe
            checkout_session = stripe.checkout.Session.retrieve(session_id)
            
            # Check if payment was successful
            if checkout_session.payment_status == 'paid':
                # Extract metadata
                package_id = checkout_session.metadata.get('package_id')
                credits = int(checkout_session.metadata.get('credits', 0))
                
                # Обновляем статус транзакции и начисляем кредиты пользователю
                from database import complete_transaction
                transaction_completed = complete_transaction(session_id, 'completed')
                
                if transaction_completed:
                    logger.info(f"Transaction {session_id} successfully completed and credits awarded")
                
                # Достаем информацию о трнзакции для отображения
                db_session = Session()
                try:
                    transaction = db_session.query(Transaction).filter_by(payment_id=session_id).first()
                    if transaction:
                        # Получаем информацию о пользователе
                        user = db_session.query(User).filter_by(id=transaction.user_id).first()
                        if user:
                            # Обновляем идентификатор пользователя в сессии
                            session['user_id'] = user.telegram_id
                except Exception as db_error:
                    logger.error(f"Database error: {db_error}")
                finally:
                    db_session.close()
                
                return render_template('success.html', credits=credits)
        
        except Exception as e:
            logger.error(f"Error processing success page: {e}")
    
    return render_template('success.html')

@app.route('/cancel')
def payment_cancel():
    return render_template('cancel.html')

@app.route('/webhook', methods=['POST'])
def stripe_webhook():
    payload = request.get_data(as_text=True)
    sig_header = request.headers.get('Stripe-Signature')
    
    try:
        event = stripe.Webhook.construct_event(
            payload, sig_header, os.environ.get('STRIPE_WEBHOOK_SECRET', '')
        )
    except ValueError as e:
        # Invalid payload
        logger.error(f"Invalid payload: {e}")
        return jsonify({'error': 'Invalid payload'}), 400
    except stripe.error.SignatureVerificationError as e:
        # Invalid signature
        logger.error(f"Invalid signature: {e}")
        return jsonify({'error': 'Invalid signature'}), 400
    
    # Handle the event
    if event['type'] == 'checkout.session.completed':
        session = event['data']['object']
        session_id = session.id
        
        logger.info(f"Received webhook for completed session {session_id}")
        
        # Используем функцию из database.py для завершения транзакции и начисления кредитов
        from database import complete_transaction
        transaction_completed = complete_transaction(session_id, 'completed')
        
        if transaction_completed:
            logger.info(f"Transaction {session_id} successfully completed via webhook")
        else:
            logger.warning(f"Failed to complete transaction {session_id} via webhook")
    
    return jsonify({'status': 'success'})

@app.route('/contact')
def contact():
    return render_template('contact.html')

if __name__ == '__main__':
    # Используем порт 8080 вместо 5000, так как порт 5000 уже занят
    port = 8080
    logger.info(f"Starting Flask application on port {port}")
    app.run(host='0.0.0.0', port=port, debug=True)