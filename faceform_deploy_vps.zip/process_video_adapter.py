"""
Адаптер для обеспечения совместимости с новой версией process_video_with_grid
"""
import logging
import process_video_with_grid

logger = logging.getLogger(__name__)

def process_video_with_grid_adapter(video_data, progress_callback=None, return_analysis=False, **kwargs):
    """
    Адаптер для совместимости старого и нового API обработки видео
    
    Args:
        video_data: Данные видео в формате bytes
        progress_callback: Функция обратного вызова для отображения прогресса (игнорируется в новой версии)
        return_analysis: Флаг, указывающий нужно ли возвращать результаты анализа
        **kwargs: Дополнительные параметры для обратной совместимости
        
    Returns:
        tuple: (processed_video_bytes, analysis_results) или processed_video_bytes
    """
    try:
        logger.info("Вызов новой версии процессора видео")
        
        # Если передана функция обратного вызова, добавляем обработчик прогресса
        if progress_callback:
            # Создаем функцию-обработчик, которая будет периодически обновлять прогресс обработки
            def update_progress_handler():
                # Получаем текущие данные о прогрессе
                percent = process_video_with_grid.processing_progress['percentage']
                stage = process_video_with_grid.processing_progress['processing_stage']
                remaining_time = process_video_with_grid.processing_progress['remaining_time']
                
                # Вызываем оригинальную функцию обратного вызова
                progress_callback(percent, stage, remaining_time)
                
            # Создаем функцию периодического обновления
            def update_progress_periodic():
                import time
                while process_video_with_grid.processing_progress['percentage'] < 100:
                    update_progress_handler()
                    time.sleep(0.5)  # Обновляем каждые 500 миллисекунд
            
            # Запускаем обработчик обновления в отдельном потоке
            import threading
            progress_thread = threading.Thread(target=update_progress_periodic)
            progress_thread.daemon = True  # Поток будет автоматически завершен при выходе из основного потока
            progress_thread.start()  # Запускаем поток
        
        # Вызов новой версии функции (принимает только video_data)
        processed_video = process_video_with_grid.process_video_with_grid(video_data)
        
        # Получаем результаты анализа из глобальной переменной
        analysis_results = {
            'face_shape': process_video_with_grid.processing_progress['most_common_shape'],
            'width_to_length_ratio': process_video_with_grid.processing_progress['width_to_length_ratio'],
            'forehead_to_jawline_ratio': process_video_with_grid.processing_progress['forehead_to_jawline_ratio'],
            'cheekbone_to_jawline_ratio': process_video_with_grid.processing_progress['cheekbone_to_jawline_ratio'],
            'face_shape_counts': process_video_with_grid.processing_progress['face_shape_counts'],
            'normalized_scores': process_video_with_grid.processing_progress['normalized_scores'],
            'remaining_time': process_video_with_grid.processing_progress['remaining_time'],
            'elapsed_time': process_video_with_grid.processing_progress['elapsed_time'],
            'vertical_asymmetry': process_video_with_grid.processing_progress.get('vertical_asymmetry', 0.10),
            'horizontal_asymmetry': process_video_with_grid.processing_progress.get('horizontal_asymmetry', 0.12)
        }
        
        # Если нужно возвращать результаты анализа
        if return_analysis:
            return processed_video, analysis_results
        
        # Иначе возвращаем только обработанное видео
        return processed_video
    except Exception as e:
        logger.error(f"Ошибка в адаптере обработки видео: {e}")
        if return_analysis:
            return None, None
        return None