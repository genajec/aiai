from sqlalchemy import Column, Integer, String, Float, DateTime, ForeignKey, Boolean
from sqlalchemy.ext.declarative import declarative_base
import datetime

Base = declarative_base()

class User(Base):
    """Модель пользователя Telegram"""
    __tablename__ = 'users'
    
    id = Column(Integer, primary_key=True)
    telegram_id = Column(Integer, unique=True, nullable=False)
    username = Column(String, nullable=True)
    first_name = Column(String, nullable=True)
    last_name = Column(String, nullable=True)
    credits = Column(Integer, default=0)  # Количество кредитов у пользователя
    registered_at = Column(DateTime, default=datetime.datetime.utcnow)
    
class Transaction(Base):
    """Модель транзакций приобретения кредитов"""
    __tablename__ = 'transactions'
    
    id = Column(Integer, primary_key=True)
    user_id = Column(Integer, ForeignKey('users.id'), nullable=False)
    amount = Column(Float, nullable=False)  # Сумма в долларах
    credits = Column(Integer, nullable=False)  # Количество приобретенных кредитов
    status = Column(String, nullable=False, default='pending')  # pending, completed, failed
    payment_id = Column(String, nullable=True)  # ID платежа в платежной системе
    payment_method = Column(String, nullable=True)  # Метод оплаты (card, crypto, etc.)
    created_at = Column(DateTime, default=datetime.datetime.utcnow)
    completed_at = Column(DateTime, nullable=True)
    updated_at = Column(DateTime, nullable=True)  # Время последнего обновления статуса
    
class CreditUsage(Base):
    """Модель использования кредитов"""
    __tablename__ = 'credit_usages'
    
    id = Column(Integer, primary_key=True)
    user_id = Column(Integer, ForeignKey('users.id'), nullable=False)
    feature = Column(String, nullable=False)  # Название функции, которая использовала кредит
    credits_used = Column(Integer, default=1)  # Количество использованных кредитов
    created_at = Column(DateTime, default=datetime.datetime.utcnow)