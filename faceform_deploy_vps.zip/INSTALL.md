# FaceForm VPS Installation Guide

This document provides instructions for installing the FaceForm web application on a VPS server.

## System Requirements

- Python 3.8 or higher
- Nginx
- PostgreSQL (optional, SQLite included)
- 2GB RAM minimum
- 10GB free disk space

## Installation Steps

### 1. Update the server and install dependencies

```bash
sudo apt update
sudo apt upgrade -y
sudo apt install -y python3-pip python3-venv nginx libpq-dev python3-dev build-essential
```

### 2. Create a directory for the application

```bash
mkdir -p /var/www/faceform
cd /var/www/faceform
```

### 3. Copy the application files

Upload the contents of this archive to the `/var/www/faceform` directory on your server.

### 4. Set up Python virtual environment

```bash
python3 -m venv venv
source venv/bin/activate
pip install --upgrade pip
pip install -r requirements.txt
```

### 5. Configure the environment variables

Copy the `.env.example` file to `.env` and edit it to include your configurations:

```bash
cp .env.example .env
nano .env
```

Make sure to update the following in the `.env` file:
- `STRIPE_SECRET_KEY` - Your Stripe secret key
- `SESSION_SECRET` - A random string for session encryption
- `DATABASE_URL` - Optional, if using PostgreSQL

### 6. Configure Nginx

Copy the provided nginx configuration:

```bash
sudo cp nginx_config.conf /etc/nginx/sites-available/faceform
```

Edit the configuration to match your server settings:

```bash
sudo nano /etc/nginx/sites-available/faceform
```

Update the `server_name` directive to match your domain and the path in the `alias` directive for static files.

Enable the site:

```bash
sudo ln -s /etc/nginx/sites-available/faceform /etc/nginx/sites-enabled/
sudo rm /etc/nginx/sites-enabled/default  # Remove default site if needed
sudo nginx -t  # Test the configuration
sudo systemctl restart nginx
```

### 7. Set up Gunicorn service

Create a systemd service file:

```bash
sudo nano /etc/systemd/system/faceform.service
```

Add the following content:

```
[Unit]
Description=FaceForm Gunicorn Service
After=network.target

[Service]
User=www-data
Group=www-data
WorkingDirectory=/var/www/faceform
ExecStart=/var/www/faceform/venv/bin/gunicorn -c gunicorn_config.py main:app
Restart=always

[Install]
WantedBy=multi-user.target
```

Start and enable the service:

```bash
sudo chown -R www-data:www-data /var/www/faceform
sudo systemctl start faceform
sudo systemctl enable faceform
```

### 8. Configure firewall (if needed)

```bash
sudo ufw allow 'Nginx Full'
sudo ufw allow ssh
sudo ufw enable
```

### 9. Check the application status

```bash
sudo systemctl status faceform
```

Visit your server's IP address or domain in a web browser to verify the application is running.

## Troubleshooting

Check the logs for errors:

```bash
sudo journalctl -u faceform -f  # View Gunicorn service logs
tail -f /var/www/faceform/error.log  # View Gunicorn application logs
tail -f /var/log/nginx/error.log  # View Nginx error logs
```

## Updating the Application

To update the application:

1. Upload the new files
2. Restart the service:

```bash
sudo systemctl restart faceform
```

## Security Considerations

- Consider using HTTPS by installing a Let's Encrypt certificate
- Ensure proper file permissions (files owned by www-data)
- Keep the system and packages updated regularly