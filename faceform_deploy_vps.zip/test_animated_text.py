"""
Тестирование анимации текста при обработке видео
"""
import os
import cv2
import numpy as np
import tempfile
import time
import logging
import process_video_with_grid

# Настраиваем логгирование
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(name)s - %(levelname)s - %(message)s')
logger = logging.getLogger(__name__)

def create_test_video(output_path="test_video.mp4", duration_sec=5, fps=30):
    """
    Создает тестовое видео с изображением лица для тестирования обработки видео.
    
    Args:
        output_path (str): Путь для сохранения выходного видео
        duration_sec (int): Длительность видео в секундах
        fps (int): Частота кадров в секунду
    
    Returns:
        str: Путь к созданному видеофайлу или None в случае ошибки
    """
    try:
        # Размеры видео
        width, height = 640, 480
        
        # Создаем простое изображение с кругом (имитация лица)
        img = np.zeros((height, width, 3), dtype=np.uint8)
        cv2.circle(img, (width//2, height//2), 100, (200, 200, 200), -1)  # Круг как "лицо"
        cv2.circle(img, (width//2 - 30, height//2 - 30), 10, (50, 50, 50), -1)  # Левый глаз
        cv2.circle(img, (width//2 + 30, height//2 - 30), 10, (50, 50, 50), -1)  # Правый глаз
        cv2.ellipse(img, (width//2, height//2 + 20), (30, 10), 0, 0, 180, (50, 50, 50), -1)  # Улыбка
        
        # Создаем видеофайл
        fourcc = cv2.VideoWriter_fourcc(*'mp4v')
        out = cv2.VideoWriter(output_path, fourcc, fps, (width, height))
        
        # Записываем кадры
        for _ in range(fps * duration_sec):
            out.write(img)
        
        # Освобождаем ресурсы
        out.release()
        
        logger.info(f"Создано тестовое видео: {output_path}")
        return output_path
    
    except Exception as e:
        logger.error(f"Ошибка при создании тестового видео: {e}")
        return None

def test_animated_text():
    """
    Тестирует функционал анимированного текста при обработке видео
    """
    logger.info("Начинаем тестирование анимированного текста")
    
    # Создаем тестовое видео
    video_path = create_test_video()
    if not video_path:
        logger.error("Не удалось создать тестовое видео")
        return False
    
    try:
        # Считываем видео в байтах
        with open(video_path, 'rb') as f:
            video_data = f.read()
        
        # Запускаем обработку
        logger.info("Запускаем обработку видео...")
        start_time = time.time()
        
        # Обрабатываем видео
        result_video = process_video_with_grid.process_video_with_grid(video_data)
        
        # Проверяем результат
        if result_video:
            elapsed_time = time.time() - start_time
            logger.info(f"Видео успешно обработано за {elapsed_time:.2f} секунд")
            
            # Сохраняем результат для проверки
            result_path = "animated_text_result.mp4"
            with open(result_path, 'wb') as f:
                f.write(result_video)
            
            logger.info(f"Результат сохранен в {result_path}")
            logger.info("Тест успешно завершен!")
            return True
        else:
            logger.error("Ошибка при обработке видео - результат пустой")
            return False
        
    except Exception as e:
        logger.error(f"Ошибка при тестировании: {e}")
        return False
    finally:
        # Удаляем временные файлы
        try:
            os.remove(video_path)
        except:
            pass

if __name__ == "__main__":
    test_animated_text()