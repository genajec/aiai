/**
 * Основной JavaScript файл для сайта FaceForm
 */
document.addEventListener('DOMContentLoaded', function() {
    // Инициализация всплывающих подсказок Bootstrap
    const tooltipTriggerList = [].slice.call(document.querySelectorAll('[data-bs-toggle="tooltip"]'));
    tooltipTriggerList.map(function (tooltipTriggerEl) {
        return new bootstrap.Tooltip(tooltipTriggerEl);
    });
    
    // Обработка прокрутки для фиксированной навигации
    const navbar = document.querySelector('.navbar');
    if (navbar) {
        window.addEventListener('scroll', function() {
            if (window.scrollY > 50) {
                navbar.classList.add('navbar-scrolled', 'shadow-sm');
            } else {
                navbar.classList.remove('navbar-scrolled', 'shadow-sm');
            }
        });
    }
    
    // Проверка и обработка загрузки изображений
    const imageUploadInputs = document.querySelectorAll('input[type="file"].image-upload');
    
    imageUploadInputs.forEach(input => {
        input.addEventListener('change', function(e) {
            const file = e.target.files[0];
            
            if (file) {
                // Проверяем, является ли файл изображением
                if (!file.type.match('image.*')) {
                    alert('Пожалуйста, загрузите изображение');
                    input.value = '';
                    return;
                }
                
                // Проверяем размер файла (максимум 5 МБ)
                const maxSize = 5 * 1024 * 1024; // 5 МБ в байтах
                if (file.size > maxSize) {
                    alert('Размер файла слишком большой. Максимальный размер: 5 МБ');
                    input.value = '';
                    return;
                }
                
                // Если у этого инпута есть предпросмотр
                const previewContainer = input.closest('.upload-container').querySelector('.image-preview');
                if (previewContainer) {
                    const reader = new FileReader();
                    
                    reader.onload = function(e) {
                        previewContainer.style.display = 'block';
                        previewContainer.src = e.target.result;
                    };
                    
                    reader.readAsDataURL(file);
                }
            }
        });
    });
    
    // Улучшение работы с формами
    const forms = document.querySelectorAll('form:not([data-no-enhance])');
    
    forms.forEach(form => {
        // Добавляем валидацию HTML5
        form.addEventListener('submit', function(e) {
            if (!form.checkValidity()) {
                e.preventDefault();
                e.stopPropagation();
            }
            
            form.classList.add('was-validated');
        });
    });
    
    // Обработка темной темы
    const toggleSwitch = document.querySelector('.theme-switch input[type="checkbox"]');
    
    if (toggleSwitch) {
        toggleSwitch.addEventListener('change', switchTheme, false);
        
        // Проверяем, сохранена ли тема в localStorage
        if (localStorage.getItem('theme')) {
            document.documentElement.setAttribute('data-theme', localStorage.getItem('theme'));
            
            if (localStorage.getItem('theme') === 'dark') {
                toggleSwitch.checked = true;
            }
        }
    }
    
    function switchTheme(e) {
        if (e.target.checked) {
            document.documentElement.setAttribute('data-theme', 'dark');
            localStorage.setItem('theme', 'dark');
        }
        else {
            document.documentElement.setAttribute('data-theme', 'light');
            localStorage.setItem('theme', 'light');
        }    
    }
    
    // Обработка клика по кнопке "Наверх"
    const scrollToTopBtn = document.getElementById('scrollToTop');
    
    if (scrollToTopBtn) {
        window.addEventListener('scroll', function() {
            if (window.scrollY > 300) {
                scrollToTopBtn.classList.add('show');
            } else {
                scrollToTopBtn.classList.remove('show');
            }
        });
        
        scrollToTopBtn.addEventListener('click', function() {
            window.scrollTo({
                top: 0,
                behavior: 'smooth'
            });
        });
    }
    
    // Для страницы примерки причёсок - обработка загрузки и отображения
    const photoForm = document.getElementById('uploadForm');
    
    if (photoForm) {
        const photoInput = document.getElementById('photoInput');
        const loadingIndicator = document.querySelector('.loading-indicator');
        
        if (photoInput && loadingIndicator) {
            photoForm.addEventListener('submit', function() {
                if (photoInput.files.length > 0) {
                    loadingIndicator.style.display = 'flex';
                }
            });
        }
    }
});