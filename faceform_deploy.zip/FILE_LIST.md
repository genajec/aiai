# Список файлов для переноса на VPS

## Основные файлы приложения
- main.py
- bot.py
- config.py
- database.py
- face_analyzer.py
- stripe_payment.py
- crypto_bot_payment.py
- background_fallback.py
- models.py
- lightx_client.py (если есть)
- lightx_key_manager.py (если есть)
- face_attractiveness.py (если есть)
- hairstyle_recommender.py (если есть)
- hairstyle_overlay.py (если есть)
- process_video_with_grid.py (если есть)

## Файлы шаблонов
- templates/index.html
- templates/base.html
- templates/features.html
- templates/pricing.html
- templates/about.html
- templates/checkout.html
- templates/payment-complete.html
- templates/cancel.html
- templates/error.html
- templates/success.html

## Статические файлы
- static/css/main.css
- static/images/logo.svg
- static/images/hero-bg.svg

## Файлы конфигурации
- .env (создайте из .env.example с вашими API ключами)
- requirements_vps.txt (создайте файл с необходимыми зависимостями)

## Инструкции
- DEPLOY_GUIDE.md
- INSTALL_VPS_FULL.md
- WEBHOOKS_SETUP.md
- SECURITY_MEASURES.md

## Шаги для архивирования:

1. Скачайте все файлы в одну директорию на локальном компьютере
2. Создайте следующую структуру директорий:
   ```
   faceform_deploy/
   ├── templates/
   ├── static/
   │   ├── css/
   │   ├── images/
   ├── deployment/
   ```

3. Разместите файлы в соответствующих директориях

4. Создайте файл requirements_vps.txt со следующим содержимым:
   ```
   flask
   flask-sqlalchemy
   gunicorn
   python-dotenv
   pytelegrambotapi
   stripe
   opencv-python
   numpy
   mediapipe
   psycopg2-binary
   requests
   pillow
   ```

5. Создайте архив:
   ```bash
   zip -r faceform_deploy.zip faceform_deploy/
   ```

6. Загрузите архив на VPS:
   ```bash
   scp faceform_deploy.zip faceform@92.113.145.171:~/
   ```

7. Распакуйте архив на VPS и следуйте инструкциям из DEPLOY_GUIDE.md