#!/usr/bin/env python
"""
Скрипт для запуска бота на VPS в режиме polling
"""

import os
import sys
import time
import logging
import telebot
from bot import FaceShapeBot
from dotenv import load_dotenv
import signal
import atexit

# Загружаем переменные окружения из .env файла
load_dotenv()

# Настраиваем логирование
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    handlers=[
        logging.StreamHandler(sys.stdout),
        logging.FileHandler('bot_vps.log')
    ]
)
logger = logging.getLogger(__name__)

# Глобальные переменные
bot_instance = None
is_running = True

def signal_handler(sig, frame):
    """Обработка сигналов завершения для корректного выхода"""
    global is_running
    logger.info("Получен сигнал завершения, останавливаем бота...")
    is_running = False
    
    if bot_instance and hasattr(bot_instance, 'bot'):
        try:
            logger.info("Останавливаем поллинг бота...")
            bot_instance.bot.stop_polling()
        except Exception as e:
            logger.error(f"Ошибка при остановке поллинга: {e}")
    
    logger.info("Бот остановлен")
    sys.exit(0)

def cleanup():
    """Функция очистки ресурсов при завершении работы"""
    logger.info("Выполняется очистка ресурсов...")
    global bot_instance, is_running
    
    is_running = False
    
    if bot_instance and hasattr(bot_instance, 'bot'):
        try:
            logger.info("Останавливаем поллинг бота в функции очистки...")
            bot_instance.bot.stop_polling()
        except Exception as e:
            logger.error(f"Ошибка при остановке поллинга в функции очистки: {e}")

def main():
    """
    Запуск бота в режиме polling с обработкой ошибок и автоматическим перезапуском
    """
    global bot_instance, is_running
    
    # Получаем токен из переменных окружения
    token = os.environ.get("TELEGRAM_API_TOKEN")
    if not token:
        logger.error("TELEGRAM_API_TOKEN не найден в переменных окружения!")
        sys.exit(1)
    
    logger.info("Запуск бота в режиме polling на VPS")
    
    # Обработка сигналов для корректного завершения
    signal.signal(signal.SIGINT, signal_handler)
    signal.signal(signal.SIGTERM, signal_handler)
    
    # Регистрация функции очистки ресурсов
    atexit.register(cleanup)
    
    # Удаляем старый webhook перед запуском polling
    try:
        logger.info("Удаляем webhook перед запуском режима polling...")
        bot = telebot.TeleBot(token)
        bot.delete_webhook()
        logger.info("Webhook успешно удален")
    except Exception as e:
        logger.error(f"Ошибка при удалении webhook: {e}")
    
    # Основной цикл с автоматическим перезапуском при ошибках
    retry_count = 0
    max_retries = 5
    retry_delay = 10  # начальная задержка в секундах
    
    while is_running:
        try:
            logger.info(f"Попытка запуска бота #{retry_count + 1}")
            
            # Создаем экземпляр бота с отключенным webhook
            bot_instance = FaceShapeBot(use_webhook=False)
            
            # Выводим информацию о запуске
            logger.info("Бот запущен успешно. Работает в режиме polling.")
            
            # Сбрасываем счетчик попыток после успешного запуска
            retry_count = 0
            retry_delay = 10
            
            # Запускаем бота
            bot_instance.run()
            
        except Exception as e:
            logger.error(f"Ошибка при работе бота: {e}")
            import traceback
            logger.error(traceback.format_exc())
            
            retry_count += 1
            
            if retry_count > max_retries:
                logger.critical(f"Превышено максимальное количество попыток ({max_retries}). Останавливаем работу.")
                break
            
            logger.info(f"Повторная попытка через {retry_delay} секунд...")
            time.sleep(retry_delay)
            
            # Увеличиваем задержку между попытками, но не более 5 минут
            retry_delay = min(retry_delay * 2, 300)
    
    logger.info("Бот остановлен")

if __name__ == "__main__":
    main()