import os
import requests
from dotenv import load_dotenv
import time

# Загружаем переменные из .env файла
load_dotenv()

# Получаем API ключ LightX
api_key = os.environ.get("LIGHTX_API_KEY")
print(f"API Key: {api_key}")

# Функция для тестирования ретуши фото
def test_beautify():
    # URL и заголовки для запросов
    headers = {
        'Content-Type': 'application/json',
        'x-api-key': api_key
    }
    
    # 1. Получаем URL для загрузки изображения
    print("1. Получаем URL для загрузки изображения...")
    upload_url_endpoint = 'https://api.lightxeditor.com/external/api/v2/uploadImageUrl'
    upload_data = {
        "uploadType": "imageUrl",
        "size": 100000,
        "contentType": "image/jpeg"
    }
    
    upload_response = requests.post(upload_url_endpoint, headers=headers, json=upload_data)
    if upload_response.status_code != 200:
        print(f"Ошибка при получении URL для загрузки: {upload_response.status_code}")
        print(upload_response.text)
        return False
    
    upload_result = upload_response.json()
    if "body" not in upload_result or "imageUrl" not in upload_result["body"]:
        print("Неверный формат ответа при получении URL")
        print(upload_result)
        return False
    
    image_url = upload_result["body"]["imageUrl"]
    print(f"URL изображения: {image_url}")
    
    # 2. Отправляем запрос на ретушь
    print("\n2. Отправляем запрос на ретушь фото...")
    beautify_endpoint = 'https://api.lightxeditor.com/external/api/v2/beautify'
    
    beautify_data = {
        "imageUrl": image_url,
        "options": {
            "skinSmoothing": True,
            "enhanceFeatures": True,
            "removeImperfections": True,
            "improveContrast": True,
            "level": 0.75
        }
    }
    
    beautify_response = requests.post(beautify_endpoint, headers=headers, json=beautify_data)
    print(f"Статус ответа: {beautify_response.status_code}")
    print(f"Тело ответа: {beautify_response.text}")
    
    if beautify_response.status_code != 200:
        print("Ошибка в запросе на ретушь!")
        return False
    
    beautify_result = beautify_response.json()
    if "body" not in beautify_result or "orderId" not in beautify_result["body"]:
        print("Неверный формат ответа при запросе на ретушь")
        print(beautify_result)
        return False
    
    order_id = beautify_result["body"]["orderId"]
    print(f"Order ID: {order_id}")
    
    # 3. Проверяем статус заказа
    print("\n3. Ожидаем обработку изображения (5 секунд)...")
    time.sleep(5)
    
    print("4. Проверяем статус заказа...")
    order_status_endpoint = 'https://api.lightxeditor.com/external/api/v1/order-status'
    
    status_data = {
        "orderId": order_id
    }
    
    status_response = requests.post(order_status_endpoint, headers=headers, json=status_data)
    print(f"Статус ответа: {status_response.status_code}")
    print(f"Тело ответа: {status_response.text}")
    
    if status_response.status_code != 200:
        print("Ошибка при проверке статуса заказа!")
        return False
    
    status_result = status_response.json()
    if "body" not in status_result or "status" not in status_result["body"]:
        print("Неверный формат ответа при проверке статуса")
        print(status_result)
        return False
    
    status = status_result["body"]["status"]
    print(f"Статус заказа: {status}")
    
    if status == "active" and "output" in status_result["body"]:
        output_url = status_result["body"]["output"]
        print(f"URL результата: {output_url}")
        print("\nТест успешно завершен! ✅")
        return True
    elif status == "init":
        print("Заказ все еще обрабатывается, нужно больше времени")
        return True
    else:
        print(f"Неизвестный статус: {status}")
        return False

if __name__ == "__main__":
    print("Тестирование функции ретуши фото с помощью LightX API...")
    test_beautify()