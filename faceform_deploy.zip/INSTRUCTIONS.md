# Инструкция по установке веб-сайта FaceForm на VPS

## Предварительные требования

1. VPS с Ubuntu 24.04 (у вас уже установлен)
2. Установленный и работающий бот FaceForm
3. Архив `faceform_website.zip` с файлами сайта

## Подготовка к установке

1. Загрузите архив `faceform_website.zip` на ваш VPS. Вы можете использовать команду `scp` или любой другой метод передачи файлов:

   ```bash
   scp faceform_website.zip faceneiro@92.113.145.171:~/
   ```

2. Подключитесь к вашему VPS через SSH:

   ```bash
   ssh faceneiro@92.113.145.171
   ```

3. Убедитесь, что архив успешно загружен:

   ```bash
   ls -la ~/ | grep faceform_website.zip
   ```

## Автоматическая установка

1. Скачайте скрипт установки:

   ```bash
   wget https://raw.githubusercontent.com/genajec/aiai/master/install_website.sh -O ~/install_website.sh
   ```

   Или создайте его вручную:

   ```bash
   nano ~/install_website.sh
   ```

   И скопируйте в него содержимое скрипта `install_website.sh`.

2. Сделайте скрипт исполняемым:

   ```bash
   chmod +x ~/install_website.sh
   ```

3. Установите переменные окружения с вашим IP-адресом:

   ```bash
   export IP_ADDRESS="92.113.145.171"
   ```

4. Запустите скрипт установки:

   ```bash
   ~/install_website.sh
   ```

5. После завершения установки откройте браузер и введите IP-адрес вашего сервера: `http://92.113.145.171`

## Ручная установка

Если автоматическая установка не удалась, выполните следующие шаги вручную:

1. Создайте директорию для веб-сайта:

   ```bash
   mkdir -p ~/faceform_website
   cd ~/faceform_website
   ```

2. Распакуйте архив с веб-сайтом:

   ```bash
   cp ~/faceform_website.zip ./
   unzip faceform_website.zip
   cp -r website_archive/* ./
   rm -rf website_archive
   ```

3. Создайте виртуальное окружение и установите зависимости:

   ```bash
   python3 -m venv venv
   source venv/bin/activate
   pip install --upgrade pip
   pip install -r requirements.txt
   ```

4. Создайте файл конфигурации `.env`:

   ```bash
   cat > .env << EOL
   # Flask settings
   FLASK_SECRET_KEY=$(python3 -c "import secrets; print(secrets.token_hex(32))")
   FLASK_DEBUG=False

   # Database settings
   DATABASE_URL=postgresql://faceneiro:ваш_пароль_postgres@localhost/faceform_website_db

   # Stripe API keys
   STRIPE_SECRET_KEY=ваш_секретный_ключ_stripe
   STRIPE_PUBLISHABLE_KEY=ваш_публичный_ключ_stripe
   STRIPE_WEBHOOK_SECRET=ваш_секретный_ключ_вебхука_stripe

   # Deployment
   YOUR_DOMAIN=92.113.145.171:5000
   EOL
   ```

5. Создайте базу данных PostgreSQL:

   ```bash
   sudo -u postgres psql -c "CREATE DATABASE faceform_website_db;"
   sudo -u postgres psql -c "GRANT ALL PRIVILEGES ON DATABASE faceform_website_db TO faceneiro;"
   ```

6. Инициализируйте базу данных:

   ```bash
   python -c "
   from app import app, db
   with app.app_context():
       db.create_all()
   "
   ```

7. Настройте Nginx:

   ```bash
   sudo nano /etc/nginx/sites-available/faceform_website
   ```

   Добавьте следующую конфигурацию:

   ```
   server {
       listen 80;
       server_name 92.113.145.171;

       location /static {
           alias /home/faceneiro/faceform_website/static;
       }

       location / {
           proxy_pass http://localhost:5000;
           proxy_set_header Host $host;
           proxy_set_header X-Real-IP $remote_addr;
           include proxy_params;
       }
   }
   ```

8. Активируйте конфигурацию Nginx:

   ```bash
   sudo ln -sf /etc/nginx/sites-available/faceform_website /etc/nginx/sites-enabled/
   sudo nginx -t && sudo systemctl restart nginx
   ```

9. Создайте службу systemd для Gunicorn:

   ```bash
   sudo nano /etc/systemd/system/faceform_website.service
   ```

   Добавьте следующую конфигурацию:

   ```
   [Unit]
   Description=Gunicorn instance to serve FaceForm Website
   After=network.target

   [Service]
   User=faceneiro
   Group=www-data
   WorkingDirectory=/home/faceneiro/faceform_website
   Environment="PATH=/home/faceneiro/faceform_website/venv/bin"
   ExecStart=/home/faceneiro/faceform_website/venv/bin/gunicorn --workers 3 --bind 0.0.0.0:5000 --access-logfile /home/faceneiro/faceform_website/access.log --error-logfile /home/faceneiro/faceform_website/error.log main:app

   [Install]
   WantedBy=multi-user.target
   ```

10. Запустите и включите службу:

    ```bash
    sudo systemctl start faceform_website
    sudo systemctl enable faceform_website
    ```

## Проверка установки

1. Проверьте статус службы:

   ```bash
   sudo systemctl status faceform_website
   ```

2. Проверьте логи в случае проблем:

   ```bash
   sudo journalctl -u faceform_website -f
   ```

3. Проверьте доступность сайта в браузере, открыв `http://92.113.145.171`

## Дополнительные настройки (после установки)

### Настройка Stripe для приема платежей

1. Обновите файл `.env` с вашими реальными ключами Stripe:

   ```bash
   nano ~/faceform_website/.env
   ```

2. Измените следующие строки:

   ```
   STRIPE_SECRET_KEY=ваш_реальный_секретный_ключ_stripe
   STRIPE_PUBLISHABLE_KEY=ваш_реальный_публичный_ключ_stripe
   STRIPE_WEBHOOK_SECRET=ваш_реальный_ключ_вебхука_stripe
   ```

3. Перезапустите службу:

   ```bash
   sudo systemctl restart faceform_website
   ```

### Обновление сайта в будущем

Если вам потребуется обновить сайт в будущем, выполните следующие шаги:

1. Загрузите новый архив на сервер
2. Распакуйте его:

   ```bash
   cd ~/faceform_website
   cp ~/новый_архив.zip ./
   unzip новый_архив.zip
   ```

3. Перезапустите службу:

   ```bash
   sudo systemctl restart faceform_website
   ```

## Устранение проблем

### Проблема: Сайт не открывается

1. Проверьте работу службы:
   ```bash
   sudo systemctl status faceform_website
   ```

2. Проверьте логи Gunicorn:
   ```bash
   cat ~/faceform_website/error.log
   ```

3. Проверьте настройки Nginx:
   ```bash
   sudo nginx -t
   ```

### Проблема: Ошибки базы данных

1. Проверьте подключение к базе данных:
   ```bash
   sudo -u postgres psql -c "\\l" | grep faceform
   ```

2. Проверьте разрешения:
   ```bash
   sudo -u postgres psql -c "SELECT * FROM pg_roles;"
   ```

## Примечание по безопасности

- Измените стандартные ключи Stripe на ваши реальные ключи
- Рассмотрите возможность использования HTTPS с Let's Encrypt для защиты данных
- Регулярно обновляйте систему и зависимости для устранения уязвимостей