import os
from app import app, db
from models import Package, Feature, ServicePrice

def init_packages():
    """Инициализация пакетов кредитов"""
    # Проверяем, есть ли уже пакеты в базе данных
    existing_packages = Package.query.all()
    if existing_packages:
        print(f"В базе данных уже есть {len(existing_packages)} пакетов. Пропускаем инициализацию.")
        return
    
    # Создаем стандартные пакеты
    packages = [
        Package(
            name="Базовый",
            description="Идеально для начала использования сервиса",
            credits=20,
            price=299,
            is_popular=False
        ),
        Package(
            name="Стандартный",
            description="Оптимальный выбор для активных пользователей",
            credits=50,
            price=599,
            is_popular=True
        ),
        Package(
            name="Премиум",
            description="Максимум возможностей и экономия",
            credits=100,
            price=999,
            is_popular=False
        ),
        Package(
            name="VIP",
            description="Неограниченные возможности для профессионалов",
            credits=500,
            price=3999,
            is_popular=False
        )
    ]
    
    # Добавляем пакеты в базу данных
    for package in packages:
        db.session.add(package)
    
    db.session.commit()
    print(f"Добавлено {len(packages)} пакетов кредитов")

def init_features():
    """Инициализация функций бота"""
    # Проверяем, есть ли уже функции в базе данных
    existing_features = Feature.query.all()
    if existing_features:
        print(f"В базе данных уже есть {len(existing_features)} функций. Пропускаем инициализацию.")
        return
    
    # Создаем стандартные функции
    features = [
        Feature(
            name="Анализ формы лица",
            description="Определение формы лица и индивидуальные рекомендации по стилю",
            credits_cost=1,
            is_premium=False,
            is_enabled=True
        ),
        Feature(
            name="Анализ симметрии лица",
            description="Проверка симметрии лица и создание симметричной версии",
            credits_cost=1,
            is_premium=False,
            is_enabled=True
        ),
        Feature(
            name="Виртуальная примерка причесок",
            description="Примерка различных причесок на ваше фото",
            credits_cost=2,
            is_premium=True,
            is_enabled=True
        ),
        Feature(
            name="Анализ привлекательности",
            description="Научный анализ привлекательности черт лица",
            credits_cost=3,
            is_premium=True,
            is_enabled=True
        ),
        Feature(
            name="Удаление фона",
            description="Удаление фона фотографии и замена на выбранный цвет",
            credits_cost=2,
            is_premium=False,
            is_enabled=True
        ),
        Feature(
            name="Удаление объектов с фото",
            description="Удаление нежелательных объектов с фотографии с помощью AI",
            credits_cost=3,
            is_premium=True,
            is_enabled=True
        ),
        Feature(
            name="Анализ видео",
            description="Анализ видео с лицом и создание сетки для оценки пропорций",
            credits_cost=5,
            is_premium=True,
            is_enabled=True
        )
    ]
    
    # Добавляем функции в базу данных
    for feature in features:
        db.session.add(feature)
    
    db.session.commit()
    print(f"Добавлено {len(features)} функций бота")

def init_service_prices():
    """Инициализация цен на услуги для отображения на сайте"""
    # Проверяем, есть ли уже цены в базе данных
    existing_prices = ServicePrice.query.all()
    if existing_prices:
        print(f"В базе данных уже есть {len(existing_prices)} цен на услуги. Пропускаем инициализацию.")
        return
    
    # Создаем стандартные цены
    prices = [
        ServicePrice(
            name="Базовый",
            description="Идеально для личного использования",
            price=299,
            is_popular=False,
            is_enabled=True,
            feature_list="Анализ формы лица, Анализ симметрии лица, Удаление фона"
        ),
        ServicePrice(
            name="Стандартный",
            description="Оптимальный выбор для активного использования",
            price=599,
            is_popular=True,
            is_enabled=True,
            feature_list="Анализ формы лица, Анализ симметрии лица, Виртуальная примерка причесок, Удаление фона"
        ),
        ServicePrice(
            name="Премиум",
            description="Максимум возможностей",
            price=999,
            is_popular=False,
            is_enabled=True,
            feature_list="Анализ формы лица, Анализ симметрии лица, Виртуальная примерка причесок, Анализ привлекательности, Удаление фона, Удаление объектов с фото, Анализ видео"
        )
    ]
    
    # Добавляем цены в базу данных
    for price in prices:
        db.session.add(price)
    
    db.session.commit()
    print(f"Добавлено {len(prices)} цен на услуги")

def init_db():
    """Инициализация базы данных"""
    with app.app_context():
        # Создаем таблицы
        db.create_all()
        
        # Инициализируем данные
        init_packages()
        init_features()
        init_service_prices()
        
        print("База данных успешно инициализирована")

if __name__ == "__main__":
    init_db()