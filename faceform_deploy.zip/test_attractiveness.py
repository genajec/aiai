import sys
from face_attractiveness import FaceAttractiveness
import cv2
import matplotlib.pyplot as plt

def test_face_attractiveness(image_path):
    """
    Тестирует анализатор привлекательности лица на указанном изображении
    
    Args:
        image_path: Путь к изображению для анализа
    """
    # Загружаем изображение
    try:
        with open(image_path, "rb") as img_file:
            image_data = img_file.read()
    except Exception as e:
        print(f"Ошибка при загрузке изображения: {e}")
        return
    
    # Создаем анализатор
    analyzer = FaceAttractiveness()
    
    # Анализируем изображение
    score, comment, visualization = analyzer.analyze_attractiveness(image_data)
    
    if score is None:
        print(f"Ошибка анализа: {comment}")
        return
    
    # Выводим результаты
    print(f"Оценка привлекательности: {score}/10")
    print(f"Комментарий: {comment}")
    
    # Сохраняем визуализацию
    output_path = "attractiveness_result.jpg"
    cv2.imwrite(output_path, visualization)
    print(f"Визуализация сохранена в {output_path}")
    
    # Показываем визуализацию
    plt.figure(figsize=(10, 8))
    plt.imshow(cv2.cvtColor(visualization, cv2.COLOR_BGR2RGB))
    plt.title(f"Оценка привлекательности: {score}/10")
    plt.axis('off')
    plt.tight_layout()
    plt.savefig("visualization_plot.jpg", dpi=300)
    print("График сохранен в visualization_plot.jpg")
    
if __name__ == "__main__":
    # Проверяем наличие пути к изображению в аргументах
    if len(sys.argv) < 2:
        print("Использование: python test_attractiveness.py <путь_к_изображению>")
        sys.exit(1)
    
    image_path = sys.argv[1]
    test_face_attractiveness(image_path)