# Установка FaceForm Bot на VPS сервер (режим polling)

Это руководство поможет вам установить и настроить FaceForm Bot на VPS сервере в режиме polling (без webhook).

## Предварительные требования

- VPS сервер с Ubuntu 20.04 или более новой версией
- Минимум 2 ГБ оперативной памяти
- Минимум 20 ГБ дискового пространства
- Root-доступ к серверу

## Шаг 1: Обновление системы

```bash
apt update && apt upgrade -y
```

## Шаг 2: Установка зависимостей

```bash
apt install -y python3-pip python3-venv supervisor git ffmpeg libsm6 libxext6 libgl1 python3-opencv
```

## Шаг 3: Создание пользователя для бота

```bash
adduser faceform
usermod -aG sudo faceform
su - faceform
```

## Шаг 4: Клонирование репозитория

```bash
git clone https://your-repository-url.git faceform_bot
cd faceform_bot
```

## Шаг 5: Создание виртуального окружения

```bash
python3 -m venv venv
source venv/bin/activate
```

## Шаг 6: Установка зависимостей Python

```bash
pip install -r requirements.txt
```

## Шаг 7: Создание файла .env с настройками

```bash
nano .env
```

Добавьте следующие настройки:

```
TELEGRAM_API_TOKEN=ваш_токен_бота
ADMIN_USER_ID=ваш_телеграм_id
LIGHTX_API_KEY=ваш_api_ключ_lightx
STRIPE_SECRET_KEY=ваш_секретный_ключ_stripe
```

## Шаг 8: Создание директории для логов

```bash
mkdir -p logs
```

## Шаг 9: Настройка Supervisor

Скопируйте конфигурационный файл supervisor:

```bash
sudo cp faceform_bot_supervisor.conf /etc/supervisor/conf.d/faceform_bot.conf
```

Отредактируйте конфигурацию, заменив пути:

```bash
sudo nano /etc/supervisor/conf.d/faceform_bot.conf
```

## Шаг 10: Запуск бота через Supervisor

```bash
sudo supervisorctl reread
sudo supervisorctl update
sudo supervisorctl status
```

## Шаг 11: Проверка работы бота

Проверьте логи:

```bash
tail -f logs/stdout.log
```

## Управление ботом через Supervisor

### Просмотр статуса:

```bash
sudo supervisorctl status faceform_bot
```

### Остановка бота:

```bash
sudo supervisorctl stop faceform_bot
```

### Запуск бота:

```bash
sudo supervisorctl start faceform_bot
```

### Перезапуск бота:

```bash
sudo supervisorctl restart faceform_bot
```

## Обновление бота

```bash
cd ~/faceform_bot
git pull
source venv/bin/activate
pip install -r requirements.txt
sudo supervisorctl restart faceform_bot
```

## Мониторинг и обслуживание

### Просмотр логов:

```bash
tail -f ~/faceform_bot/logs/stdout.log
tail -f ~/faceform_bot/logs/stderr.log
```

### Просмотр логов мониторинга:

```bash
tail -f ~/faceform_bot/logs/monitor_stdout.log
```

### Проверка использования системных ресурсов:

```bash
htop
```

## Резервное копирование базы данных

```bash
cd ~/faceform_bot
sqlite3 faceform_bot.db .dump > backup_$(date +%Y%m%d).sql
```

## Восстановление из резервной копии

```bash
cd ~/faceform_bot
sqlite3 faceform_bot.db < backup_YYYYMMDD.sql
```

## Устранение неполадок

1. **Бот не запускается:**
   - Проверьте логи в папке logs
   - Убедитесь, что все переменные окружения правильно настроены в файле .env
   - Проверьте, что все необходимые библиотеки установлены

2. **Ошибки медиапайп:**
   - Убедитесь, что установлены все необходимые системные библиотеки
   - Проверьте версию OpenCV и MediaPipe

3. **Ошибки доступа к файлам:**
   - Проверьте права доступа: `sudo chown -R faceform:faceform ~/faceform_bot`

4. **Высокая загрузка CPU:**
   - Увеличьте ресурсы VPS сервера
   - Отключите неиспользуемые функции бота

## Дополнительные настройки

### Настройка автоматического резервного копирования

Добавьте в crontab:

```bash
crontab -e
```

Добавьте строку для ежедневного резервного копирования:

```
0 3 * * * cd ~/faceform_bot && sqlite3 faceform_bot.db .dump > backup_$(date +\%Y\%m\%d).sql
```

### Настройка оповещений в Telegram

Измените файл `monitor.py`, добавив свой ID Telegram в переменную `ADMIN_IDS`.

## Полезные ссылки

- [Документация по Supervisor](http://supervisord.org/configuration.html)
- [Документация по SQLite](https://www.sqlite.org/docs.html)
- [Документация по Python-Telegram-Bot](https://python-telegram-bot.readthedocs.io/en/stable/)