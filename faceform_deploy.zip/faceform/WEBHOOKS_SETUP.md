# Настройка вебхуков для FaceForm

## Настройка вебхуков Stripe

Для корректной обработки платежей через Stripe необходимо настроить вебхуки, которые будут уведомлять ваш сервер о событиях платежей.

1. Войдите в [панель управления Stripe](https://dashboard.stripe.com/)
2. Перейдите в раздел **Developers** → **Webhooks**
3. Нажмите **Add endpoint**
4. В поле "Endpoint URL" введите: `https://faceform.vps.webdock.cloud/stripe-webhook`
5. В разделе "Events to send" выберите:
   - `checkout.session.completed`
   - `payment_intent.succeeded`
   - `payment_intent.payment_failed`
6. Нажмите **Add endpoint** для сохранения

После создания вебхука:

1. Откройте созданный вебхук
2. Найдите раздел "Signing secret" и нажмите "Reveal"
3. Скопируйте ключ и добавьте его в файл `.env` на вашем сервере:
   ```
   STRIPE_WEBHOOK_SECRET=ваш_секретный_ключ_вебхука
   ```
4. Перезапустите сервис для применения изменений:
   ```bash
   sudo supervisorctl restart faceform
   ```

## Настройка вебхуков Telegram (опционально)

По умолчанию бот работает в режиме polling (автоматически запрашивает обновления). Если вы хотите использовать вебхуки для Telegram (это более эффективно), выполните следующие шаги:

1. Получите SSL-сертификат для вашего домена с помощью Let's Encrypt (уже должно быть настроено)

2. Настройте вебхук для Telegram бота:
   ```bash
   curl -F "url=https://faceform.vps.webdock.cloud/webhook" -F "drop_pending_updates=true" https://api.telegram.org/bot7586536261:AAFWtwOsRY390hEKJBzCS1grQtCO8fTHaXc/setWebhook
   ```

3. Проверьте статус вебхука:
   ```bash
   curl https://api.telegram.org/bot7586536261:AAFWtwOsRY390hEKJBzCS1grQtCO8fTHaXc/getWebhookInfo
   ```

4. Измените метод запуска бота в файле `main.py`, найдите строку с запуском бота в режиме polling и измените ее на использование вебхуков.

## Проверка работы вебхуков

### Для Stripe:

1. В панели управления Stripe перейдите в раздел **Developers** → **Webhooks**
2. Выберите ваш вебхук
3. Нажмите на кнопку "Send test webhook"
4. Выберите событие `checkout.session.completed` и нажмите "Send test webhook"
5. Проверьте логи на сервере:
   ```bash
   sudo tail -f /var/log/faceform/faceform.out.log
   ```

### Для Telegram:

1. Отправьте сообщение боту
2. Проверьте логи на сервере:
   ```bash
   sudo tail -f /var/log/faceform/faceform.out.log
   ```

## Устранение неполадок с вебхуками

### Stripe вебхуки не работают:

1. Проверьте, что URL вебхука правильный и доступен извне
2. Убедитесь, что секретный ключ вебхука правильно указан в файле `.env`
3. Проверьте логи на ошибки:
   ```bash
   sudo tail -f /var/log/faceform/faceform.err.log
   ```
4. Убедитесь, что ваш сервер имеет SSL-сертификат и доступен по HTTPS

### Telegram вебхуки не работают:

1. Проверьте статус вебхука:
   ```bash
   curl https://api.telegram.org/bot7586536261:AAFWtwOsRY390hEKJBzCS1grQtCO8fTHaXc/getWebhookInfo
   ```
2. Убедитесь, что URL вебхука доступен извне и имеет действительный SSL-сертификат
3. Проверьте логи на ошибки:
   ```bash
   sudo tail -f /var/log/faceform/faceform.err.log
   ```