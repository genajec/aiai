#!/bin/bash
# Скрипт для установки FaceForm на VPS без домена, используя только IP-адрес
set -e

echo "=== Начинаем установку FaceForm (Бот + Сайт) на VPS ==="

# Обновление пакетов
echo "Обновление системы..."
sudo apt update
sudo apt upgrade -y

# Установка необходимых пакетов
echo "Установка необходимых пакетов..."
sudo apt install -y python3-pip python3-venv nginx certbot python3-certbot-nginx git supervisor

# Создание директории для проекта
echo "Создание директории проекта..."
sudo mkdir -p /home/faceform/faceform_bot
sudo chown -R $USER:$USER /home/faceform

# Разархивация файлов проекта (предполагается, что архив уже загружен)
echo "Разархивация файлов проекта..."
unzip faceform_deploy.zip -d /tmp/faceform_deploy
cp -r /tmp/faceform_deploy/* /home/faceform/faceform_bot/
cp /tmp/faceform_deploy/.env /home/faceform/faceform_bot/ 2>/dev/null || echo "Файл .env не найден, создайте его вручную"

# Переход в директорию проекта
cd /home/faceform/faceform_bot

# Настройка виртуального окружения
echo "Настройка виртуального окружения..."
python3 -m venv venv
source venv/bin/activate
pip install -r requirements_vps.txt
pip install gunicorn

# Создание самоподписанного сертификата для SSL
echo "Создание самоподписанного SSL-сертификата..."
sudo mkdir -p /etc/ssl/private
sudo openssl req -x509 -nodes -days 365 -newkey rsa:2048 \
    -keyout /etc/ssl/private/nginx-selfsigned.key \
    -out /etc/ssl/certs/nginx-selfsigned.crt \
    -subj "/C=RU/ST=Moscow/L=Moscow/O=FaceForm/CN=92.113.145.171"

# Настройка Nginx
echo "Настройка Nginx..."
sudo cp NGINX_CONFIG_IP.conf /etc/nginx/sites-available/faceform
sudo ln -s /etc/nginx/sites-available/faceform /etc/nginx/sites-enabled/ || true
sudo nginx -t
sudo systemctl restart nginx

# Настройка Supervisor
echo "Настройка Supervisor..."
sudo mkdir -p /var/log/faceform
cat > /tmp/faceform_supervisor.conf << 'EOF'
[program:faceform]
command=/home/faceform/faceform_bot/venv/bin/gunicorn --bind 127.0.0.1:5000 main:app
directory=/home/faceform/faceform_bot
user=faceform
autostart=true
autorestart=true
stderr_logfile=/var/log/faceform/faceform.err.log
stdout_logfile=/var/log/faceform/faceform.out.log
EOF
sudo cp /tmp/faceform_supervisor.conf /etc/supervisor/conf.d/faceform.conf
sudo supervisorctl reread
sudo supervisorctl update
sudo supervisorctl start faceform

echo "=== Установка завершена ==="
echo "Проверьте, что сайт доступен по адресу: http://92.113.145.171 и https://92.113.145.171"
echo "Проверьте логи: sudo tail -f /var/log/faceform/faceform.out.log"

# Настройка файрвола (опционально)
echo "Настройка файрвола (UFW)..."
sudo apt install -y ufw
sudo ufw default deny incoming
sudo ufw default allow outgoing
sudo ufw allow ssh
sudo ufw allow http
sudo ufw allow https
sudo ufw --force enable

echo "=== Настройка безопасности завершена ==="