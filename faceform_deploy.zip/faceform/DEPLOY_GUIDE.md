# Полное руководство по деплою FaceForm на VPS

## Содержание

1. [Основные шаги установки](#1-основные-шаги-установки)
2. [Настройка вебхуков](#2-настройка-вебхуков)
3. [Обеспечение безопасности](#3-обеспечение-безопасности)
4. [Проверка работоспособности](#4-проверка-работоспособности)
5. [Устранение неполадок](#5-устранение-неполадок)
6. [Файлы, необходимые для переноса](#6-файлы-необходимые-для-переноса)

## 1. Основные шаги установки

Подробные инструкции по основной установке находятся в файле [INSTALL_VPS_FULL.md](INSTALL_VPS_FULL.md). Краткий обзор шагов:

1. **Подготовка сервера**:
   - Обновление пакетов
   - Установка необходимых инструментов (Python, Nginx, Supervisor, Git)

2. **Установка бота и сайта**:
   - Копирование исходных файлов
   - Создание виртуального окружения Python
   - Установка зависимостей

3. **Настройка веб-сервера**:
   - Конфигурация Nginx
   - Настройка SSL-сертификата

4. **Настройка процесс-менеджера**:
   - Конфигурация Supervisor
   - Запуск и автоматический перезапуск приложения

## 2. Настройка вебхуков

Подробные инструкции по настройке вебхуков находятся в файле [WEBHOOKS_SETUP.md](WEBHOOKS_SETUP.md). Основные шаги:

1. **Настройка вебхуков Stripe**:
   - Создание вебхука в панели управления Stripe
   - Получение секретного ключа вебхука
   - Добавление ключа в конфигурацию приложения

2. **Настройка вебхуков Telegram** (опционально):
   - Настройка вебхука для бота
   - Изменение режима работы бота с polling на webhook

## 3. Обеспечение безопасности

Подробные рекомендации по безопасности находятся в файле [SECURITY_MEASURES.md](SECURITY_MEASURES.md). Ключевые меры:

1. **Защита API ключей**:
   - Безопасное хранение переменных окружения
   - Ограничение доступа к файлу .env

2. **Защита сервера**:
   - Настройка файрвола (UFW)
   - Установка fail2ban для защиты от брутфорс-атак

3. **Регулярное обслуживание**:
   - Автоматические обновления безопасности
   - Резервное копирование базы данных и ключей
   - Ротация API ключей

## 4. Проверка работоспособности

После установки рекомендуется проверить работоспособность всех компонентов:

1. **Веб-сайт**:
   - Откройте `https://faceform.vps.webdock.cloud` в браузере
   - Проверьте доступность всех страниц (главная, функции, цены и т.д.)
   - Протестируйте переключение языков

2. **Telegram-бот**:
   - Отправьте сообщение боту @Faceform_bot
   - Проверьте основные команды (/start, /help, /menu)
   - Протестируйте отправку фото и получение анализа

3. **Система оплаты**:
   - Проверьте процесс оформления заказа на сайте
   - Проверьте получение вебхуков от Stripe
   - Протестируйте начисление кредитов после оплаты

## 5. Устранение неполадок

### Проблемы с веб-сайтом

1. **Сайт не доступен**:
   ```bash
   sudo systemctl status nginx
   sudo nginx -t
   sudo tail -f /var/log/nginx/error.log
   ```

2. **Ошибки в работе приложения**:
   ```bash
   sudo supervisorctl status faceform
   sudo tail -f /var/log/faceform/faceform.err.log
   ```

### Проблемы с ботом

1. **Бот не отвечает**:
   ```bash
   sudo tail -f /var/log/faceform/faceform.out.log
   ```
   
2. **Ошибки в веб-хуках**:
   ```bash
   curl https://api.telegram.org/bot7586536261:AAFWtwOsRY390hEKJBzCS1grQtCO8fTHaXc/getWebhookInfo
   ```

### Проблемы с платежами

1. **Платежи не проходят**:
   - Проверьте настройки вебхуков в панели Stripe
   - Проверьте правильность ключей в .env файле
   - Проверьте логи на ошибки обработки вебхуков

## 6. Файлы, необходимые для переноса

Чтобы упростить перенос проекта на VPS, убедитесь, что у вас есть следующие файлы:

### Основные файлы приложения
- `main.py` - главный файл Flask приложения
- `bot.py` - основной файл Telegram бота
- `config.py` - настройки приложения
- `database.py` - работа с базой данных
- `face_analyzer.py` - модуль анализа лиц
- `stripe_payment.py` - обработка платежей Stripe
- `crypto_bot_payment.py` - обработка криптоплатежей (опционально)
- `background_fallback.py` - модуль обработки фона изображений

### Шаблоны и статические файлы
- `templates/` - HTML шаблоны для веб-сайта
- `static/` - CSS, JavaScript, изображения

### Настройки сервера
- `.env` - файл с переменными окружения (создайте из примера ниже)
- `requirements_vps.txt` - список зависимостей Python

### Пример содержимого `.env` файла
```
# Telegram Bot
TELEGRAM_BOT_TOKEN=7586536261:AAFWtwOsRY390hEKJBzCS1grQtCO8fTHaXc
TELEGRAM_BOT_NAME=Faceform_bot

# Stripe API
STRIPE_SECRET_KEY=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
STRIPE_PUBLIC_KEY=pk_live_51RFWPbIXP9qWqMx9mFcESigNDB705oZNH8glzwdnzxkxHoBINjgfXZHfNJrJQMuDLEyCnP1jtO1YVLdUSKEyKTzs00DP5wzGaS

# LightX API Keys
LIGHTX_API_KEYS=33dc337eefda49ab92fd29f43da336bf_ac9ec1f895af47948c32513640a0136a_andoraitools,4e0057d083f3420dbe043d00c1986d9a_d7d8ea58f693480cba99ebcbc9998bc5_andoraitools,d7d8e6a124b94ae2a1369229e247f920_aad315a2e1f64b778c49cf8b75d7a413_andoraitools,ee03d7f4abbe489ebf52f6a6898a2e58_1bf285878c8a4950bca2d0e28ce08a27_andoraitools,2614471723e34e30a5c53ab682c88c52_415cd730394e4aedb0c7c377890321c7_andoraitools,b9043dfb51af4e3d9a787bb7e6858ece_9814ff95790f49e6b23ca71195799f3f_andoraitools

# DeepL API
DEEPL_API_KEY=7fe9dd7a-990a-4bf1-86af-a216b1b993a1:fx

# Server Config
SESSION_SECRET=faceform_session_secret_123456789abc
REPLIT_DOMAINS=faceform.vps.webdock.cloud
DATABASE_URL=sqlite:///faceform_bot.db
```

### Пример содержимого `requirements_vps.txt` файла
```
flask
flask-sqlalchemy
gunicorn
python-dotenv
pytelegrambotapi
stripe
opencv-python
numpy
mediapipe
psycopg2-binary
requests
pillow
```

---

Удачного деплоя! Если возникнут вопросы или проблемы, обращайтесь к подробным инструкциям в соответствующих файлах.