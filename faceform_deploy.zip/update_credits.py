#!/usr/bin/env python3
"""
Скрипт для обновления кредитов пользователей в базе данных.
Более простой и надежный, чем полный импорт.
"""

import sqlite3
import os
import datetime

def backup_database(db_path):
    """Создает резервную копию базы данных"""
    backup_path = f"{db_path}.backup_{datetime.datetime.now().strftime('%Y%m%d%H%M%S')}"
    try:
        import shutil
        shutil.copy2(db_path, backup_path)
        print(f"Создана резервная копия базы данных: {backup_path}")
        return True
    except Exception as e:
        print(f"Ошибка при создании резервной копии: {e}")
        return False

def update_user_credits(db_path):
    """Обновляет кредиты пользователей"""
    # Создаем резервную копию
    if not backup_database(db_path):
        return False
    
    # Данные пользователей из экспорта (telegram_id: credits)
    user_credits = {
        6139328506: 4,   # Nikolay Lukyanov
        999999: 5,       # Test User
        624741160: 0,    # Рустам
        5394916101: 0,   # Kop Lex
        123456789: 30    # Test User
    }
    
    try:
        conn = sqlite3.connect(db_path)
        cursor = conn.cursor()
        
        # Проверяем, существует ли таблица users
        cursor.execute("SELECT name FROM sqlite_master WHERE type='table' AND name='users';")
        if not cursor.fetchone():
            print("Ошибка: Таблица users не найдена в базе данных!")
            return False
        
        # Проверяем структуру таблицы
        cursor.execute("PRAGMA table_info(users);")
        columns = [col[1] for col in cursor.fetchall()]
        
        if 'telegram_id' not in columns or 'credits' not in columns:
            print("Ошибка: В таблице users отсутствуют необходимые колонки!")
            return False
        
        # Выводим текущие значения кредитов
        print("Текущие значения кредитов:")
        cursor.execute("SELECT telegram_id, username, credits FROM users;")
        for row in cursor.fetchall():
            print(f"  Telegram ID: {row[0]}, Username: {row[1]}, Credits: {row[2]}")
        
        # Обновляем кредиты пользователей
        updated_count = 0
        for telegram_id, credits in user_credits.items():
            # Проверяем, существует ли пользователь
            cursor.execute("SELECT id, credits FROM users WHERE telegram_id = ?;", (telegram_id,))
            user = cursor.fetchone()
            
            if user:
                # Обновляем кредиты существующего пользователя
                current_credits = user[1] if user[1] is not None else 0
                cursor.execute("UPDATE users SET credits = ? WHERE telegram_id = ?;", (credits, telegram_id))
                conn.commit()  # Явно коммитим каждое обновление
                print(f"Обновлены кредиты для пользователя с Telegram ID {telegram_id}: {current_credits} -> {credits}")
                updated_count += 1
        
        # Выводим обновленные значения кредитов
        print("\nОбновленные значения кредитов:")
        cursor.execute("SELECT telegram_id, username, credits FROM users;")
        for row in cursor.fetchall():
            print(f"  Telegram ID: {row[0]}, Username: {row[1]}, Credits: {row[2]}")
        
        print(f"\nОбновление завершено. Обновлено пользователей: {updated_count}")
        return True
    
    except sqlite3.Error as e:
        print(f"Ошибка при работе с базой данных: {e}")
        return False
    finally:
        if 'conn' in locals():
            conn.close()

if __name__ == "__main__":
    # Путь к базе данных
    db_path = "faceform_bot.db"
    
    # Обновляем кредиты пользователей
    if update_user_credits(db_path):
        print("Операция успешно завершена!")
    else:
        print("Операция завершена с ошибками.")