import telebot
from config import TELEGRAM_API_TOKEN
import time
import logging

# Настраиваем логирование
logging.basicConfig(level=logging.INFO, 
                   format='%(asctime)s - %(name)s - %(levelname)s - %(message)s')
logger = logging.getLogger(__name__)

def test_function_9():
    """
    Тестирует функцию 9 (Генерация по тексту) напрямую через внутренний API бота
    """
    try:
        # Импортируем бота из основного модуля
        from bot import FaceShapeBot
        from io import BytesIO
        
        logger.info("Инициализация бота для теста...")
        
        # Создаем экземпляр бота
        bot = FaceShapeBot(use_webhook=False)
        
        # Создаем фиктивное сообщение
        class MockMessage:
            def __init__(self, text):
                self.text = text
                # Тестовый чат
                self.chat = MockChat()
                
        class MockChat:
            def __init__(self):
                self.id = 123456  # Фиктивный ID чата
                
        # Создаем фиктивное сообщение с текстом "9" 
        test_message = MockMessage("9")
        
        # Тестируем обработку сообщения
        logger.info("Тестирование функции 9 (Генерация по тексту)...")
        
        # Патчим метод отправки сообщений, чтобы видеть ответы
        original_send_message = bot.bot.send_message
        
        def patched_send_message(chat_id, text, *args, **kwargs):
            logger.info(f"Бот отвечает: {text}")
            return original_send_message(chat_id, text, *args, **kwargs)
            
        bot.bot.send_message = patched_send_message
        
        # Патчим метод отправки фото
        original_send_photo = bot.bot.send_photo
        
        def patched_send_photo(chat_id, photo, caption=None, *args, **kwargs):
            logger.info(f"Бот отправляет фото с подписью: {caption}")
            # Не отправляем фото на самом деле
            return True
            
        bot.bot.send_photo = patched_send_photo
        
        # Вызываем обработчик сообщений
        bot.handle_message(test_message)
        
        # Если бот запросил ввод текста для генерации, предоставим его
        if (hasattr(bot, 'user_data') and 
            123456 in bot.user_data and 
            bot.user_data[123456].get('waiting_for_text_prompt')):
            
            logger.info("Бот запросил текстовое описание для генерации изображения")
            
            # Создаем сообщение с текстовым запросом
            prompt_message = MockMessage("фантастический пейзаж с горами и водопадом")
            
            # Добавляем патч для генерации изображения
            original_generate_from_text = bot.lightx_client.generate_from_text
            
            def patched_generate_from_text(prompt, image_data=None):
                logger.info(f"Вызываем LightX API для генерации изображения по запросу: {prompt}")
                logger.info("Это тестовая среда, поэтому фактический вызов API пропускается")
                
                # Симулируем успешный ответ API, возвращая тестовые данные
                return b"Test image data"
                
            # Устанавливаем патч
            bot.lightx_client.generate_from_text = patched_generate_from_text
            
            # Снова вызываем обработчик, на этот раз с текстовым запросом
            logger.info("Отправляем текстовый запрос для генерации изображения...")
            # Обработка текстового сообщения вручную, так как handle_text может быть недоступен
            if hasattr(bot, 'generate_from_text_command'):
                bot.generate_from_text_command(prompt_message)
            
            logger.info("Тест функции 9 завершен!")
            return True
        else:
            logger.error("Бот не запросил текстовое описание")
            return False
            
    except Exception as e:
        logger.error(f"Ошибка при тестировании: {e}")
        import traceback
        logger.error(traceback.format_exc())
        return False
        
if __name__ == "__main__":
    test_function_9()