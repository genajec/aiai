import os
import stripe
import json
import logging
from flask import render_template, request, redirect, url_for, flash, session, jsonify
from flask_login import LoginManager, login_required, current_user, login_user, logout_user
import cv2
import numpy as np
from werkzeug.utils import secure_filename
import uuid
import base64
from dotenv import load_dotenv

# Загружаем переменные окружения из файла .env
load_dotenv()

# Импортируем объект app из app.py
from app import app, db, logger

# Устанавливаем секретный ключ приложения для сессий
app.secret_key = os.environ.get("FLASK_SECRET_KEY") or "faceshapebot_secret_key_2025"

# Импортируем модели
from models import User, Package, Order, Feature, ServicePrice

# Настраиваем Stripe - используем ключи из переменных окружения
stripe.api_key = os.environ.get('STRIPE_SECRET_KEY')
stripe_publishable_key = os.environ.get('STRIPE_PUBLISHABLE_KEY')

# Домен для URL-адресов Stripe
YOUR_DOMAIN = os.environ.get('YOUR_DOMAIN', 'localhost:5000')

# Инициализируем Flask-Login
login_manager = LoginManager()
login_manager.init_app(app)
login_manager.login_view = 'login'

@login_manager.user_loader
def load_user(user_id):
    return User.query.get(int(user_id))

# Создаем необходимые таблицы в базе данных
with app.app_context():
    db.create_all()

@app.route('/')
def index():
    """Главная страница сайта"""
    return render_template('index.html')

@app.route('/en')
def index_en():
    """English version of the main page"""
    return render_template('index_en.html')

@app.route('/about')
def about():
    """Страница о сервисе"""
    return render_template('about.html')

@app.route('/features')
def features():
    """Страница с функциями бота"""
    return render_template('features.html')

@app.route('/services')
def services():
    """Страница с услугами"""
    service_prices = ServicePrice.query.filter_by(is_enabled=True).all()
    return render_template('services.html', services=service_prices)

@app.route('/pricing')
def pricing():
    """Страница с тарифами и пакетами кредитов"""
    packages = Package.query.all()
    return render_template('pricing.html', packages=packages, stripe_key=stripe_publishable_key)

@app.route('/contact')
def contact():
    """Страница контактов"""
    return render_template('contact.html')

@app.route('/try-on')
def try_on():
    """Страница для виртуальной примерки причесок"""
    return render_template('try_on.html')

@app.route('/try-on-result', methods=['POST'])
def try_on_result():
    """Обработка загруженного фото для примерки прически"""
    if 'photo' not in request.files:
        flash('Не выбрано фото', 'error')
        return redirect(url_for('try_on'))
    
    photo = request.files['photo']
    hairstyle = request.form.get('hairstyle', 'classic')
    
    if photo.filename == '':
        flash('Не выбран файл', 'error')
        return redirect(url_for('try_on'))
    
    # Сохраняем загруженное фото
    filename = secure_filename(str(uuid.uuid4()) + os.path.splitext(photo.filename)[1])
    upload_folder = os.path.join(app.static_folder, 'uploads')
    os.makedirs(upload_folder, exist_ok=True)
    filepath = os.path.join(upload_folder, filename)
    photo.save(filepath)
    
    # TODO: Здесь должна быть логика обработки фото и наложения прически
    # Пример простой обработки с помощью OpenCV
    try:
        img = cv2.imread(filepath)
        # Здесь должен быть код для обработки изображения
        
        # Для демонстрации просто возвращаем исходное изображение
        result_filename = 'result_' + filename
        result_path = os.path.join(upload_folder, result_filename)
        cv2.imwrite(result_path, img)
        
        return render_template('try_on_result.html', 
                              original_image=url_for('static', filename='uploads/' + filename),
                              result_image=url_for('static', filename='uploads/' + result_filename),
                              hairstyle=hairstyle)
    except Exception as e:
        flash(f'Ошибка при обработке изображения: {str(e)}', 'error')
        return redirect(url_for('try_on'))

@app.route('/create-checkout-session', methods=['POST'])
def create_checkout_session():
    """Создание сессии оплаты Stripe"""
    try:
        package_id = request.form.get('package_id')
        if not package_id:
            return jsonify(error='Не указан ID пакета'), 400
        
        package = Package.query.get(package_id)
        if not package:
            return jsonify(error='Пакет не найден'), 404
        
        checkout_session = stripe.checkout.Session.create(
            payment_method_types=['card'],
            line_items=[{
                'price_data': {
                    'currency': 'usd',
                    'product_data': {
                        'name': package.name,
                        'description': package.description or f'{package.credits} кредитов',
                    },
                    'unit_amount': int(package.price * 100),  # В центах
                },
                'quantity': 1,
            }],
            mode='payment',
            success_url=YOUR_DOMAIN + '/success?session_id={CHECKOUT_SESSION_ID}',
            cancel_url=YOUR_DOMAIN + '/cancel',
        )
        
        # Создаем запись о заказе в базе данных
        order = Order(
            user_id=current_user.id if current_user.is_authenticated else None,
            package_id=package.id,
            session_id=checkout_session.id,
            amount=package.price,
            status='pending'
        )
        db.session.add(order)
        db.session.commit()
        
        return jsonify(id=checkout_session.id)
    except Exception as e:
        logger.error(f"Ошибка при создании сессии оплаты: {str(e)}")
        return jsonify(error=str(e)), 500

@app.route('/success')
def success():
    """Страница успешной оплаты"""
    session_id = request.args.get('session_id')
    if not session_id:
        return redirect(url_for('index'))
    
    try:
        # Получаем информацию о сессии из Stripe
        checkout_session = stripe.checkout.Session.retrieve(session_id)
        
        # Обновляем статус заказа в базе данных
        order = Order.query.filter_by(session_id=session_id).first()
        if order and order.status == 'pending':
            order.status = 'completed'
            order.payment_id = checkout_session.payment_intent
            order.complete()  # Метод добавляет кредиты пользователю
            db.session.commit()
        
        return render_template('success.html', session=checkout_session)
    except Exception as e:
        logger.error(f"Ошибка при обработке успешного платежа: {str(e)}")
        return redirect(url_for('index'))

@app.route('/cancel')
def cancel():
    """Страница отмены оплаты"""
    return render_template('cancel.html')

@app.route('/webhook', methods=['POST'])
def webhook():
    """Обработчик вебхуков Stripe"""
    payload = request.get_data(as_text=True)
    sig_header = request.headers.get('Stripe-Signature')
    
    try:
        event = stripe.Webhook.construct_event(
            payload, sig_header, os.environ.get('STRIPE_WEBHOOK_SECRET')
        )
    except ValueError as e:
        logger.error(f"Ошибка валидации вебхука: {str(e)}")
        return jsonify(success=False), 400
    except stripe.error.SignatureVerificationError as e:
        logger.error(f"Ошибка проверки подписи вебхука: {str(e)}")
        return jsonify(success=False), 400
    
    # Обработка событий Stripe
    if event['type'] == 'checkout.session.completed':
        session = event['data']['object']
        fulfill_order(session)
    
    return jsonify(success=True)

def fulfill_order(session):
    """Выполнение заказа после успешной оплаты"""
    order = Order.query.filter_by(session_id=session.id).first()
    if order and order.status == 'pending':
        order.status = 'completed'
        order.payment_id = session.payment_intent
        order.complete()
        db.session.commit()
        logger.info(f"Заказ {order.id} выполнен успешно")

@app.route('/login', methods=['GET', 'POST'])
def login():
    """Страница входа"""
    if current_user.is_authenticated:
        return redirect(url_for('index'))
    
    if request.method == 'POST':
        username = request.form.get('username')
        password = request.form.get('password')
        
        user = User.query.filter_by(username=username).first()
        if user and user.check_password(password):
            login_user(user)
            next_page = request.args.get('next')
            return redirect(next_page or url_for('index'))
        
        flash('Неверное имя пользователя или пароль', 'error')
    
    return render_template('login.html')

@app.route('/logout')
@login_required
def logout():
    """Выход из системы"""
    logout_user()
    return redirect(url_for('index'))

@app.route('/register', methods=['GET', 'POST'])
def register():
    """Страница регистрации"""
    if current_user.is_authenticated:
        return redirect(url_for('index'))
    
    if request.method == 'POST':
        username = request.form.get('username')
        email = request.form.get('email')
        password = request.form.get('password')
        
        if User.query.filter_by(username=username).first():
            flash('Пользователь с таким именем уже существует', 'error')
            return render_template('register.html')
        
        if User.query.filter_by(email=email).first():
            flash('Пользователь с таким email уже существует', 'error')
            return render_template('register.html')
        
        user = User(username=username, email=email)
        user.set_password(password)
        db.session.add(user)
        db.session.commit()
        
        flash('Регистрация успешна! Теперь вы можете войти.', 'success')
        return redirect(url_for('login'))
    
    return render_template('register.html')

@app.route('/profile')
@login_required
def profile():
    """Страница профиля пользователя"""
    orders = Order.query.filter_by(user_id=current_user.id).all()
    return render_template('profile.html', user=current_user, orders=orders)

@app.route('/download')
def download():
    """Страница для скачивания бота"""
    return render_template('download.html')

@app.errorhandler(404)
def page_not_found(e):
    """Обработчик ошибки 404"""
    return render_template('error.html', error_code=404, error_message='Страница не найдена'), 404

@app.errorhandler(500)
def internal_server_error(e):
    """Обработчик ошибки 500"""
    return render_template('error.html', error_code=500, error_message='Внутренняя ошибка сервера'), 500

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=5000, debug=True)