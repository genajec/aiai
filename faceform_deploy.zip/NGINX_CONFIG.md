# Настройка Nginx для совместной работы бота и веб-сайта FaceForm на одном VPS

## Введение

Эта инструкция поможет вам настроить веб-сервер Nginx для одновременной работы Telegram-бота FaceForm и веб-сайта на одном сервере. Nginx будет работать как реверс-прокси, перенаправляя запросы к соответствующим приложениям.

## Предварительные требования

1. Установленный и работающий Telegram-бот FaceForm
2. Установленный веб-сайт FaceForm с помощью скрипта `install_website.sh`
3. Установленный Nginx (`sudo apt install nginx`)

## Настройка конфигурации Nginx

### 1. Создание конфигурационного файла для сайта (если его еще нет)

```bash
sudo nano /etc/nginx/sites-available/faceform_website
```

Вставьте следующую конфигурацию (замените IP_ADDRESS на ваш IP и PORT на порт веб-сайта):

```nginx
server {
    listen 80;
    server_name IP_ADDRESS;  # Замените на ваш IP-адрес или домен
    
    # Логи
    access_log /var/log/nginx/faceform_website_access.log;
    error_log /var/log/nginx/faceform_website_error.log;
    
    # Статические файлы
    location /static {
        alias /home/faceneiro/faceform_website/static;
        expires 30d;
        add_header Cache-Control "public, max-age=2592000";
    }
    
    # Проксирование запросов к веб-приложению Flask
    location / {
        proxy_pass http://localhost:PORT;  # PORT - порт веб-сайта (5000-5010)
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto $scheme;
        
        # Таймауты для длительных запросов
        proxy_connect_timeout 60;
        proxy_send_timeout 60;
        proxy_read_timeout 60;
        
        # Буферы
        proxy_buffering on;
        proxy_buffer_size 4k;
        proxy_buffers 8 16k;
    }
    
    # Настройки безопасности
    add_header X-Content-Type-Options nosniff;
    add_header X-Frame-Options SAMEORIGIN;
    add_header X-XSS-Protection "1; mode=block";
}
```

### 2. Создание отдельной конфигурации для Telegram-вебхуков (если бот использует вебхуки)

```bash
sudo nano /etc/nginx/sites-available/faceform_bot_webhook
```

Вставьте следующую конфигурацию:

```nginx
server {
    listen 8443 ssl;
    server_name IP_ADDRESS;  # Замените на ваш IP-адрес или домен
    
    # SSL настройки (если используются вебхуки)
    ssl_certificate /etc/ssl/certs/faceform-selfsigned.crt;
    ssl_certificate_key /etc/ssl/private/faceform-selfsigned.key;
    ssl_protocols TLSv1.2 TLSv1.3;
    
    # Логи
    access_log /var/log/nginx/faceform_bot_access.log;
    error_log /var/log/nginx/faceform_bot_error.log;
    
    # Проксирование запросов вебхуков для Telegram-бота
    location /WEBHOOK_PATH {  # Замените на путь вебхука вашего бота
        proxy_pass http://localhost:BOT_PORT;  # Порт, на котором запущен ваш бот-сервер
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto $scheme;
    }
}
```

### 3. Активация конфигураций

```bash
# Активация конфигурации сайта
sudo ln -sf /etc/nginx/sites-available/faceform_website /etc/nginx/sites-enabled/

# Активация конфигурации вебхуков бота (если используются)
sudo ln -sf /etc/nginx/sites-available/faceform_bot_webhook /etc/nginx/sites-enabled/

# Проверка конфигурации Nginx
sudo nginx -t

# Применение конфигурации
sudo systemctl restart nginx
```

## Проверка конфигурации

После применения конфигурации проверьте:

1. Веб-сайт доступен по адресу: `http://ваш_IP_адрес`
2. Бот продолжает работать без ошибок
3. Вебхуки Telegram (если используются) корректно обрабатываются

## Оптимизация настроек Nginx для работы под нагрузкой

Оптимизируйте глобальные настройки Nginx для лучшей производительности:

```bash
sudo nano /etc/nginx/nginx.conf
```

Замените секцию `http` на следующую:

```nginx
http {
    # Основные настройки
    include       /etc/nginx/mime.types;
    default_type  application/octet-stream;
    
    # Логи
    log_format  main  '$remote_addr - $remote_user [$time_local] "$request" '
                      '$status $body_bytes_sent "$http_referer" '
                      '"$http_user_agent" "$http_x_forwarded_for"';
    access_log  /var/log/nginx/access.log  main;
    
    # Оптимизация производительности
    sendfile        on;
    tcp_nopush      on;
    tcp_nodelay     on;
    keepalive_timeout  65;
    types_hash_max_size 2048;
    
    # Настройки буферов и таймаутов
    client_body_buffer_size 10K;
    client_header_buffer_size 1k;
    client_max_body_size 8m;
    large_client_header_buffers 2 1k;
    
    # Настройки Gzip
    gzip on;
    gzip_disable "msie6";
    gzip_vary on;
    gzip_proxied any;
    gzip_comp_level 6;
    gzip_buffers 16 8k;
    gzip_http_version 1.1;
    gzip_types text/plain text/css application/json application/javascript text/xml application/xml application/xml+rss text/javascript;
    
    # Включение файлов конфигурации
    include /etc/nginx/conf.d/*.conf;
    include /etc/nginx/sites-enabled/*;
}
```

## Настройка HTTPS для веб-сайта

### Создание самоподписанного сертификата

Если у вас нет домена, можно создать самоподписанный сертификат:

```bash
# Создание директории для сертификатов (если не существует)
sudo mkdir -p /etc/ssl/private /etc/ssl/certs

# Создание самоподписанного сертификата
sudo openssl req -x509 -nodes -days 365 -newkey rsa:2048 \
    -keyout /etc/ssl/private/faceform-selfsigned.key \
    -out /etc/ssl/certs/faceform-selfsigned.crt
```

### Обновление конфигурации Nginx для использования HTTPS

```bash
sudo nano /etc/nginx/sites-available/faceform_website
```

Обновите конфигурацию:

```nginx
# Редирект с HTTP на HTTPS
server {
    listen 80;
    server_name IP_ADDRESS;  # Ваш IP-адрес или домен
    return 301 https://$server_name$request_uri;
}

# HTTPS сервер
server {
    listen 443 ssl http2;
    server_name IP_ADDRESS;  # Ваш IP-адрес или домен
    
    # SSL настройки
    ssl_certificate /etc/ssl/certs/faceform-selfsigned.crt;
    ssl_certificate_key /etc/ssl/private/faceform-selfsigned.key;
    ssl_protocols TLSv1.2 TLSv1.3;
    ssl_prefer_server_ciphers on;
    ssl_ciphers ECDHE-RSA-AES256-GCM-SHA512:DHE-RSA-AES256-GCM-SHA512:ECDHE-RSA-AES256-GCM-SHA384:DHE-RSA-AES256-GCM-SHA384:ECDHE-RSA-AES256-SHA384;
    
    # Логи
    access_log /var/log/nginx/faceform_website_access.log;
    error_log /var/log/nginx/faceform_website_error.log;
    
    # Статические файлы
    location /static {
        alias /home/faceneiro/faceform_website/static;
        expires 30d;
        add_header Cache-Control "public, max-age=2592000";
    }
    
    # Проксирование запросов к веб-приложению Flask
    location / {
        proxy_pass http://localhost:PORT;  # PORT - порт веб-сайта
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto $scheme;
        
        # Таймауты для длительных запросов
        proxy_connect_timeout 60;
        proxy_send_timeout 60;
        proxy_read_timeout 60;
        
        # Буферы
        proxy_buffering on;
        proxy_buffer_size 4k;
        proxy_buffers 8 16k;
    }
    
    # Настройки безопасности
    add_header X-Content-Type-Options nosniff;
    add_header X-Frame-Options SAMEORIGIN;
    add_header X-XSS-Protection "1; mode=block";
    add_header Strict-Transport-Security "max-age=31536000; includeSubDomains" always;
}
```

### Применение новой конфигурации

```bash
sudo nginx -t && sudo systemctl restart nginx
```

## Устранение проблем

### 1. Проблема: Сайт не отображается

Выполните следующие проверки:

```bash
# Проверка доступности сайта локально
curl http://localhost:PORT

# Проверка логов Nginx
sudo tail -f /var/log/nginx/error.log
sudo tail -f /var/log/nginx/faceform_website_error.log

# Проверка логов веб-сайта
tail -f /home/faceneiro/faceform_website/error.log

# Проверка статуса службы веб-сайта
sudo systemctl status faceform_website

# Проверка открытых портов
sudo ss -tulpn | grep PORT
```

### 2. Проблема: Бот не работает

Выполните следующие проверки:

```bash
# Проверка журналов бота
sudo tail -f /home/faceneiro/faceform_bot/bot.log

# Убедитесь, что процесс бота запущен
ps aux | grep python | grep bot

# Проверка статуса службы бота (если настроена)
sudo systemctl status faceform_bot

# Перезапуск бота
sudo systemctl restart faceform_bot
```

### 3. Проблема: Конфликты портов

Если порт, который вы пытаетесь использовать, уже занят:

```bash
# Проверка используемых портов
sudo netstat -tulpn | grep LISTEN

# Проверка, какой процесс использует определенный порт
sudo lsof -i :PORT
```

Измените порт в конфигурациях и перезапустите соответствующие службы.

## Дополнительные рекомендации

1. **Резервное копирование**:
   ```bash
   # Резервное копирование базы данных
   pg_dump -U faceneiro faceform_website_db > faceform_website_db_backup.sql
   
   # Резервное копирование файлов сайта
   tar -czf faceform_website_backup.tar.gz /home/faceneiro/faceform_website
   ```

2. **Мониторинг ресурсов**:
   ```bash
   # Установка утилиты для мониторинга
   sudo apt install htop
   
   # Запуск мониторинга
   htop
   ```

3. **Автоматические обновления**:
   ```bash
   # Настройка автоматических обновлений безопасности
   sudo apt install unattended-upgrades
   sudo dpkg-reconfigure -plow unattended-upgrades
   ```