import cv2
import os
import numpy as np
import matplotlib.pyplot as plt

def view_example(image_path):
    """
    Отображает изображение с помощью matplotlib
    """
    print(f"Просмотр изображения: {image_path}")
    
    # Проверяем существование файла
    if not os.path.exists(image_path):
        print(f"Файл {image_path} не найден")
        return
    
    # Читаем изображение
    img = cv2.imread(image_path)
    if img is None:
        print(f"Не удалось прочитать {image_path}")
        return
    
    # Конвертируем из BGR в RGB для корректного отображения
    img_rgb = cv2.cvtColor(img, cv2.COLOR_BGR2RGB)
    
    # Показываем информацию об изображении
    print(f"Размер изображения: {img.shape}")
    
    # Отображаем
    plt.figure(figsize=(10, 8))
    plt.imshow(img_rgb)
    plt.title(f"Изображение: {os.path.basename(image_path)}")
    plt.axis('off')
    plt.savefig(f"{os.path.basename(image_path)}_preview.png")
    print(f"Сохранено как {os.path.basename(image_path)}_preview.png")

# Просматриваем несколько примеров изображений
recent_examples = [
    "attached_assets/IMG_7858.jpeg",  # Недавно добавленное изображение
    "attached_assets/IMG_7860.png",
    "attached_assets/IMG_7861.png",
    "attached_assets/IMG_7862.png", 
    "attached_assets/IMG_7863.png",
    "attached_assets/IMG_7870.png"
]

# Просматриваем каждое изображение
for example in recent_examples:
    view_example(example)
    print("-" * 50)