#!/usr/bin/env python3
"""
Тестирование механизма ротации ключей LightX API
"""

import logging
import sys
import time
from lightx_key_manager import LightXKeyManager
from lightx_client import LightXClient
import traceback

# Настройка логирования
logging.basicConfig(level=logging.INFO, 
                   format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
                   handlers=[
                       logging.StreamHandler(sys.stdout),
                       logging.FileHandler('key_rotation_test.log')
                   ])
logger = logging.getLogger(__name__)

def test_key_manager_initialization():
    """Тестирует инициализацию менеджера ключей"""
    try:
        logger.info("--- Тест 1: Инициализация LightXKeyManager ---")
        key_manager = LightXKeyManager()
        logger.info(f"Менеджер ключей инициализирован, текущий ключ: {key_manager.get_current_key()[:8]}...")
        
        # Проверяем все ключи
        logger.info("Тестирование всех доступных ключей...")
        key_statuses = key_manager.test_all_keys()
        
        for key, status in key_statuses.items():
            logger.info(f"Ключ {key}: {'✓ Работает' if status else '✗ Не работает'}")
            
        # Получаем статистику
        stats = key_manager.get_key_stats()
        logger.info(f"Статистика ключей: {stats}")
        
        return True
    except Exception as e:
        logger.error(f"Ошибка в тесте инициализации: {e}")
        logger.error(traceback.format_exc())
        return False

def test_key_rotation_on_error():
    """Тестирует ротацию ключей при ошибке"""
    try:
        logger.info("--- Тест 2: Ротация ключей при ошибке ---")
        key_manager = LightXKeyManager()
        initial_key = key_manager.get_current_key()
        logger.info(f"Начальный ключ: {initial_key[:8]}...")
        
        # Имитируем ошибку HTTP 403 (запрещено)
        logger.info("Имитируем ошибку 403 (Forbidden)")
        key_manager.mark_request_error(403, initial_key)
        
        # Должен переключиться на следующий ключ
        next_key = key_manager.switch_to_next_key()
        logger.info(f"Новый ключ после ошибки 403: {next_key[:8]}...")
        
        if next_key != initial_key:
            logger.info("✓ Тест пройден: ключ успешно изменился")
        else:
            logger.warning("✗ Тест не пройден: ключ не изменился")
        
        return next_key != initial_key
    except Exception as e:
        logger.error(f"Ошибка в тесте ротации при ошибке: {e}")
        logger.error(traceback.format_exc())
        return False

def test_lightx_client_key_rotation():
    """Тестирует ротацию ключей в LightX клиенте"""
    try:
        logger.info("--- Тест 3: Ротация ключей в LightXClient ---")
        # Создаем клиент
        client = LightXClient()
        initial_key = client.api_key
        logger.info(f"Начальный ключ клиента: {initial_key[:8]}...")
        
        # Проверяем метод generate_from_text с текстовым запросом
        logger.info("Пробуем метод generate_from_text с текстовым запросом 'красивый закат над океаном'")
        
        # Мы ожидаем, что credits consumed, поэтому ключ должен поменяться
        result = client.generate_from_text("красивый закат над океаном")
        
        # Проверяем, изменился ли ключ
        new_key = client.api_key
        logger.info(f"Новый ключ клиента после запроса: {new_key[:8]}...")
        
        if new_key != initial_key:
            logger.info("✓ Тест пройден: ключ клиента успешно изменился")
        else:
            # Возможно, что запрос был успешным и ключ не нужно было менять
            logger.info("Ключ клиента не изменился после запроса. Это может быть нормально, если запрос был успешным.")
            
        # Получаем статистику ключей
        stats = client.key_manager.get_key_stats()
        logger.info(f"Статистика ключей после запроса: {stats}")
        
        return True
    except Exception as e:
        logger.error(f"Ошибка в тесте клиента: {e}")
        logger.error(traceback.format_exc())
        return False
        
def main():
    """Основная функция"""
    logger.info("Начало тестирования механизма ротации ключей LightX API")
    
    # Тестируем инициализацию
    if not test_key_manager_initialization():
        logger.error("Ошибка в тесте инициализации менеджера ключей")
        return
    
    # Тестируем ротацию при ошибке
    if not test_key_rotation_on_error():
        logger.error("Ошибка в тесте ротации ключей при ошибке")
        return
    
    # Тестируем клиент
    if not test_lightx_client_key_rotation():
        logger.error("Ошибка в тесте клиента")
        return
    
    logger.info("Тестирование успешно завершено!")
    
if __name__ == "__main__":
    main()