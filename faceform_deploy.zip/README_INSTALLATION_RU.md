# Инструкция по установке веб-сайта FaceForm на VPS

## Содержание
1. [Предварительные требования](#предварительные-требования)
2. [Шаги установки](#шаги-установки)
3. [Проверка установки](#проверка-установки)
4. [Настройка Stripe](#настройка-stripe)
5. [Устранение неполадок](#устранение-неполадок)

## Предварительные требования

- VPS с Ubuntu (24.04 или 22.04)
- Доступ к серверу через SSH с правами sudo
- Установленный и работающий бот FaceForm (необязательно, но предполагается)
- Архив `faceform_website.zip` с файлами веб-сайта

## Шаги установки

### 1. Загрузка архива на сервер

Загрузите архив `faceform_website.zip` на ваш сервер одним из способов:

```bash
# Через SCP (с локального компьютера)
scp faceform_website.zip faceneiro@92.113.145.171:~/

# Или через wget/curl (если архив доступен по URL)
wget https://example.com/path/to/faceform_website.zip -O ~/faceform_website.zip

# Или через GitHub (если применимо)
wget https://github.com/genajec/aiai/raw/main/faceform_website.zip -O ~/faceform_website.zip
```

### 2. Загрузка установочного скрипта

Создайте и сделайте исполняемым установочный скрипт:

```bash
# Соединитесь с сервером через SSH
ssh faceneiro@92.113.145.171

# Создайте установочный скрипт
wget https://raw.githubusercontent.com/genajec/aiai/main/install_website.sh -O ~/install_website.sh

# ИЛИ скопируйте из нашего ZIP архива
unzip -j ~/faceform_website.zip "website_archive/install_website.sh" -d ~/

# Сделайте скрипт исполняемым
chmod +x ~/install_website.sh
```

### 3. Установка веб-сайта

```bash
# Установите IP-адрес вашего сервера
export IP_ADDRESS="92.113.145.171"

# Запустите скрипт установки
~/install_website.sh
```

Процесс установки выполнит следующие шаги:
- Распаковку архива с файлами веб-сайта
- Создание виртуального окружения Python
- Установку всех необходимых зависимостей
- Создание базы данных PostgreSQL
- Настройку службы systemd для Gunicorn
- Настройку Nginx как реверс-прокси
- Запуск веб-сайта

## Проверка установки

После успешной установки:

1. Откройте веб-браузер и перейдите по адресу: `http://92.113.145.171` (замените на ваш IP-адрес)
2. Убедитесь, что главная страница сайта загружается правильно
3. Проверьте работу основных функций сайта

## Настройка Stripe

Для включения платежей через Stripe:

1. Откройте файл .env:
   ```bash
   nano /home/faceneiro/faceform_website/.env
   ```

2. Обновите следующие строки вашими ключами Stripe:
   ```
   STRIPE_SECRET_KEY=ваш_секретный_ключ_stripe
   STRIPE_PUBLISHABLE_KEY=ваш_публичный_ключ_stripe
   STRIPE_WEBHOOK_SECRET=ваш_секретный_ключ_вебхука_stripe
   ```

3. Перезапустите службу веб-сайта:
   ```bash
   sudo systemctl restart faceform_website
   ```

## Устранение неполадок

### Просмотр логов

```bash
# Логи Gunicorn (веб-сайт)
tail -f /home/faceneiro/faceform_website/error.log
tail -f /home/faceneiro/faceform_website/access.log

# Логи Nginx
sudo tail -f /var/log/nginx/faceform_website_error.log
sudo tail -f /var/log/nginx/faceform_website_access.log

# Логи службы systemd
sudo journalctl -u faceform_website -f
```

### Проблема: Сайт не открывается

1. Проверьте статус службы веб-сайта:
   ```bash
   sudo systemctl status faceform_website
   ```

2. Проверьте, что порт не занят другим приложением:
   ```bash
   sudo netstat -tulpn | grep 5000  # или другой порт, указанный при установке
   ```

3. Проверьте конфигурацию Nginx:
   ```bash
   sudo nginx -t
   ```

4. Проверьте доступность сайта локально:
   ```bash
   curl http://localhost:5000  # или другой порт, указанный при установке
   ```

### Проблема: Базы данных не создана

1. Подключитесь к PostgreSQL:
   ```bash
   sudo -u postgres psql
   ```

2. Проверьте наличие базы данных:
   ```sql
   \l
   ```

3. Если базы нет, создайте её:
   ```sql
   CREATE DATABASE faceform_website_db;
   GRANT ALL PRIVILEGES ON DATABASE faceform_website_db TO faceneiro;
   ```

4. Инициализируйте базу данных:
   ```bash
   cd /home/faceneiro/faceform_website
   source venv/bin/activate
   python -c "from app import app, db; app.app_context().push(); db.create_all()"
   ```

### Запуск скрипта диагностики

Для быстрой диагностики и устранения распространенных проблем:

```bash
# Загрузите скрипт диагностики
wget https://raw.githubusercontent.com/genajec/aiai/main/troubleshoot.sh -O ~/troubleshoot.sh
chmod +x ~/troubleshoot.sh

# Запустите скрипт диагностики
~/troubleshoot.sh
```

### Контактная информация

Если у вас возникли проблемы при установке, обратитесь к разработчикам:
- Email: info@faceform.ai
- Telegram: @FaceFormBot