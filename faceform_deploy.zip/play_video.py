import cv2
import sys
import logging
import os

# Настройка логирования
logging.basicConfig(level=logging.DEBUG, 
                    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s')
logger = logging.getLogger(__name__)

def play_video(video_path):
    """
    Проигрывает видео и показывает его в окне.
    
    Args:
        video_path (str): Путь к видеофайлу
    
    Returns:
        bool: True если видео успешно проиграно, False в случае ошибки
    """
    try:
        if not os.path.exists(video_path):
            logger.error(f"Файл {video_path} не найден")
            return False
        
        # Открываем видеофайл
        cap = cv2.VideoCapture(video_path)
        if not cap.isOpened():
            logger.error(f"Не удалось открыть видеофайл: {video_path}")
            return False
        
        # Получаем информацию о видео
        fps = cap.get(cv2.CAP_PROP_FPS)
        frame_count = int(cap.get(cv2.CAP_PROP_FRAME_COUNT))
        duration = frame_count / fps if fps > 0 else 0
        
        logger.info(f"Видео: {video_path}")
        logger.info(f"Разрешение: {int(cap.get(cv2.CAP_PROP_FRAME_WIDTH))}x{int(cap.get(cv2.CAP_PROP_FRAME_HEIGHT))}")
        logger.info(f"FPS: {fps}")
        logger.info(f"Длительность: {duration:.2f} сек ({frame_count} кадров)")
        
        # Создаем окно для отображения видео
        window_name = os.path.basename(video_path)
        cv2.namedWindow(window_name, cv2.WINDOW_NORMAL)
        
        # Шаг в миллисекундах между кадрами
        frame_delay = int(1000 / fps) if fps > 0 else 33  # 33мс ~ 30fps
        
        # Проигрываем видео
        frame_idx = 0
        while True:
            ret, frame = cap.read()
            if not ret:
                break
            
            # Отображаем текущий кадр
            cv2.imshow(window_name, frame)
            
            # Выводим прогресс каждые 10% кадров
            frame_idx += 1
            if frame_idx % max(1, (frame_count // 10)) == 0:
                progress = frame_idx * 100 / frame_count
                logger.info(f"Прогресс: {progress:.1f}% ({frame_idx}/{frame_count})")
            
            # Ждем указанное время или до нажатия клавиши
            key = cv2.waitKey(frame_delay)
            
            # Выход при нажатии клавиши 'q' или ESC
            if key == ord('q') or key == 27:  # 27 - код клавиши ESC
                logger.info("Воспроизведение прервано пользователем")
                break
        
        # Освобождаем ресурсы
        cap.release()
        cv2.destroyAllWindows()
        
        logger.info("Воспроизведение видео завершено")
        return True
    
    except Exception as e:
        logger.error(f"Ошибка при воспроизведении видео: {e}")
        import traceback
        logger.error(traceback.format_exc())
        return False

def extract_frames(video_path, output_dir, num_frames=5):
    """
    Извлекает заданное количество кадров из видео и сохраняет их в указанную директорию.
    
    Args:
        video_path (str): Путь к видеофайлу
        output_dir (str): Директория для сохранения кадров
        num_frames (int): Количество кадров для извлечения
    
    Returns:
        list: Список путей к сохраненным кадрам
    """
    try:
        if not os.path.exists(video_path):
            logger.error(f"Файл {video_path} не найден")
            return []
        
        # Создаем директорию, если её нет
        os.makedirs(output_dir, exist_ok=True)
        
        # Открываем видеофайл
        cap = cv2.VideoCapture(video_path)
        if not cap.isOpened():
            logger.error(f"Не удалось открыть видеофайл: {video_path}")
            return []
        
        # Получаем общее количество кадров
        frame_count = int(cap.get(cv2.CAP_PROP_FRAME_COUNT))
        if frame_count <= 0:
            logger.error(f"Не удалось определить количество кадров в видео: {video_path}")
            return []
        
        # Выбираем равномерно распределенные кадры
        frame_indices = [int(i * frame_count / num_frames) for i in range(num_frames)]
        logger.info(f"Извлекаем {num_frames} кадров из позиций: {frame_indices}")
        
        saved_frames = []
        
        # Извлекаем и сохраняем кадры
        for i, frame_idx in enumerate(frame_indices):
            # Устанавливаем позицию чтения
            cap.set(cv2.CAP_PROP_POS_FRAMES, frame_idx)
            
            # Читаем кадр
            ret, frame = cap.read()
            if not ret:
                logger.warning(f"Не удалось прочитать кадр {frame_idx}")
                continue
            
            # Формируем имя файла для сохранения
            output_path = os.path.join(output_dir, f"frame_{i+1:03d}.jpg")
            
            # Сохраняем кадр
            cv2.imwrite(output_path, frame)
            logger.info(f"Сохранен кадр {frame_idx} как {output_path}")
            
            saved_frames.append(output_path)
        
        # Освобождаем ресурсы
        cap.release()
        
        logger.info(f"Извлечено {len(saved_frames)} кадров из видео {video_path}")
        return saved_frames
    
    except Exception as e:
        logger.error(f"Ошибка при извлечении кадров: {e}")
        import traceback
        logger.error(traceback.format_exc())
        return []

if __name__ == "__main__":
    if len(sys.argv) > 1:
        video_path = sys.argv[1]
    else:
        # Ищем обработанное видео
        processed_video = "test_face_video_processed.mp4"
        if os.path.exists(processed_video):
            video_path = processed_video
        else:
            # Ищем любое видео
            video_files = [f for f in os.listdir('.') if f.endswith(('.mp4', '.avi', '.mov'))]
            if not video_files:
                logger.error("Не найдено видеофайлов")
                sys.exit(1)
            
            video_path = video_files[0]
            logger.info(f"Используем первый найденный видеофайл: {video_path}")
    
    # Извлекаем несколько кадров для анализа
    frames_dir = "extracted_frames"
    extracted_frames = extract_frames(video_path, frames_dir, num_frames=5)
    
    if extracted_frames:
        logger.info(f"Извлечено {len(extracted_frames)} кадров в директорию {frames_dir}")
        logger.info(f"Проверьте директорию {frames_dir} для анализа результатов обработки видео.")
    
    # Пытаемся воспроизвести видео, если окно X11 доступно
    try:
        success = play_video(video_path)
        if not success:
            logger.warning("Не удалось воспроизвести видео")
    except Exception as e:
        logger.warning(f"Невозможно отобразить видео (возможно из-за отсутствия X11): {e}")
        logger.info("Извлеченные кадры доступны в директории extracted_frames")