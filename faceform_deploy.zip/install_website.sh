#!/bin/bash
# Скрипт для установки сайта FaceForm на VPS без нарушения работы бота

set -e

# Определяем цвета для вывода
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
RED='\033[0;31m'
NC='\033[0m' # No Color

log_success() {
    echo -e "${GREEN}[✓] $1${NC}"
}

log_info() {
    echo -e "${YELLOW}[i] $1${NC}"
}

log_error() {
    echo -e "${RED}[✗] $1${NC}"
}

echo "=== Начинаем установку FaceForm Website на VPS ==="

# Проверяем наличие IP-адреса
if [ -z "${IP_ADDRESS}" ]; then
    # Попытка автоматически определить IP адрес
    IP_ADDRESS=$(curl -s ifconfig.me)
    if [ -z "${IP_ADDRESS}" ]; then
        log_error "Не удалось автоматически определить IP адрес"
        log_info "Пожалуйста, укажите IP адрес вручную:"
        read IP_ADDRESS
    else
        log_info "Автоматически определен IP адрес: ${IP_ADDRESS}"
    fi
fi

# Создаем директорию для веб-сайта отдельно от директории бота
WEBSITE_DIR="/home/faceneiro/faceform_website"

log_info "Создание директории для веб-сайта..."
mkdir -p $WEBSITE_DIR
cd $WEBSITE_DIR

# Проверяем наличие архива с веб-сайтом
if [ ! -f ~/faceform_website.zip ]; then
    log_error "Архив faceform_website.zip не найден в домашней директории!"
    log_info "Пожалуйста, загрузите архив в домашнюю директорию пользователя faceneiro и попробуйте снова."
    exit 1
fi

# Распаковка архива с веб-сайтом
log_info "Распаковка архива с веб-сайтом..."
cp ~/faceform_website.zip ./
unzip -q faceform_website.zip || {
    log_error "Ошибка при распаковке архива!"
    exit 1
}

# Перемещение файлов из вложенной директории website_archive
log_info "Перемещение файлов из архива..."
if [ -d "website_archive" ]; then
    cp -r website_archive/* ./
    rm -rf website_archive
else
    log_error "Директория website_archive не найдена в распакованном архиве!"
    log_info "Структура архива может отличаться от ожидаемой. Продолжаем установку..."
fi

# Проверяем наличие основных файлов
if [ ! -f "app.py" ] || [ ! -f "main.py" ] || [ ! -f "models.py" ]; then
    log_error "Не найдены основные файлы приложения (app.py, main.py, models.py)!"
    log_info "Пожалуйста, проверьте содержимое архива и структуру файлов."
    exit 1
fi

# Создание виртуального окружения
log_info "Создание виртуального окружения Python..."
python3 -m venv venv || {
    log_error "Ошибка при создании виртуального окружения!"
    log_info "Проверьте наличие пакета python3-venv: sudo apt install python3-venv"
    exit 1
}
source venv/bin/activate

# Установка зависимостей
log_info "Установка зависимостей..."
pip install --upgrade pip
pip install -r requirements.txt || {
    log_error "Ошибка при установке зависимостей!"
    log_info "Проверьте наличие файла requirements.txt и его содержимое."
    exit 1
}

# Проверка порта для Flask (5000 по умолчанию)
PORT=5000
if nc -z localhost $PORT 2>/dev/null; then
    log_info "Порт $PORT уже используется, выбираем другой порт..."
    # Поиск свободного порта
    for p in {5001..5010}; do
        if ! nc -z localhost $p 2>/dev/null; then
            PORT=$p
            log_info "Выбран порт $PORT"
            break
        fi
    done
    if [ $PORT -eq 5000 ]; then
        log_error "Не найдено свободных портов в диапазоне 5001-5010!"
        log_info "Укажите порт вручную:"
        read PORT
    fi
fi

# Создание файла конфигурации .env
log_info "Создание файла конфигурации .env..."
cat > .env << EOL
# Flask settings
FLASK_SECRET_KEY=$(python3 -c "import secrets; print(secrets.token_hex(32))")
FLASK_DEBUG=False

# Database settings
DATABASE_URL=postgresql://faceneiro:${PGPASSWORD}@localhost/faceform_website_db

# Stripe API keys
STRIPE_SECRET_KEY=your_stripe_secret_key
STRIPE_PUBLISHABLE_KEY=your_stripe_publishable_key
STRIPE_WEBHOOK_SECRET=your_stripe_webhook_secret

# Deployment
YOUR_DOMAIN=${IP_ADDRESS}:${PORT}
EOL

log_success "Файл .env создан."

# Создание базы данных PostgreSQL
log_info "Создание базы данных PostgreSQL..."
if sudo -u postgres psql -lqt | cut -d \| -f 1 | grep -qw faceform_website_db; then
    log_info "База данных faceform_website_db уже существует."
else
    sudo -u postgres psql -c "CREATE DATABASE faceform_website_db;" || {
        log_error "Ошибка при создании базы данных!"
        exit 1
    }
    sudo -u postgres psql -c "GRANT ALL PRIVILEGES ON DATABASE faceform_website_db TO faceneiro;" || {
        log_error "Ошибка при назначении прав на базу данных!"
        exit 1
    }
    log_success "База данных создана и настроена."
fi

# Инициализация базы данных
log_info "Инициализация базы данных..."
python3 -c "
from app import app, db
with app.app_context():
    db.create_all()
" || {
    log_error "Ошибка при инициализации базы данных!"
    log_info "Проверьте настройки подключения к базе данных в файле .env"
    exit 1
}
log_success "База данных инициализирована."

# Создание файла службы systemd для Gunicorn
log_info "Создание файла службы systemd для Gunicorn..."
sudo tee /etc/systemd/system/faceform_website.service > /dev/null << EOL
[Unit]
Description=Gunicorn instance to serve FaceForm Website
After=network.target postgresql.service

[Service]
User=faceneiro
Group=www-data
WorkingDirectory=${WEBSITE_DIR}
Environment="PATH=${WEBSITE_DIR}/venv/bin"
ExecStart=${WEBSITE_DIR}/venv/bin/gunicorn --workers 3 --bind 0.0.0.0:${PORT} --access-logfile ${WEBSITE_DIR}/access.log --error-logfile ${WEBSITE_DIR}/error.log main:app
Restart=always
RestartSec=5
StartLimitInterval=0

[Install]
WantedBy=multi-user.target
EOL
log_success "Служба systemd настроена."

# Настройка Nginx для веб-сайта
log_info "Настройка Nginx для веб-сайта..."
sudo tee /etc/nginx/sites-available/faceform_website > /dev/null << EOL
server {
    listen 80;
    server_name ${IP_ADDRESS};

    # Логи
    access_log /var/log/nginx/faceform_website_access.log;
    error_log /var/log/nginx/faceform_website_error.log;

    # Статические файлы
    location /static {
        alias ${WEBSITE_DIR}/static;
        expires 30d;
        add_header Cache-Control "public, max-age=2592000";
    }

    # Проксирование запросов к веб-приложению Flask
    location / {
        proxy_pass http://localhost:${PORT};
        proxy_set_header Host \$host;
        proxy_set_header X-Real-IP \$remote_addr;
        proxy_set_header X-Forwarded-For \$proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto \$scheme;

        # Таймауты для длительных запросов
        proxy_connect_timeout 60;
        proxy_send_timeout 60;
        proxy_read_timeout 60;
        
        # Буферы
        proxy_buffering on;
        proxy_buffer_size 4k;
        proxy_buffers 8 16k;
    }
}
EOL
log_success "Конфигурация Nginx создана."

# Создание ссылки на конфиг nginx и перезапуск
log_info "Активация конфигурации Nginx..."
sudo ln -sf /etc/nginx/sites-available/faceform_website /etc/nginx/sites-enabled/
sudo nginx -t && sudo systemctl restart nginx || {
    log_error "Ошибка в конфигурации Nginx!"
    log_info "Проверьте конфигурацию Nginx: sudo nginx -t"
    exit 1
}
log_success "Конфигурация Nginx активирована."

# Запуск службы
log_info "Запуск службы Gunicorn..."
sudo systemctl daemon-reload
sudo systemctl start faceform_website || {
    log_error "Ошибка при запуске службы!"
    log_info "Проверьте логи службы: sudo journalctl -u faceform_website"
    exit 1
}
sudo systemctl enable faceform_website || {
    log_error "Ошибка при добавлении службы в автозапуск!"
    exit 1
}
log_success "Служба запущена и добавлена в автозапуск."

echo ""
echo "=== Установка FaceForm Website завершена! ==="
echo ""
log_success "Веб-сайт доступен по адресу: http://${IP_ADDRESS}"
log_info "Порт приложения: ${PORT}"
log_info "Директория установки: ${WEBSITE_DIR}"
log_info "Чтобы отредактировать настройки, используйте файл .env в директории ${WEBSITE_DIR}"
log_info "Для просмотра логов используйте: sudo journalctl -u faceform_website"
echo ""
log_info "После установки рекомендуется:"
echo "1. Обновить Stripe API ключи в файле .env для корректной работы платежей"
echo "2. Перезапустить службу после внесения изменений: sudo systemctl restart faceform_website"
echo "3. Настроить HTTPS с помощью Let's Encrypt, если у вас есть домен"
echo ""