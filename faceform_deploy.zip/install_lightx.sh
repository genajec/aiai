#!/bin/bash
# Скрипт для установки и настройки LightX API интеграции

# Цвета для вывода
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
RED='\033[0;31m'
NC='\033[0m' # No Color

echo -e "${GREEN}Установка интеграции LightX API для FaceForm бота${NC}"
echo "==================================================="

# Проверка наличия архива
if [ ! -f "lightx_integration.zip" ]; then
    echo -e "${RED}Ошибка: Файл lightx_integration.zip не найден${NC}"
    exit 1
fi

# Создание директории для интеграции
echo -e "${YELLOW}Создание директории для интеграции...${NC}"
mkdir -p lightx_integration
rm -rf lightx_integration/*

# Распаковка архива
echo -e "${YELLOW}Распаковка архива...${NC}"
unzip -o lightx_integration.zip -d lightx_integration/

# Копирование файлов в основную директорию
echo -e "${YELLOW}Копирование файлов в основную директорию...${NC}"
cp lightx_integration/lightx_api.py .
cp lightx_integration/test_lightx.py .
cp lightx_integration/lightx_bot_integration.py .
cp lightx_integration/run_test_lightx.py .
cp lightx_integration/bot_integration.py .
cp lightx_integration/README_LIGHTX.md .

# Создание резервной копии бота
echo -e "${YELLOW}Создание резервной копии bot.py...${NC}"
cp bot.py bot.py.backup_lightx

# Настройка прав доступа
echo -e "${YELLOW}Настройка прав доступа...${NC}"
chmod +x lightx_api.py test_lightx.py lightx_bot_integration.py run_test_lightx.py bot_integration.py

# Запрос API ключа
echo -e "${YELLOW}Для использования LightX API требуется API-ключ.${NC}"
echo -n "Введите ваш API-ключ LightX (или нажмите Enter, чтобы пропустить): "
read -r API_KEY

if [ -n "$API_KEY" ]; then
    # Экспорт API ключа в переменные окружения
    export LIGHTX_API_KEY="$API_KEY"
    echo -e "${GREEN}API-ключ установлен в переменную окружения LIGHTX_API_KEY${NC}"
    
    # Проверка файла конфигурации supervisor
    CONFIG_FILE="/etc/supervisor/conf.d/faceform_bot_polling.conf"
    
    if [ -f "$CONFIG_FILE" ]; then
        echo -e "${YELLOW}Добавление API-ключа в конфигурацию supervisor...${NC}"
        
        # Проверка, есть ли уже LIGHTX_API_KEY в конфигурации
        if grep -q "LIGHTX_API_KEY" "$CONFIG_FILE"; then
            # Обновляем существующую строку
            sudo sed -i "s/LIGHTX_API_KEY=.*/LIGHTX_API_KEY=$API_KEY/" "$CONFIG_FILE"
            echo -e "${GREEN}API-ключ LightX обновлен в конфигурации${NC}"
        else
            # Проверяем, есть ли строка environment
            if grep -q "environment=" "$CONFIG_FILE"; then
                # Добавляем LIGHTX_API_KEY в существующую строку environment
                CURRENT_ENV=$(grep "environment=" "$CONFIG_FILE")
                if echo "$CURRENT_ENV" | grep -q ",$"; then
                    # Если строка заканчивается запятой, добавляем без запятой
                    NEW_ENV="${CURRENT_ENV}LIGHTX_API_KEY=$API_KEY"
                else
                    # Иначе добавляем с запятой
                    NEW_ENV="${CURRENT_ENV},LIGHTX_API_KEY=$API_KEY"
                fi
                sudo sed -i "s|$CURRENT_ENV|$NEW_ENV|" "$CONFIG_FILE"
            else
                # Добавляем новую строку environment
                sudo sed -i "/^user=/a environment=LIGHTX_API_KEY=$API_KEY" "$CONFIG_FILE"
            fi
            echo -e "${GREEN}API-ключ LightX добавлен в конфигурацию supervisor${NC}"
        fi
    else
        echo -e "${YELLOW}Файл конфигурации supervisor не найден. API-ключ установлен только в текущей сессии.${NC}"
    fi
else
    echo -e "${YELLOW}API-ключ не указан. LightX API будет недоступен.${NC}"
fi

# Предложение тестирования API
echo -e "${YELLOW}Хотите протестировать LightX API? (y/n)${NC}"
read -r test_api

if [ "$test_api" = "y" ] || [ "$test_api" = "Y" ]; then
    echo -e "${YELLOW}Доступные тесты:${NC}"
    echo "1. Просмотр доступных стилей причесок"
    echo "2. Тестирование на демо-изображении"
    echo "3. Запуск тестового бота"
    echo -n "Выберите опцию (1-3): "
    read -r test_option
    
    case $test_option in
        1)
            echo -e "${YELLOW}Получение списка доступных стилей причесок...${NC}"
            python3 test_lightx.py --styles
            ;;
        2)
            echo -e "${YELLOW}Тестирование на демо-изображении...${NC}"
            if [ -f "demo_base_face.jpg" ]; then
                python3 test_lightx.py demo_base_face.jpg "короткий боб"
            else
                echo -e "${RED}Ошибка: Файл demo_base_face.jpg не найден${NC}"
                echo -e "${YELLOW}Введите путь к изображению для тестирования:${NC}"
                read -r test_image
                if [ -f "$test_image" ]; then
                    python3 test_lightx.py "$test_image" "короткий боб"
                else
                    echo -e "${RED}Ошибка: Файл $test_image не найден${NC}"
                fi
            fi
            ;;
        3)
            echo -e "${YELLOW}Запуск тестового бота...${NC}"
            echo -e "${YELLOW}Бот будет запущен в фоновом режиме. Для остановки нажмите Ctrl+C${NC}"
            python3 run_test_lightx.py
            ;;
        *)
            echo -e "${RED}Неверная опция${NC}"
            ;;
    esac
fi

# Предложение интеграции в бота
echo -e "${YELLOW}Хотите интегрировать LightX API в основного бота? (y/n)${NC}"
read -r integrate_bot

if [ "$integrate_bot" = "y" ] || [ "$integrate_bot" = "Y" ]; then
    echo -e "${YELLOW}Интеграция LightX API в основного бота...${NC}"
    python3 bot_integration.py
    
    if [ $? -eq 0 ]; then
        echo -e "${GREEN}Интеграция успешно выполнена!${NC}"
        
        # Предложение перезапуска бота
        echo -e "${YELLOW}Хотите перезапустить бота? (y/n)${NC}"
        read -r restart_bot
        
        if [ "$restart_bot" = "y" ] || [ "$restart_bot" = "Y" ]; then
            echo -e "${YELLOW}Перезапуск бота...${NC}"
            sudo supervisorctl restart faceform_bot_polling
            echo -e "${GREEN}Бот перезапущен!${NC}"
        fi
    else
        echo -e "${RED}Ошибка при интеграции${NC}"
        echo -e "${YELLOW}Хотите восстановить бота из резервной копии? (y/n)${NC}"
        read -r restore_bot
        
        if [ "$restore_bot" = "y" ] || [ "$restore_bot" = "Y" ]; then
            echo -e "${YELLOW}Восстановление бота из резервной копии...${NC}"
            cp bot.py.backup_lightx bot.py
            echo -e "${GREEN}Бот восстановлен из резервной копии.${NC}"
        fi
    fi
fi

echo -e "${GREEN}Установка завершена!${NC}"
echo "==================================================="
echo -e "${YELLOW}Рекомендации по использованию:${NC}"
echo "1. Документация по интеграции: README_LIGHTX.md"
echo "2. Тестирование API: python3 test_lightx.py --styles"
echo "3. Запуск тестового бота: python3 run_test_lightx.py"
echo "4. Интеграция в основного бота: python3 bot_integration.py"
echo "5. Перезапуск бота: sudo supervisorctl restart faceform_bot_polling"
echo "==================================================="