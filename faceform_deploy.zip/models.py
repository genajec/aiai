from datetime import datetime
from app import db
from flask_login import UserMixin
from werkzeug.security import generate_password_hash, check_password_hash

class User(UserMixin, db.Model):
    """Модель пользователя системы"""
    id = db.Column(db.Integer, primary_key=True)
    username = db.Column(db.String(64), unique=True, nullable=False)
    email = db.Column(db.String(120), unique=True, nullable=False)
    password_hash = db.Column(db.String(256))
    telegram_id = db.Column(db.String(64), unique=True, nullable=True)
    credits = db.Column(db.Integer, default=0)
    is_admin = db.Column(db.Boolean, default=False)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    
    # Отношения
    orders = db.relationship('Order', backref='user', lazy=True)
    
    def set_password(self, password):
        """Установка хеша пароля"""
        self.password_hash = generate_password_hash(password)
    
    def check_password(self, password):
        """Проверка пароля"""
        return check_password_hash(self.password_hash, password)
    
    def add_credits(self, amount):
        """Добавление кредитов пользователю"""
        self.credits += amount
    
    def use_credit(self):
        """Использование одного кредита"""
        if self.credits > 0:
            self.credits -= 1
            return True
        return False
    
    def __repr__(self):
        return f'<User {self.username}>'

class Package(db.Model):
    """Модель пакета кредитов"""
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(64), nullable=False)
    description = db.Column(db.String(256), nullable=True)
    credits = db.Column(db.Integer, nullable=False)
    price = db.Column(db.Float, nullable=False)
    is_popular = db.Column(db.Boolean, default=False)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    
    # Отношения
    orders = db.relationship('Order', backref='package', lazy=True)
    
    def __repr__(self):
        return f'<Package {self.name}: {self.credits} credits for {self.price}>'

class Order(db.Model):
    """Модель заказа кредитов"""
    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey('user.id'), nullable=True)
    package_id = db.Column(db.Integer, db.ForeignKey('package.id'), nullable=False)
    session_id = db.Column(db.String(256), unique=True, nullable=True)
    payment_id = db.Column(db.String(256), unique=True, nullable=True)
    amount = db.Column(db.Float, nullable=False)
    status = db.Column(db.String(64), default='pending')  # pending, completed, failed, refunded
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    completed_at = db.Column(db.DateTime, nullable=True)
    
    def __repr__(self):
        return f'<Order {self.id}: {self.status}>'
    
    def complete(self):
        """Отметка заказа как выполненного"""
        self.status = 'completed'
        self.completed_at = datetime.utcnow()
        
        # Если есть пользователь, добавляем ему кредиты
        if self.user_id:
            user = User.query.get(self.user_id)
            if user and self.package:
                user.add_credits(self.package.credits)

class Feature(db.Model):
    """Модель функций/возможностей бота"""
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(64), nullable=False)
    description = db.Column(db.Text, nullable=True)
    credits_cost = db.Column(db.Integer, default=1)
    is_premium = db.Column(db.Boolean, default=False)
    is_enabled = db.Column(db.Boolean, default=True)
    
    def __repr__(self):
        return f'<Feature {self.name}: {self.credits_cost} credits>'

class ServicePrice(db.Model):
    """Модель цен на услуги для отображения на сайте"""
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(64), nullable=False)
    description = db.Column(db.Text, nullable=True)
    price = db.Column(db.Float, nullable=False)
    is_popular = db.Column(db.Boolean, default=False)
    is_enabled = db.Column(db.Boolean, default=True)
    feature_list = db.Column(db.Text, nullable=True)  # JSON список функций
    
    def __repr__(self):
        return f'<ServicePrice {self.name}: {self.price}>'