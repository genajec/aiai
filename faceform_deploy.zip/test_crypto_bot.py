#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
Скрипт для тестирования функциональности Crypto Bot в тестовом режиме
"""

import logging
import os
import sys
import json
from datetime import datetime
from database import init_db, get_user_credits, create_transaction, complete_transaction, get_or_create_user
from crypto_bot_payment import CryptoBotPayment

# Настройка логирования
logging.basicConfig(level=logging.INFO,
                   format='%(asctime)s - %(name)s - %(levelname)s - %(message)s')
logger = logging.getLogger(__name__)

def setup_test_environment():
    """Настраивает тестовое окружение"""
    # Устанавливаем переменную окружения для тестового режима
    os.environ["TEST_CRYPTO_BOT"] = "true"
    logger.info("Тестовый режим Crypto Bot активирован")
    
    # Инициализируем базу данных
    init_db()
    logger.info("База данных инициализирована")
    
    # Создаем тестового пользователя
    test_user_id = 123456789  # Произвольный тестовый ID пользователя
    get_or_create_user(test_user_id, "test_user", "Test", "User")
    logger.info(f"Создан тестовый пользователь с ID {test_user_id}")
    
    return test_user_id

def test_crypto_bot_payment():
    """Тестирует полный цикл оплаты через Crypto Bot"""
    test_user_id = setup_test_environment()
    
    # Получаем начальное количество кредитов
    initial_credits = get_user_credits(test_user_id)
    logger.info(f"Начальное количество кредитов: {initial_credits}")
    
    # Создаем экземпляр платежной системы в тестовом режиме
    payment = CryptoBotPayment()
    logger.info("Создан экземпляр платежной системы")
    
    # Выводим доступные пакеты кредитов
    credit_packages = payment.get_credit_packages()
    logger.info(f"Доступные пакеты кредитов: {json.dumps(credit_packages, indent=2)}")
    
    # Выбираем первый пакет
    selected_package = credit_packages[0]
    logger.info(f"Выбран пакет: {selected_package}")
    
    # Создаем платеж
    payment_info = payment.create_payment(
        amount=selected_package["price"],
        package_id=selected_package["id"],
        telegram_id=test_user_id
    )
    
    if not payment_info:
        logger.error("Не удалось создать платеж")
        return False
        
    logger.info(f"Создан тестовый платеж: {json.dumps(payment_info, indent=2)}")
    
    # Создаем транзакцию в базе данных
    transaction = create_transaction(
        telegram_id=test_user_id,
        amount=selected_package["price"],
        credits=selected_package["credits"],
        payment_id=payment_info.get("payment_id")
    )
    logger.info(f"Создана транзакция в базе данных с ID: {payment_info.get('payment_id')}")
    
    # Имитируем webhook от Crypto Bot - проверяем статус платежа
    payment_status = payment.check_payment_status(payment_info.get("payment_id"))
    logger.info(f"Статус платежа: {payment_status}")
    
    # Завершаем транзакцию (как если бы пришел вебхук)
    complete_transaction(payment_info.get("payment_id"), status="completed")
    logger.info(f"Транзакция завершена")
    
    # Проверяем количество кредитов после оплаты
    final_credits = get_user_credits(test_user_id)
    logger.info(f"Количество кредитов после оплаты: {final_credits}")
    
    # Проверяем, что кредиты были начислены
    if final_credits == initial_credits + selected_package["credits"]:
        logger.info(f"✅ Тест успешно пройден! Начислено {selected_package['credits']} кредитов.")
        return True
    else:
        logger.error(f"❌ Тест не пройден! Ожидалось {initial_credits + selected_package['credits']} кредитов, получено {final_credits}")
        return False

def simulate_webhook(user_id, invoice_id, status="paid"):
    """Имитирует вебхук от Crypto Bot"""
    logger.info(f"Симуляция вебхука от Crypto Bot для пользователя {user_id}, invoice_id: {invoice_id}")
    
    # Создаем данные вебхука
    webhook_data = {
        "update_id": int(datetime.now().timestamp()),
        "payload": f"package_id:basic_crypto,user_id:{user_id}",
        "status": status,
        "invoice_id": invoice_id
    }
    
    logger.info(f"Данные вебхука: {json.dumps(webhook_data, indent=2)}")
    
    # Обрабатываем вебхук как в main.py
    if status == "paid":
        # Извлекаем payload
        payload = webhook_data.get("payload", "")
        user_id = None
        package_id = None
        
        # Обрабатываем payload формата "package_id:xxx,user_id:yyy"
        if payload:
            payload_parts = payload.split(',')
            for part in payload_parts:
                key_value = part.split(':')
                if len(key_value) == 2:
                    key, value = key_value
                    if key == "user_id":
                        user_id = int(value)
                    elif key == "package_id":
                        package_id = value
        
        # Если удалось извлечь ID пользователя и ID пакета
        if user_id and package_id:
            # Получаем информацию о пакете
            payment = CryptoBotPayment()
            credit_packages = payment.get_credit_packages()
            
            selected_package = None
            for package in credit_packages:
                if package["id"] == package_id:
                    selected_package = package
                    break
            
            if selected_package:
                # Завершаем транзакцию
                complete_transaction(invoice_id, status="completed")
                logger.info(f"Транзакция {invoice_id} завершена через симуляцию вебхука")
                
                # Проверяем количество кредитов
                credits = get_user_credits(user_id)
                logger.info(f"Количество кредитов пользователя {user_id} после вебхука: {credits}")
                return True
    
    return False

if __name__ == "__main__":
    logger.info("Запуск теста оплаты через Crypto Bot")
    success = test_crypto_bot_payment()
    logger.info(f"Результат теста: {'Успешно' if success else 'Ошибка'}")
    
    sys.exit(0 if success else 1)