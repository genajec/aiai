#!/usr/bin/env python
"""
Этот тест проверяет интеграцию между DeepL API и LightX API.
Тест проверит, что русский текст корректно переводится и используется при запросах к LightX.
"""

import logging
import sys
from bot import FaceShapeBot

# Настроим логирование для лучшей видимости процесса
logging.basicConfig(
    level=logging.DEBUG, 
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    handlers=[
        logging.StreamHandler(sys.stdout)
    ]
)
logger = logging.getLogger(__name__)

def test_translation_with_deepl():
    """
    Тестирует перевод с помощью DeepL API
    """
    logger.info("=== Тест перевода с DeepL API ===")
    
    bot = FaceShapeBot(use_webhook=False)
    
    # Тестовые фразы на русском
    test_phrases = [
        "Создай длинные волнистые волосы",
        "Замени фон на пляж",
        "Синий цвет волос с длинными локонами",
        "Короткая стрижка пикси"
    ]
    
    for phrase in test_phrases:
        logger.info(f"Исходная фраза: '{phrase}'")
        # Используем приватный метод для теста
        translated = bot._translate_with_deepl(phrase)
        logger.info(f"Перевод через DeepL: '{translated}'")
        
        # Проверяем перевод с улучшением для LightX API
        improved = bot._translate_prompt_to_english(phrase)
        logger.info(f"Улучшенный перевод для LightX API: '{improved}'\n")

def main():
    """Основная функция теста"""
    logger.info("Запуск теста интеграции DeepL и LightX API")
    
    try:
        test_translation_with_deepl()
        logger.info("Тесты успешно завершены")
    except Exception as e:
        logger.error(f"Ошибка в тестах: {e}")
        import traceback
        logger.error(traceback.format_exc())

if __name__ == "__main__":
    main()