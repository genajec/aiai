#!/bin/bash
# Скрипт для устранения проблем с установкой веб-сайта FaceForm

set -e

echo "=== Скрипт диагностики веб-сайта FaceForm ==="

WEBSITE_DIR="/home/faceneiro/faceform_website"

# Проверка наличия директории
if [ ! -d "$WEBSITE_DIR" ]; then
    echo "❌ Директория $WEBSITE_DIR не найдена! Установка не была выполнена."
    exit 1
else
    echo "✓ Директория веб-сайта найдена."
fi

# Проверка виртуального окружения
if [ ! -d "$WEBSITE_DIR/venv" ]; then
    echo "❌ Виртуальное окружение не найдено!"
    echo "Создание виртуального окружения..."
    cd $WEBSITE_DIR
    python3 -m venv venv
    source venv/bin/activate
    pip install --upgrade pip
    pip install -r requirements.txt
else
    echo "✓ Виртуальное окружение найдено."
fi

# Проверка файла .env
if [ ! -f "$WEBSITE_DIR/.env" ]; then
    echo "❌ Файл .env не найден!"
    echo "Создание файла .env..."
    cd $WEBSITE_DIR
    cat > .env << EOL
# Flask settings
FLASK_SECRET_KEY=$(python3 -c "import secrets; print(secrets.token_hex(32))")
FLASK_DEBUG=False

# Database settings
DATABASE_URL=postgresql://faceneiro:${PGPASSWORD}@localhost/faceform_website_db

# Stripe API keys
STRIPE_SECRET_KEY=ваш_секретный_ключ_stripe
STRIPE_PUBLISHABLE_KEY=ваш_публичный_ключ_stripe
STRIPE_WEBHOOK_SECRET=ваш_секретный_ключ_вебхука_stripe

# Deployment
YOUR_DOMAIN=${IP_ADDRESS}:5000
EOL
    echo "✓ Файл .env создан. Пожалуйста, отредактируйте его и укажите правильные значения."
else
    echo "✓ Файл .env найден."
fi

# Проверка базы данных
echo "Проверка базы данных PostgreSQL..."
if sudo -u postgres psql -lqt | cut -d \| -f 1 | grep -qw faceform_website_db; then
    echo "✓ База данных faceform_website_db существует."
else
    echo "❌ База данных не найдена!"
    echo "Создание базы данных..."
    sudo -u postgres psql -c "CREATE DATABASE faceform_website_db;"
    sudo -u postgres psql -c "GRANT ALL PRIVILEGES ON DATABASE faceform_website_db TO faceneiro;"
    
    # Инициализация базы данных
    cd $WEBSITE_DIR
    source venv/bin/activate
    python3 -c "
    from app import app, db
    with app.app_context():
        db.create_all()
    "
    echo "✓ База данных создана и инициализирована."
fi

# Проверка конфигурации Nginx
if [ ! -f "/etc/nginx/sites-available/faceform_website" ]; then
    echo "❌ Конфигурация Nginx не найдена!"
    echo "Создание конфигурации Nginx..."
    sudo tee /etc/nginx/sites-available/faceform_website > /dev/null << EOL
server {
    listen 80;
    server_name ${IP_ADDRESS};

    location /static {
        alias ${WEBSITE_DIR}/static;
    }

    location / {
        proxy_pass http://localhost:5000;
        proxy_set_header Host \$host;
        proxy_set_header X-Real-IP \$remote_addr;
        include proxy_params;
    }
}
EOL
    sudo ln -sf /etc/nginx/sites-available/faceform_website /etc/nginx/sites-enabled/
    sudo nginx -t && sudo systemctl restart nginx
    echo "✓ Конфигурация Nginx создана и активирована."
else
    echo "✓ Конфигурация Nginx найдена."
fi

# Проверка службы systemd
if [ ! -f "/etc/systemd/system/faceform_website.service" ]; then
    echo "❌ Служба systemd не найдена!"
    echo "Создание службы systemd..."
    sudo tee /etc/systemd/system/faceform_website.service > /dev/null << EOL
[Unit]
Description=Gunicorn instance to serve FaceForm Website
After=network.target

[Service]
User=faceneiro
Group=www-data
WorkingDirectory=${WEBSITE_DIR}
Environment="PATH=${WEBSITE_DIR}/venv/bin"
ExecStart=${WEBSITE_DIR}/venv/bin/gunicorn --workers 3 --bind 0.0.0.0:5000 --access-logfile ${WEBSITE_DIR}/access.log --error-logfile ${WEBSITE_DIR}/error.log main:app

[Install]
WantedBy=multi-user.target
EOL
    sudo systemctl daemon-reload
    sudo systemctl start faceform_website
    sudo systemctl enable faceform_website
    echo "✓ Служба systemd создана и запущена."
else
    echo "✓ Служба systemd найдена."
fi

# Проверка статуса службы
echo "Проверка статуса службы..."
if systemctl is-active --quiet faceform_website; then
    echo "✓ Служба faceform_website запущена и работает."
else
    echo "❌ Служба faceform_website остановлена!"
    echo "Перезапуск службы..."
    sudo systemctl restart faceform_website
    if systemctl is-active --quiet faceform_website; then
        echo "✓ Служба успешно перезапущена."
    else
        echo "❌ Не удалось перезапустить службу!"
        echo "Просмотр логов для диагностики..."
        sudo journalctl -u faceform_website -n 50
    fi
fi

# Проверка доступности сайта
echo "Проверка доступности сайта..."
if curl -s --head http://localhost:5000 | grep "200 OK" > /dev/null; then
    echo "✓ Сайт доступен по адресу http://localhost:5000"
else
    echo "❌ Сайт недоступен!"
    echo "Просмотр последних ошибок..."
    if [ -f "$WEBSITE_DIR/error.log" ]; then
        tail -n 50 $WEBSITE_DIR/error.log
    fi
fi

echo "=== Диагностика завершена ==="