import cv2
import numpy as np
import os
import logging

# Настройка логирования
logging.basicConfig(level=logging.DEBUG, 
                    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s')
logger = logging.getLogger(__name__)

def create_test_video(output_path="test_face_video.mp4", duration_sec=5, fps=30):
    """
    Создает тестовое видео с изображением лица для тестирования обработки видео.
    
    Args:
        output_path (str): Путь для сохранения выходного видео
        duration_sec (int): Длительность видео в секундах
        fps (int): Частота кадров в секунду
    
    Returns:
        str: Путь к созданному видеофайлу или None в случае ошибки
    """
    try:
        # Проверяем наличие тестового изображения с лицом
        face_image_path = "test_face.jpg"
        
        # Если тестового изображения нет, создаем заглушку с цветным прямоугольником
        if not os.path.exists(face_image_path):
            logger.info(f"Тестовое изображение {face_image_path} не найдено, создаем заглушку")
            # Создаем простое изображение с цветным прямоугольником и текстом
            img = np.ones((720, 1280, 3), dtype=np.uint8) * 50  # Темно-серый фон
            
            # Добавляем цветной прямоугольник для имитации лица
            cv2.rectangle(img, (480, 200), (800, 520), (200, 200, 200), -1)  # Серый прямоугольник
            
            # Добавляем глаза и рот для имитации лица
            cv2.circle(img, (560, 300), 30, (255, 255, 255), -1)  # Левый глаз
            cv2.circle(img, (720, 300), 30, (255, 255, 255), -1)  # Правый глаз
            cv2.circle(img, (560, 300), 10, (0, 0, 0), -1)  # Левый зрачок
            cv2.circle(img, (720, 300), 10, (0, 0, 0), -1)  # Правый зрачок
            cv2.rectangle(img, (580, 400), (700, 420), (0, 0, 200), -1)  # Рот
            
            # Сохраняем изображение для использования
            cv2.imwrite(face_image_path, img)
            logger.info(f"Создано изображение-заглушка: {face_image_path}")
        
        # Загружаем изображение для создания видео
        img = cv2.imread(face_image_path)
        if img is None:
            logger.error(f"Не удалось загрузить изображение: {face_image_path}")
            return None
        
        # Получаем размеры изображения
        height, width = img.shape[:2]
        
        # Создаем объект VideoWriter
        fourcc = cv2.VideoWriter_fourcc(*'mp4v')
        out = cv2.VideoWriter(output_path, fourcc, fps, (width, height))
        
        # Определяем общее количество кадров
        total_frames = duration_sec * fps
        logger.info(f"Создаем видео с {total_frames} кадрами, длительностью {duration_sec} секунд")
        
        # Создаем видео из повторяющегося изображения с небольшой анимацией
        for i in range(total_frames):
            # Создаем копию изображения для анимации
            frame = img.copy()
            
            # Добавляем анимацию - движущийся цветной индикатор для уникальности каждого кадра
            indicator_position = int(width * (i / total_frames))
            cv2.rectangle(frame, (indicator_position, 10), (indicator_position + 20, 30), (0, 255, 0), -1)
            
            # Добавляем счетчик кадров
            cv2.putText(frame, f"Frame: {i+1}/{total_frames}", (50, 50), 
                       cv2.FONT_HERSHEY_SIMPLEX, 1, (255, 255, 255), 2)
            
            # Записываем кадр в видео
            out.write(frame)
            
            # Выводим прогресс каждые 10% кадров
            if i % (total_frames // 10) == 0:
                logger.info(f"Создание видео: {i}/{total_frames} кадров ({i*100/total_frames:.1f}%)")
        
        # Освобождаем ресурсы
        out.release()
        
        logger.info(f"Тестовое видео успешно создано: {output_path}")
        logger.info(f"Размер видео: {os.path.getsize(output_path)/1024/1024:.2f} MB")
        
        return output_path
    
    except Exception as e:
        logger.error(f"Ошибка при создании тестового видео: {e}")
        import traceback
        logger.error(traceback.format_exc())
        return None

if __name__ == "__main__":
    video_path = create_test_video()
    if video_path:
        logger.info(f"Видео создано успешно: {video_path}")
    else:
        logger.error("Не удалось создать тестовое видео")