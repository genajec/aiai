#!/usr/bin/env python3
"""
Скрипт для импорта базы данных из SQL-файла в SQLite.
"""

import os
import sqlite3
import datetime

def import_database(sql_file, db_path):
    """
    Импортирует данные из SQL-файла в базу данных SQLite.
    
    Args:
        sql_file (str): Путь к SQL-файлу с данными
        db_path (str): Путь к файлу базы данных SQLite
    """
    print(f"Импорт данных из {sql_file} в базу данных {db_path}")
    
    # Проверяем существование SQL-файла
    if not os.path.exists(sql_file):
        print(f"Ошибка: SQL-файл {sql_file} не найден!")
        return False
    
    # Создаем резервную копию текущей базы данных, если она существует
    if os.path.exists(db_path):
        backup_path = f"{db_path}.backup_{datetime.datetime.now().strftime('%Y%m%d%H%M%S')}"
        try:
            import shutil
            shutil.copy2(db_path, backup_path)
            print(f"Создана резервная копия базы данных: {backup_path}")
        except Exception as e:
            print(f"Предупреждение: Не удалось создать резервную копию базы данных: {e}")
    
    # Читаем SQL-файл
    try:
        with open(sql_file, 'r') as f:
            sql_script = f.read()
    except Exception as e:
        print(f"Ошибка при чтении SQL-файла: {e}")
        return False
    
    # Подключаемся к базе данных
    try:
        conn = sqlite3.connect(db_path)
        cursor = conn.cursor()
        
        # Выполняем SQL-скрипт
        cursor.executescript(sql_script)
        conn.commit()
        
        print(f"Импорт успешно завершен. База данных обновлена: {db_path}")
        return True
    except sqlite3.Error as e:
        print(f"Ошибка при импорте данных в базу данных: {e}")
        return False
    finally:
        # Закрываем соединение с базой данных
        if 'conn' in locals():
            conn.close()

if __name__ == "__main__":
    # Пути по умолчанию
    sql_file = "faceform_bot_db_export.sql"
    db_path = "faceform_bot.db"
    
    # Импортируем данные в базу данных
    import_database(sql_file, db_path)