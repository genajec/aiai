#!/usr/bin/env python
"""
Мониторинг состояния FaceForm бота для VPS
"""

import os
import sys
import time
import logging
import psutil
import json
import requests
import datetime
from dotenv import load_dotenv

# Загружаем переменные окружения из .env файла
load_dotenv()

# Получаем токен API из переменных окружения
TELEGRAM_API_TOKEN = os.environ.get("TELEGRAM_API_TOKEN")

# ID админов, которым будут отправляться уведомления
ADMIN_IDS = [int(os.environ.get("ADMIN_USER_ID", "0"))]  # Добавьте ID админов через запятую

# Настройки мониторинга
MONITORING_INTERVAL = 300  # Проверка каждые 5 минут
MEMORY_THRESHOLD = 90  # Предупреждение при использовании более 90% памяти
CPU_THRESHOLD = 80  # Предупреждение при использовании более 80% CPU
DISK_THRESHOLD = 90  # Предупреждение при заполнении более 90% диска

# Настройка логирования
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    handlers=[
        logging.StreamHandler(sys.stdout),
        logging.FileHandler('monitor.log')
    ]
)
logger = logging.getLogger(__name__)

def send_telegram_message(user_id, message, parse_mode='Markdown'):
    """Отправляет сообщение через Telegram API"""
    try:
        url = f"https://api.telegram.org/bot{TELEGRAM_API_TOKEN}/sendMessage"
        data = {
            "chat_id": user_id,
            "text": message,
            "parse_mode": parse_mode
        }
        response = requests.post(url, data=data)
        return response.json()
    except Exception as e:
        logger.error(f"Ошибка при отправке сообщения: {e}")
        return None

def check_bot_process():
    """Проверяет, запущен ли процесс бота"""
    bot_running = False
    
    for proc in psutil.process_iter(['pid', 'name', 'cmdline']):
        try:
            cmdline = ' '.join(proc.info['cmdline']) if proc.info['cmdline'] else ''
            if 'python' in proc.info['name'].lower() and 'run_vps.py' in cmdline:
                bot_running = True
                break
        except (psutil.NoSuchProcess, psutil.AccessDenied, psutil.ZombieProcess):
            continue
    
    return bot_running

def check_system_resources():
    """Проверяет системные ресурсы и возвращает информацию об их использовании"""
    # Использование CPU
    cpu_percent = psutil.cpu_percent(interval=1)
    
    # Использование памяти
    memory = psutil.virtual_memory()
    memory_percent = memory.percent
    
    # Использование диска
    disk = psutil.disk_usage('/')
    disk_percent = disk.percent
    
    # Время работы системы
    uptime = datetime.datetime.now() - datetime.datetime.fromtimestamp(psutil.boot_time())
    
    return {
        'cpu_percent': cpu_percent,
        'memory_percent': memory_percent,
        'disk_percent': disk_percent,
        'uptime': str(uptime).split('.')[0],  # Убираем миллисекунды
        'warnings': {
            'cpu': cpu_percent > CPU_THRESHOLD,
            'memory': memory_percent > MEMORY_THRESHOLD,
            'disk': disk_percent > DISK_THRESHOLD
        }
    }

def check_bot_status():
    """Проверяет статус Telegram API и бота"""
    try:
        # Проверяем API соединение
        url = f"https://api.telegram.org/bot{TELEGRAM_API_TOKEN}/getMe"
        response = requests.get(url)
        api_ok = response.status_code == 200
        
        # Проверяем запущен ли процесс бота
        bot_running = check_bot_process()
        
        return {
            'api_ok': api_ok,
            'bot_running': bot_running
        }
    except Exception as e:
        logger.error(f"Ошибка при проверке статуса бота: {e}")
        return {
            'api_ok': False,
            'bot_running': False,
            'error': str(e)
        }

def create_status_report():
    """Создает полный отчет о состоянии системы и бота"""
    resources = check_system_resources()
    bot_status = check_bot_status()
    
    # Формируем отчет
    report = [
        "*Отчет о состоянии FaceForm Bot*",
        f"📅 Дата: {datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S')}",
        f"⏱ Время работы системы: {resources['uptime']}",
        "",
        "*Статус бота:*",
        f"🤖 Процесс бота активен: {'✅' if bot_status['bot_running'] else '❌'}",
        f"🌐 Соединение с Telegram API: {'✅' if bot_status['api_ok'] else '❌'}",
        "",
        "*Системные ресурсы:*",
        f"💻 CPU: {resources['cpu_percent']}% {'⚠️' if resources['warnings']['cpu'] else ''}",
        f"🧠 Память: {resources['memory_percent']}% {'⚠️' if resources['warnings']['memory'] else ''}",
        f"💾 Диск: {resources['disk_percent']}% {'⚠️' if resources['warnings']['disk'] else ''}"
    ]
    
    # Добавляем предупреждения, если есть
    warnings = []
    if resources['warnings']['cpu']:
        warnings.append(f"⚠️ Высокая нагрузка на CPU: {resources['cpu_percent']}%")
    if resources['warnings']['memory']:
        warnings.append(f"⚠️ Высокое использование памяти: {resources['memory_percent']}%")
    if resources['warnings']['disk']:
        warnings.append(f"⚠️ Мало свободного места на диске: {resources['disk_percent']}%")
    if not bot_status['bot_running']:
        warnings.append("❗ Процесс бота не запущен!")
    if not bot_status['api_ok']:
        warnings.append("❗ Нет соединения с Telegram API!")
    
    if warnings:
        report.append("")
        report.append("*Предупреждения:*")
        report.extend(warnings)
    
    return "\n".join(report)

def main():
    """Основная функция мониторинга"""
    logger.info("Запуск мониторинга FaceForm Bot")
    
    # Проверяем наличие токена API
    if not TELEGRAM_API_TOKEN:
        logger.critical("TELEGRAM_API_TOKEN не найден в переменных окружения!")
        sys.exit(1)
    
    # Проверяем наличие ID админов
    if not ADMIN_IDS or ADMIN_IDS == [0]:
        logger.warning("ID админов не настроены. Уведомления не будут отправляться.")
    
    # Отправляем начальное сообщение
    for admin_id in ADMIN_IDS:
        if admin_id != 0:
            send_telegram_message(
                admin_id, 
                "*Система мониторинга FaceForm Bot запущена*\n\nВы будете получать уведомления о состоянии бота."
            )
    
    # Предыдущие предупреждения для отслеживания изменений
    previous_warnings = {
        'cpu': False,
        'memory': False,
        'disk': False,
        'bot_running': True,
        'api_ok': True
    }
    
    # Счетчик для отправки периодических отчетов
    report_counter = 0
    
    while True:
        try:
            logger.info("Проверка состояния системы и бота...")
            
            # Получаем данные о состоянии
            resources = check_system_resources()
            bot_status = check_bot_status()
            
            # Текущие предупреждения
            current_warnings = {
                'cpu': resources['warnings']['cpu'],
                'memory': resources['warnings']['memory'],
                'disk': resources['warnings']['disk'],
                'bot_running': bot_status['bot_running'],
                'api_ok': bot_status['api_ok']
            }
            
            # Проверяем изменения в предупреждениях
            warnings_changed = any(previous_warnings[key] != current_warnings[key] for key in previous_warnings)
            
            # Каждые 12 часов отправляем полный отчет (24 часа / 5 минут = 288 проверок)
            report_counter += 1
            send_full_report = report_counter >= 144  # 12 часов при интервале в 5 минут
            
            # Отправляем уведомления при изменениях или по расписанию
            if warnings_changed or send_full_report:
                report = create_status_report()
                
                for admin_id in ADMIN_IDS:
                    if admin_id != 0:
                        send_telegram_message(admin_id, report)
                
                # Сбрасываем счетчик после отправки полного отчета
                if send_full_report:
                    report_counter = 0
                
                # Обновляем предыдущие предупреждения
                previous_warnings = current_warnings.copy()
            
            # Логируем состояние
            log_message = (
                f"CPU: {resources['cpu_percent']}%, "
                f"Memory: {resources['memory_percent']}%, "
                f"Disk: {resources['disk_percent']}%, "
                f"Bot running: {bot_status['bot_running']}, "
                f"API OK: {bot_status['api_ok']}"
            )
            logger.info(log_message)
            
            # Ждем до следующей проверки
            time.sleep(MONITORING_INTERVAL)
            
        except Exception as e:
            logger.error(f"Ошибка в мониторинге: {e}")
            import traceback
            logger.error(traceback.format_exc())
            time.sleep(60)  # Ждем минуту перед повторной попыткой

if __name__ == "__main__":
    main()