#!/usr/bin/env python
"""
Видео анализатор формы лица - отдельный модуль
"""
import os
import argparse
import logging
from process_video_with_grid import process_video_with_grid

# Настройка логирования
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger(__name__)

def analyze_video(input_path, output_path=None, show_help_text=True):
    """
    Анализирует видео и добавляет на него сетку с анализом формы лица
    
    Args:
        input_path (str): Путь к входному видео
        output_path (str, optional): Путь для сохранения результата
        show_help_text (bool): Показывать ли справочный текст на видео
        
    Returns:
        str: Путь к обработанному видео
    """
    try:
        if not os.path.exists(input_path):
            raise FileNotFoundError(f"Не найдено входное видео: {input_path}")
        
        if not output_path:
            # Если путь не указан, сохраняем рядом с оригиналом
            base_name = os.path.basename(input_path)
            name, ext = os.path.splitext(base_name)
            output_path = os.path.join(os.path.dirname(input_path), f"{name}_processed{ext}")
        
        # Обрабатываем видео с помощью функции из process_video_with_grid
        result_path = process_video_with_grid(
            input_path,
            output_path,
            add_grid=True,
            draw_landmarks=True,
            show_text=show_help_text
        )
        
        logger.info(f"Видео успешно обработано и сохранено: {result_path}")
        return result_path
    
    except Exception as e:
        logger.error(f"Ошибка при обработке видео: {e}")
        return None

def main():
    # Парсер командной строки
    parser = argparse.ArgumentParser(description="Анализатор видео формы лица")
    parser.add_argument("input", help="Путь к входному видео")
    parser.add_argument("-o", "--output", help="Путь для сохранения результата")
    parser.add_argument("--no-text", action="store_true", help="Не добавлять справочный текст")
    
    args = parser.parse_args()
    
    # Запускаем анализ
    analyze_video(args.input, args.output, not args.no_text)

if __name__ == "__main__":
    main()