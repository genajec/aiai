# Руководство по установке FaceForm Bot и веб-сайта на VPS

## Шаг 1: Подготовка сервера

```bash
# Обновление системы
sudo apt update
sudo apt upgrade -y

# Установка необходимых пакетов
sudo apt install -y python3-pip python3-venv nginx supervisor git

# Установка библиотек для компьютерного зрения
sudo apt install -y ffmpeg libsm6 libxext6 libgl1-mesa-glx
```

## Шаг 2: Создание пользователя и настройка каталогов

```bash
# Создание пользователя (если требуется)
sudo adduser faceform

# Переключение на пользователя
sudo su - faceform

# Создание директорий
mkdir -p ~/faceform_bot
cd ~/faceform_bot
```

## Шаг 3: Копирование файлов проекта

Распакуйте архив проекта в директорию `~/faceform_bot`

```bash
# Распаковка архива (предположим, что архив называется faceform_bot.zip)
unzip /path/to/faceform_bot.zip -d ~/faceform_bot
cd ~/faceform_bot
```

## Шаг 4: Настройка виртуального окружения Python

```bash
# Создание виртуального окружения
python3 -m venv venv

# Активация виртуального окружения
source venv/bin/activate

# Установка зависимостей
pip install -r requirements.txt
```

## Шаг 5: Настройка переменных окружения

Файл `.env` уже создан и содержит необходимые ключи API и другие настройки. Убедитесь, что этот файл находится в корневой директории проекта. При необходимости отредактируйте его:

```bash
# Проверка наличия .env файла
ls -la .env

# При необходимости редактирования
nano .env
```

## Шаг 6: Настройка базы данных

По умолчанию проект использует SQLite. Если вы хотите использовать PostgreSQL, установите его и обновите `DATABASE_URL` в файле `.env`.

```bash
# Для SQLite ничего устанавливать не нужно
# Для PostgreSQL:
sudo apt install -y postgresql postgresql-contrib
sudo -u postgres psql

# В интерактивной оболочке PostgreSQL:
CREATE DATABASE faceform_bot;
CREATE USER faceform WITH PASSWORD 'ваш_пароль';
GRANT ALL PRIVILEGES ON DATABASE faceform_bot TO faceform;
\q

# И измените DATABASE_URL в .env:
# DATABASE_URL=postgresql://faceform:ваш_пароль@localhost/faceform_bot
```

## Шаг 7: Настройка Supervisor для автоматического запуска бота

Создайте файл конфигурации для Supervisor:

```bash
sudo nano /etc/supervisor/conf.d/faceform_bot.conf
```

Добавьте следующее содержимое (замените пути на соответствующие вашей системе):

```ini
[program:faceform_bot]
command=/home/faceform/faceform_bot/venv/bin/python /home/faceform/faceform_bot/main.py
directory=/home/faceform/faceform_bot
user=faceform
autostart=true
autorestart=true
stderr_logfile=/var/log/faceform_bot/stderr.log
stdout_logfile=/var/log/faceform_bot/stdout.log
environment=PATH="/home/faceform/faceform_bot/venv/bin"
```

Создайте директории для логов:

```bash
sudo mkdir -p /var/log/faceform_bot
sudo chown -R faceform:faceform /var/log/faceform_bot
```

Обновите конфигурацию Supervisor:

```bash
sudo supervisorctl reread
sudo supervisorctl update
sudo supervisorctl start faceform_bot
```

## Шаг 8: Настройка Nginx для веб-сайта

Создайте файл конфигурации для Nginx:

```bash
sudo nano /etc/nginx/sites-available/faceform_bot
```

Добавьте следующее содержимое (замените domain.com на ваш домен):

```nginx
server {
    listen 80;
    server_name domain.com www.domain.com;

    location / {
        proxy_pass http://127.0.0.1:5000;
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto $scheme;
    }

    location /static {
        alias /home/faceform/faceform_bot/static;
        expires 30d;
    }
}
```

Активируйте сайт и перезапустите Nginx:

```bash
sudo ln -s /etc/nginx/sites-available/faceform_bot /etc/nginx/sites-enabled/
sudo nginx -t
sudo systemctl restart nginx
```

## Шаг 9: Настройка SSL с помощью Certbot (необязательно, но рекомендуется)

```bash
sudo apt install -y certbot python3-certbot-nginx
sudo certbot --nginx -d domain.com -d www.domain.com
```

## Шаг 10: Настройка вебхуков для Telegram (если используются)

Если вы хотите использовать вебхуки вместо режима опроса (polling), вам потребуется настроить их:

```bash
# Активация виртуального окружения
cd ~/faceform_bot
source venv/bin/activate

# Создание скрипта для настройки вебхуков
cat > setup_webhook.py << EOF
import requests
import os
from dotenv import load_dotenv

# Загрузка переменных окружения
load_dotenv()

TOKEN = os.getenv('TELEGRAM_BOT_TOKEN')
DOMAIN = "domain.com"  # Замените на ваш домен

# URL для установки вебхука
url = f"https://api.telegram.org/bot{TOKEN}/setWebhook?url=https://{DOMAIN}/webhook/{TOKEN}"

# Отправка запроса
response = requests.get(url)
print(response.json())
EOF

# Запуск скрипта
python setup_webhook.py
```

## Шаг 11: Проверка работы

```bash
# Проверка статуса Supervisor
sudo supervisorctl status faceform_bot

# Проверка логов
tail -f /var/log/faceform_bot/stderr.log
tail -f /var/log/faceform_bot/stdout.log

# Проверка работы веб-сервера
curl http://localhost:5000
```

## Дополнительно: Настройка брандмауэра (необязательно)

```bash
sudo apt install -y ufw
sudo ufw allow 22/tcp
sudo ufw allow 80/tcp
sudo ufw allow 443/tcp
sudo ufw enable
```

## Важные замечания

1. **Безопасность**: Храните файл `.env` в безопасном месте и убедитесь, что он недоступен через веб-сервер.
2. **Резервное копирование**: Регулярно создавайте резервные копии базы данных и конфигурационных файлов.
3. **Мониторинг**: Настройте мониторинг для отслеживания работоспособности бота и веб-сайта.