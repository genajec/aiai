import os
import logging
import requests
import json
import hmac
import hashlib
from datetime import datetime

# Настраиваем логирование
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger(__name__)

class CryptoBotPayment:
    """Класс для работы с криптоплатежами через Crypto Bot API"""
    
    def __init__(self):
        """Инициализация объекта для работы с Crypto Bot"""
        self.token = os.environ.get("CRYPTO_BOT_TOKEN")
        
        if not self.token:
            logger.warning("Отсутствует токен Crypto Bot. Платежи будут работать в тестовом режиме.")
            # В тестовом режиме используем фиктивный токен
            self.token = "test_token"
        else:
            logger.info(f"Используется токен Crypto Bot: {self.token[:8]}...")
            
        # API endpoint - новый endpoint для использования Crypto Bot API 1.0
        self.api_url = "https://pay.crypt.bot/api"
        
        # Проверка формата токена и корректировка URL
        if self.token and isinstance(self.token, str) and ":" in self.token:
            # Токен имеет формат 'ID:TOKEN' для API 1.0
            logger.info("Используется API Crypto Bot 1.0")
        else:
            # Старый формат API 0.x
            self.api_url = "https://api.crypto.bot/api"
            logger.info("Используется старый API Crypto Bot (0.x)")
        
        # Тарифные планы для Crypto Bot (отличаются от Stripe)
        self.credit_packages = [
            {"id": "basic_crypto", "credits": 10, "price": 1.0, "description": "Базовый пакет: 10 кредитов"},
            {"id": "standard_crypto", "credits": 20, "price": 1.9, "description": "Стандартный пакет: 20 кредитов"},
            {"id": "premium_crypto", "credits": 50, "price": 4.0, "description": "Премиум пакет: 50 кредитов"}
        ]
    
    def get_credit_packages(self):
        """Получить доступные пакеты кредитов"""
        return self.credit_packages
        
    def create_payment(self, amount, package_id, telegram_id, title=None, description=None):
        """
        Создание счета в Crypto Bot
        
        Args:
            amount (float): Сумма платежа в долларах
            package_id (str): ID пакета кредитов
            telegram_id (int): Telegram ID пользователя
            title (str, optional): Заголовок счета
            description (str, optional): Описание счета
            
        Returns:
            dict: Информация о созданном счете или None в случае ошибки
        """
        try:
            # В тестовом режиме просто возвращаем тестовые данные
            if self.token == "test_token":
                test_invoice_id = f"TEST_INVOICE_{telegram_id}_{int(datetime.now().timestamp())}"
                logger.info(f"Тестовый режим: создан счет {test_invoice_id} для пользователя {telegram_id} на сумму {amount}$")
                return {
                    "invoice_id": test_invoice_id,
                    "status": "active",
                    "hash": f"test_hash_{test_invoice_id}",
                    "amount": amount,
                    "asset": "USDT",
                    "test_mode": True,
                    "payment_url": f"https://t.me/CryptoBot?start=test_{test_invoice_id}",
                    "pay_url": f"https://t.me/CryptoBot?start=test_{test_invoice_id}", # для совместимости со старым API
                    "payment_id": test_invoice_id # для совместимости с разными версиями кода
                }
            
            # Формируем заголовок и описание, если они не указаны
            if not title:
                title = f"Кредиты FaceForm Bot"
            
            if not description:
                description = f"Покупка пакета из {self.get_credits_by_package_id(package_id)} кредитов для использования премиум-функций FaceForm Bot"
            
            # Формируем параметры запроса в зависимости от версии API
            params = {}
            
            # Проверяем формат токена для определения версии API
            if isinstance(self.token, str) and ":" in self.token:  # API 1.0
                params = {
                    "amount": str(amount),  # Сумма должна быть строкой
                    "asset": "USDT",        # Используем USDT как валюту по умолчанию
                    "description": description,
                    "payload": f"package_id:{package_id},user_id:{telegram_id}",
                    "paid_btn_name": "openBot",  # Одно из предопределенных значений в API 1.0
                    "paid_btn_url": f"https://t.me/Faceform_bot?start=success_",  # URL будет дополнен ID инвойса после создания
                    "expires_in": 3600  # Счет действителен 1 час
                }
            else:  # Старый API 0.x
                params = {
                    "amount": str(amount),  # Сумма должна быть строкой
                    "asset": "USDT",        # Используем USDT как валюту по умолчанию
                    "accept_partial": False, # Не принимаем частичную оплату
                    "description": description,
                    "hidden_message": f"package_id:{package_id},user_id:{telegram_id}",
                    "paid_btn_name": "Вернуться в бот"  # После оплаты пользователь вернется в бот
                }
            
            logger.info(f"Параметры запроса на создание счета: {params}")
            
            # Отправляем запрос на создание счета
            try:
                response = requests.get(
                    f"{self.api_url}/createInvoice",
                    params=params,
                    headers={"Crypto-Pay-API-Token": self.token}
                )
                
                # Проверяем ответ сервера
                if response.status_code != 200:
                    logger.error(f"Ошибка HTTP при создании счета: {response.status_code} - {response.text}")
                    return None
                
                # Пытаемся разобрать JSON
                try:
                    response_data = response.json()
                except ValueError as e:
                    logger.error(f"Ошибка при разборе JSON: {e}. Текст ответа: {response.text}")
                    return None
                
                if not response_data.get("ok"):
                    logger.error(f"API вернул ошибку: {response_data}")
                    return None
                    
            except requests.exceptions.RequestException as e:
                logger.error(f"Ошибка сетевого запроса: {e}")
                return None
                
            # Получаем данные счета
            invoice = response_data.get("result", {})
            logger.info(f"Создан счет для пользователя {telegram_id} на сумму {amount}$: {invoice}")
            
            # Модифицируем URL для возврата, подставляя фактический ID инвойса
            if "pay_url" in invoice:
                invoice["payment_url"] = invoice["pay_url"]
                
            # Добавляем URL для возврата после успешной оплаты
            invoice_id = invoice.get("invoice_id", "")
            if invoice_id:
                invoice["success_return_url"] = f"https://t.me/Faceform_bot?start=success_{invoice_id}"
            
            # Добавляем метаданные для отслеживания пакета и пользователя
            invoice["package_id"] = package_id
            invoice["telegram_id"] = telegram_id
            invoice["payment_id"] = invoice.get("invoice_id")
            
            return invoice
            
        except Exception as e:
            logger.error(f"Ошибка при создании счета: {e}")
            return None
            
    def get_invoice(self, invoice_id):
        """
        Получение информации о счете
        
        Args:
            invoice_id (str): ID счета
            
        Returns:
            dict: Информация о счете или None в случае ошибки
        """
        try:
            # В тестовом режиме просто возвращаем тестовые данные
            if self.token == "test_token" or invoice_id.startswith("TEST_INVOICE_"):
                logger.info(f"Тестовый режим: получение информации о счете {invoice_id}")
                # Определяем пакет и кредиты по метаданным в invoice_id
                package_id = "basic_crypto"  # По умолчанию базовый пакет
                telegram_id = None
                
                # Если ID инвойса содержит метаданные в формате TEST_INVOICE_userid_timestamp
                if "_" in invoice_id:
                    parts = invoice_id.split("_")
                    if len(parts) >= 3:
                        telegram_id = parts[2]
                        
                # Находим пакет кредитов
                credits = 10  # По умолчанию для базового пакета
                amount = 1.0
                for pkg in self.credit_packages:
                    if pkg["id"] == package_id:
                        credits = pkg["credits"]
                        amount = pkg["price"]
                        break
                
                return {
                    "invoice_id": invoice_id,
                    "status": "paid",  # Всегда считаем счет оплаченным в тестовом режиме
                    "hash": f"test_hash_{invoice_id}",
                    "amount": amount,
                    "asset": "USDT",
                    "test_mode": True,
                    "package_id": package_id,
                    "telegram_id": telegram_id,
                    "credits": credits
                }
            
            # Отправляем запрос на получение информации о счете
            try:
                response = requests.get(
                    f"{self.api_url}/getInvoice",
                    params={"invoice_id": invoice_id},
                    headers={"Crypto-Pay-API-Token": self.token}
                )
                
                # Проверяем ответ сервера
                if response.status_code != 200:
                    logger.error(f"Ошибка HTTP при получении информации о счете: {response.status_code} - {response.text}")
                    return None
                
                # Пытаемся разобрать JSON
                try:
                    response_data = response.json()
                except ValueError as e:
                    logger.error(f"Ошибка при разборе JSON: {e}. Текст ответа: {response.text}")
                    return None
                
                if not response_data.get("ok"):
                    logger.error(f"API вернул ошибку: {response_data}")
                    return None
                    
            except requests.exceptions.RequestException as e:
                logger.error(f"Ошибка сетевого запроса: {e}")
                return None
                
            # Получаем данные счета
            invoice = response_data.get("result", {})
            logger.info(f"Получена информация о счете {invoice_id}: {invoice}")
            
            return invoice
            
        except Exception as e:
            logger.error(f"Ошибка при получении информации о счете: {e}")
            return None
            
    def check_payment_status(self, payment_id):
        """
        Проверка статуса платежа
        
        Args:
            payment_id (str): ID платежа (инвойса)
            
        Returns:
            str: Статус платежа ('active', 'paid', 'expired') или None в случае ошибки
        """
        try:
            # Лог для отладки
            logger.info(f"Проверка статуса платежа с ID: {payment_id}")
            
            # В тестовом режиме для определенных ID сразу возвращаем "ошибку"
            if self.token == "test_token" and payment_id and payment_id.startswith("TEST_ERROR_"):
                logger.info(f"Тестовый режим: симуляция ошибки платежа для {payment_id}")
                return "error"
                
            # Получаем информацию о счете
            invoice = self.get_invoice(payment_id)
            
            if not invoice:
                logger.error(f"Не удалось получить информацию об инвойсе {payment_id}")
                return "error"
                
            # Получаем статус счета
            status = invoice.get("status")
            logger.info(f"Статус платежа {payment_id}: {status}")
            
            # Проверка на известные статусы
            if status not in ["active", "paid", "expired"]:
                logger.warning(f"Неизвестный статус счета {payment_id}: {status}")
            
            return status
            
        except Exception as e:
            logger.error(f"Ошибка при проверке статуса счета: {e}")
            return "error"
            
    def get_credits_by_package_id(self, package_id):
        """
        Получает количество кредитов по ID пакета
        
        Args:
            package_id (str): ID пакета кредитов
            
        Returns:
            int: Количество кредитов или 0 если пакет не найден
        """
        for package in self.credit_packages:
            if package["id"] == package_id:
                return package["credits"]
                
        return 0
        
    def handle_payment_error(self, chat_id, error_code=None, error_message=None):
        """
        Обрабатывает ошибку платежа и отправляет соответствующее сообщение
        
        Args:
            chat_id (int): ID чата пользователя
            error_code (str, optional): Код ошибки
            error_message (str, optional): Сообщение об ошибке
            
        Returns:
            str: Сообщение об ошибке, которое было сформировано
        """
        # Логируем ошибку
        logger.error(f"Ошибка платежа для пользователя {chat_id}: {error_code} - {error_message}")
        
        # Базовое сообщение об ошибке
        base_message = "❌ Ошибка платежа ❌\n\nПроизошла ошибка при обработке платежа. "
        
        # Расширяем сообщение в зависимости от кода ошибки
        if error_code == "invalid_amount":
            message = base_message + "Некорректная сумма платежа."
        elif error_code == "expired":
            message = base_message + "Срок действия счета истек. Пожалуйста, создайте новый платеж."
        elif error_code == "canceled":
            message = base_message + "Платеж был отменен."
        else:
            message = base_message + "Пожалуйста, попробуйте позже или выберите другой способ оплаты."
            
        # Добавляем контактную информацию для поддержки
        message += "\n\nЕсли проблема повторяется, свяжитесь с поддержкой @FaceFormSupport."
        
        return message
        
    def get_payment_data(self, payment_id):
        """
        Получает полную информацию о платеже, включая метаданные о пакете и пользователе
        
        Args:
            payment_id (str): ID платежа (инвойса)
            
        Returns:
            dict: Данные о платеже или None в случае ошибки
        """
        try:
            # Получаем инвойс
            invoice = self.get_invoice(payment_id)
            if not invoice:
                logger.error(f"Не удалось получить инвойс {payment_id}")
                return None
                
            # Извлекаем метаданные из payload или hidden_message
            metadata = {}
            payload = invoice.get("payload", "")
            hidden_message = invoice.get("hidden_message", "")
            
            # Сначала пробуем payload (API 1.0)
            if payload:
                for item in payload.split(","):
                    if ":" in item:
                        key, value = item.split(":", 1)
                        metadata[key] = value
            
            # Если нет данных, пробуем hidden_message (API 0.x)
            elif hidden_message:
                for item in hidden_message.split(","):
                    if ":" in item:
                        key, value = item.split(":", 1)
                        metadata[key] = value
                        
            # Собираем полную информацию о платеже
            payment_data = {
                "invoice_id": payment_id,
                "status": invoice.get("status"),
                "amount": invoice.get("amount"),
                "asset": invoice.get("asset"),
                "created_at": invoice.get("created_at"),
                "package_id": metadata.get("package_id"),
                "telegram_id": None
            }
            
            # Если есть user_id в метаданных, преобразуем его в int
            user_id = metadata.get("user_id")
            if user_id:
                try:
                    payment_data["telegram_id"] = int(user_id)
                except (ValueError, TypeError):
                    logger.error(f"Не удалось преобразовать user_id '{user_id}' в число")
                    
            return payment_data
            
        except Exception as e:
            logger.error(f"Ошибка при получении данных платежа {payment_id}: {e}")
            return None
    
    def verify_webhook_signature(self, request_data, signature, init_vector=None):
        """
        Проверяет подпись веб-хука от Crypto Bot API 1.0
        
        Args:
            request_data (bytes): Данные запроса в формате bytes
            signature (str): Подпись из заголовка X-Crypto-Bot-Signature
            init_vector (str, optional): Вектор инициализации из заголовка X-Crypto-Bot-Signature-IV
            
        Returns:
            bool: True если подпись валидна, False если нет
        """
        try:
            # В тестовом режиме пропускаем проверку подписи
            if self.token == "test_token":
                logger.info("Тестовый режим: пропускаем проверку подписи веб-хука")
                return True
                
            # Проверяем, что токен имеет формат API 1.0
            if not isinstance(self.token, str) or ":" not in self.token:
                logger.error("Невозможно проверить подпись для старого формата API")
                return False
                
            # Получаем секретный ключ из токена
            api_token_parts = self.token.split(":")
            if len(api_token_parts) != 2:
                logger.error("Неверный формат токена для API 1.0")
                return False
                
            api_secret = api_token_parts[1]
            
            # Создаем HMAC с SHA-256
            hmac_obj = hmac.new(
                api_secret.encode('utf-8'),
                request_data,
                hashlib.sha256
            )
            
            # Получаем hex-дайджест
            calculated_signature = hmac_obj.hexdigest()
            
            # Сравниваем с переданной подписью
            is_valid = hmac.compare_digest(calculated_signature, signature)
            logger.info(f"Проверка подписи веб-хука: {'успешно' if is_valid else 'неверная подпись'}")
            
            return is_valid
            
        except Exception as e:
            logger.error(f"Ошибка при проверке подписи веб-хука: {e}")
            return False
    
    def parse_callback_data(self, callback_data):
        """
        Парсит данные колбэка при успешной оплате
        
        Args:
            callback_data (str): Данные колбэка
            
        Returns:
            dict: Данные о платеже или None в случае ошибки
        """
        try:
            logger.info(f"Получены данные колбэка: {callback_data}")
            
            # Возможны два формата данных:
            # 1. JSON строка для API 1.0: {"invoice_id": "INVOICE_ID", "status": "paid", "payload": "..."}
            # 2. Строка с префиксом для начального сообщения: "success_INVOICE_ID"
            
            invoice_id = None
            is_success_message = False
            
            # Проверяем, является ли входная строка JSON
            try:
                # Пробуем разобрать как JSON
                data = json.loads(callback_data)
                invoice_id = data.get("invoice_id")
                status = data.get("status")
                
                if not invoice_id or status != "paid":
                    logger.error(f"Некорректные данные колбэка JSON: {callback_data}")
                    return None
                    
            except json.JSONDecodeError:
                # Не JSON, проверяем формат "success_INVOICE_ID"
                if callback_data.startswith("success_"):
                    invoice_id = callback_data[8:]  # Удаляем префикс "success_"
                    is_success_message = True
                    logger.info(f"Обрабатывается успешное возвращение с ID счета: {invoice_id}")
                else:
                    logger.error(f"Неизвестный формат данных колбэка: {callback_data}")
                    return None
            
            # Получаем информацию о счете по ID
            invoice = self.get_invoice(invoice_id)
            
            if not invoice:
                logger.error(f"Не удалось получить информацию о счете {invoice_id}")
                return None
                
            # Для успешного возвращения нужно проверить статус счета
            if is_success_message and invoice.get("status") != "paid":
                logger.error(f"Счет {invoice_id} не оплачен: {invoice.get('status')}")
                return None
                
            # Извлекаем метаданные из скрытого сообщения или payload
            metadata = {}
            
            # Проверяем формат API 1.0 (payload)
            payload = invoice.get("payload", "")
            if payload:
                # Парсим payload формата "key1:value1,key2:value2"
                for item in payload.split(","):
                    if ":" in item:
                        key, value = item.split(":", 1)
                        metadata[key] = value
                logger.info(f"Извлечены метаданные из payload: {metadata}")
            
            # Проверяем формат API 0.x (hidden_message)
            hidden_message = invoice.get("hidden_message", "")
            if hidden_message and not metadata:  # Если payload не дал результатов
                # Парсим hidden_message формата "key1:value1,key2:value2"
                for item in hidden_message.split(","):
                    if ":" in item:
                        key, value = item.split(":", 1)
                        metadata[key] = value
                logger.info(f"Извлечены метаданные из hidden_message: {metadata}")
                
            # Если метаданные не найдены, используем сохраненные в инвойсе
            if not metadata:
                logger.warning("Метаданные не найдены в payload или hidden_message, используем сохраненные данные")
                # Получаем package_id и telegram_id из самого объекта invoice
                if "package_id" in invoice:
                    metadata["package_id"] = invoice.get("package_id")
                if "telegram_id" in invoice:
                    metadata["user_id"] = str(invoice.get("telegram_id"))
                        
            # Создаем базовую информацию о платеже
            payment_info = {
                "invoice_id": invoice_id,
                "status": "paid",
                "amount": invoice.get("amount"),
                "asset": invoice.get("asset"),
                "package_id": metadata.get("package_id"),
                "telegram_id": None
            }
            
            # Безопасно преобразуем telegram_id в int, если он есть
            user_id = metadata.get("user_id")
            if user_id:
                try:
                    payment_info["telegram_id"] = int(user_id)
                except (ValueError, TypeError):
                    logger.error(f"Не удалось преобразовать user_id '{user_id}' в число")
            
            logger.info(f"Успешно обработан платеж: {payment_info}")
            return payment_info
            
        except Exception as e:
            logger.error(f"Ошибка при парсинге данных колбэка: {e}")
            return None