"""
Тестирование функциональности отображения таймера при обработке видео
"""
import os
import time
import io
import logging
from process_video_adapter import process_video_with_grid_adapter

# Настройка логирования
logging.basicConfig(level=logging.INFO, 
                    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s')
logger = logging.getLogger(__name__)

def test_process_video_with_timer():
    """
    Тестирует обработку видео с отображением оставшегося времени
    """
    # Проверяем наличие тестового видео
    test_video_path = "test_face_video.mp4"
    if not os.path.exists(test_video_path):
        logger.error(f"Тестовое видео не найдено: {test_video_path}")
        return False
    
    logger.info(f"Найдено тестовое видео: {test_video_path}")
    
    # Загружаем тестовое видео
    with open(test_video_path, "rb") as video_file:
        video_data = video_file.read()
    
    logger.info(f"Загружено видео размером: {len(video_data)} байт")
    
    # Функция обратного вызова для отслеживания прогресса
    def progress_callback(percent, stage, remaining_time=None):
        time_info = ""
        if remaining_time is not None:
            time_info = f", осталось примерно {remaining_time} секунд"
        logger.info(f"Прогресс: {percent:.1f}%, этап: {stage}{time_info}")
    
    # Обрабатываем видео с помощью адаптера
    logger.info("Начинаем обработку видео...")
    start_time = time.time()
    
    try:
        processed_video, analysis_results = process_video_with_grid_adapter(
            video_data, 
            progress_callback=progress_callback,
            return_analysis=True
        )
        
        end_time = time.time()
        processing_time = round(end_time - start_time, 1)
        
        if processed_video:
            logger.info(f"Видео успешно обработано за {processing_time} секунд")
            
            # Сохраняем результат
            with open("test_video_with_timer_result.avi", "wb") as result_file:
                result_file.write(processed_video)
                
            logger.info("Результат сохранен в файл: test_video_with_timer_result.avi")
            
            # Выводим информацию о результатах анализа
            if analysis_results:
                logger.info(f"Форма лица: {analysis_results.get('face_shape', 'не определена')}")
                logger.info(f"Оставшееся время (финальное): {analysis_results.get('remaining_time', 'не определено')}")
                logger.info(f"Прошедшее время: {analysis_results.get('elapsed_time', 'не определено')} секунд")
                
            return True
        else:
            logger.error("Не удалось обработать видео")
            return False
    except Exception as e:
        logger.error(f"Ошибка при обработке видео: {e}")
        return False

if __name__ == "__main__":
    logger.info("Запуск тестирования таймера обработки видео...")
    success = test_process_video_with_timer()
    logger.info(f"Тестирование завершено {'успешно' if success else 'с ошибками'}")