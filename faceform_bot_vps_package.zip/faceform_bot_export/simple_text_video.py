import cv2
import numpy as np
import os
import random
from PIL import Image, ImageDraw, ImageFont
import tempfile
import logging

# Настройка логирования
logging.basicConfig(level=logging.INFO, 
                    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s')
logger = logging.getLogger(__name__)

def draw_text_with_pil(img, text, position, font_size=30, color=(0, 255, 0), bg_color=(0, 0, 0, 220), font_name=None):
    """
    Рисует текст с поддержкой кириллицы используя PIL
    
    Args:
        img: OpenCV изображение (в формате BGR)
        text: Текст для отображения (поддерживает кириллицу)
        position: Позиция (x, y) для отображения текста
        font_size: Размер шрифта
        color: Цвет текста в формате BGR
        bg_color: Цвет фона в формате BGRA (с прозрачностью)
        font_name: Название шрифта для использования (например, 'DejaVuSans-Bold')
        
    Returns:
        OpenCV изображение с добавленным текстом
    """
    # Конвертируем BGR в RGB для PIL
    img_rgb = cv2.cvtColor(img, cv2.COLOR_BGR2RGB)
    pil_img = Image.fromarray(img_rgb)
    
    # Создаем новый слой для текста
    txt_layer = Image.new('RGBA', pil_img.size, (0, 0, 0, 0))
    draw = ImageDraw.Draw(txt_layer)
    
    # Ищем доступный шрифт с поддержкой кириллицы
    font_file = None
    # Если указано имя шрифта, ищем его
    if font_name:
        font_directories = [
            '/usr/share/fonts/',
            '/usr/local/share/fonts/',
            '/usr/share/fonts/truetype/'
        ]
        
        for font_dir in font_directories:
            if os.path.exists(font_dir):
                for root, dirs, files in os.walk(font_dir):
                    ttf_files = [os.path.join(root, f) for f in files if f.endswith('.ttf')]
                    if ttf_files:
                        # Ищем указанный шрифт
                        for ttf in ttf_files:
                            if font_name in ttf:
                                font_file = ttf
                                logger.info(f"Подтверждено: шрифт {font_name} доступен в системе")
                                break
                        if font_file:
                            break
            if font_file:
                break
    
    # Если не нашли указанный шрифт или имя не указано, ищем DejaVuSans
    if not font_file:
        font_directories = [
            '/usr/share/fonts/',
            '/usr/local/share/fonts/',
            '/usr/share/fonts/truetype/'
        ]
        
        for font_dir in font_directories:
            if os.path.exists(font_dir):
                for root, dirs, files in os.walk(font_dir):
                    ttf_files = [os.path.join(root, f) for f in files if f.endswith('.ttf')]
                    if ttf_files:
                        logger.debug(f"Найдено {len(ttf_files)} .ttf файлов")
                        logger.debug(f"Первые 5 шрифтов: {ttf_files[:5]}")
                        # Ищем DejaVuSans, который хорошо поддерживает кириллицу
                        for ttf in ttf_files:
                            if 'DejaVuSans' in ttf:
                                font_file = ttf
                                logger.info(f"Подтверждено: шрифт DejaVuSans.ttf доступен в системе")
                                break
                        if font_file:
                            break
            if font_file:
                break
                
        if not font_file and 'ttf_files' in locals() and ttf_files:
            # Если не нашли DejaVuSans, используем первый доступный шрифт
            font_file = ttf_files[0]
        
    if not font_file:
        # Если вообще не нашли шрифты, используем шрифт по умолчанию
        logger.warning("Не найдены шрифты с поддержкой кириллицы, используем шрифт по умолчанию")
        try:
            # Попробуем использовать шрифт по умолчанию из PIL
            font = ImageFont.load_default()
        except Exception as e:
            logger.error(f"Не удалось загрузить шрифт по умолчанию: {e}")
            # Вернем исходное изображение если не удалось найти шрифт
            return img
    else:
        logger.info(f"Используется шрифт с поддержкой кириллицы: {font_file}")
        try:
            font = ImageFont.truetype(font_file, font_size)
        except Exception as e:
            logger.error(f"Ошибка загрузки шрифта {font_file}: {e}")
            # Попробуем использовать шрифт по умолчанию из PIL
            try:
                font = ImageFont.load_default()
            except:
                # Вернем исходное изображение если не удалось найти шрифт
                return img
    
    # Рассчитываем размеры текста
    bbox = draw.textbbox(position, text, font=font)
    text_width = bbox[2] - bbox[0]
    text_height = bbox[3] - bbox[1]
    
    logger.debug(f"Размер текста: {bbox}")
    
    # Рисуем фон если указан bg_color
    if bg_color:
        draw.rectangle(
            [position[0]-5, position[1]-5, position[0]+text_width+5, position[1]+text_height+5],
            fill=bg_color
        )
    
    # Конвертируем BGR в RGB для текста
    text_color = (color[2], color[1], color[0])
    
    # Рисуем текст
    draw.text(position, text, font=font, fill=text_color)
    
    # Накладываем слой текста на оригинальное изображение
    composite = Image.alpha_composite(pil_img.convert('RGBA'), txt_layer)
    result = np.array(composite.convert('RGB'))
    
    # Конвертируем обратно в BGR для OpenCV
    return cv2.cvtColor(result, cv2.COLOR_RGB2BGR)

def create_demo_video(output_path="demo_text_video.mp4", duration_sec=5, fps=30, width=1280, height=720):
    """
    Создает демо-видео с текстом внизу экрана и математическими символами для демонстрации.
    
    Args:
        output_path (str): Путь для сохранения выходного видео
        duration_sec (int): Длительность видео в секундах
        fps (int): Частота кадров в секунду
        width (int): Ширина видео
        height (int): Высота видео
    
    Returns:
        str: Путь к созданному видеофайлу или None в случае ошибки
    """
    # Рассчитываем количество кадров
    total_frames = fps * duration_sec
    
    # Создаем VideoWriter
    fourcc = cv2.VideoWriter_fourcc(*'XVID')
    out = cv2.VideoWriter(output_path, fourcc, fps, (width, height))
    
    if not out.isOpened():
        logger.error(f"Не удалось создать выходной файл: {output_path}")
        return None
    
    logger.info(f"Создаем видео с {total_frames} кадрами, длительностью {duration_sec} секунд")
    
    # Список доступных форм лица для демонстрации
    face_shapes = ["ОВАЛЬНАЯ", "КРУГЛАЯ", "КВАДРАТНАЯ", "СЕРДЦЕВИДНАЯ", "ПРОДОЛГОВАТАЯ", "РОМБОВИДНАЯ"]
    
    # Реальные данные для анализа формы лица
    face_analysis_data = {
        "ОВАЛЬНАЯ": [
            "Симметрия: 94%",
            "Золотое сечение: 1.618",
            "Пропорция челюсти: 0.82",
            "S = π × A × B (площадь)"
        ],
        "КРУГЛАЯ": [
            "Симметрия: 92%",
            "Периметр/площадь: 0.88",
            "Угол подбородка: 165°",
            "Ширина ≈ Высота"
        ],
        "КВАДРАТНАЯ": [
            "Угол челюсти: 87°",
            "Квадратичность: 89%",
            "Соотношение сторон 1:1.1",
            "Cθ = frac(n+1)×(n+2)"
        ],
        "СЕРДЦЕВИДНАЯ": [
            "Подбородок: 15% площади",
            "Угол сужения: 56°",
            "Расширение лба: 119%",
            "S/Ч = 1.33 (4:3)"
        ],
        "ПРОДОЛГОВАТАЯ": [
            "Вертикальная доминанта",
            "Длина > ширины × 1.5",
            "Золотое сечение: 1.62",
            "Форм-фактор: 0.65"
        ],
        "РОМБОВИДНАЯ": [
            "Выраженные скулы: 120%",
            "Угол Cθ = 55°±4°",
            "Диагональное соотношение",
            "S = D₁×D₂/2 (площадь)"
        ]
    }
    
    # Создаем кадры
    for frame_num in range(total_frames):
        if frame_num % 15 == 0:
            logger.info(f"Создание видео: {frame_num}/{total_frames} кадров ({frame_num*100/total_frames:.1f}%)")
        
        # Создаем пустой кадр с темным фоном
        frame = np.zeros((height, width, 3), dtype=np.uint8)
        frame[:] = (25, 25, 25)  # Темно-серый фон
        
        # Добавляем индикатор номера кадра
        frame_indicator = f"Frame: {frame_num+1}/{total_frames}"
        cv2.putText(frame, frame_indicator, (10, 30), cv2.FONT_HERSHEY_SIMPLEX, 0.7, (200, 200, 200), 2)
        
        # Добавляем зеленый индикатор в правом верхнем углу
        cv2.rectangle(frame, (width-30, 10), (width-10, 30), (0, 255, 0), -1)
        
        # ------------ ВЕРХНИЙ БЛОК ТЕКСТА ------------
        # Выбираем форму лица на основе номера кадра
        shape_idx = frame_num % len(face_shapes)
        current_shape = face_shapes[shape_idx]
        
        # Генерируем демо-значения метрик
        width_ratio = 0.7 + random.random() * 0.3
        forehead_ratio = 0.9 + random.random() * 0.4
        cheekbone_ratio = 1.1 + random.random() * 0.4
        
        # Создаем зеленую полоску для формы лица сверху
        top_shape_width = 230
        top_shape_height = 25
        top_shape_left = 10
        top_shape_top = 80
        cv2.rectangle(frame,
                      (top_shape_left, top_shape_top),
                      (top_shape_left + top_shape_width, top_shape_top + top_shape_height),
                      (0, 100, 0), -1)  # Темно-зеленый фон
        
        # Добавляем текст с формой лица
        frame = draw_text_with_pil(
            frame,
            f"Форма лица: {current_shape}",
            (top_shape_left + 5, top_shape_top + 2),
            font_size=18,
            color=(0, 255, 0),  # Ярко-зеленый текст
            bg_color=None  # Без фона
        )
        
        # Создаем черную полоску с метриками под зеленой полоской
        metrics_bar_top = top_shape_top + top_shape_height
        metrics_bar_height = 25
        cv2.rectangle(frame,
                     (top_shape_left, metrics_bar_top),
                     (top_shape_left + top_shape_width, metrics_bar_top + metrics_bar_height),
                     (0, 0, 0), -1)  # Черный фон
        
        # Добавляем метрики
        frame = draw_text_with_pil(
            frame,
            f"Ш/Д: {width_ratio:.2f}, Л/Ч: {forehead_ratio:.2f}, С/Ч: {cheekbone_ratio:.2f}",
            (top_shape_left + 5, metrics_bar_top + 3),
            font_size=16,
            color=(0, 255, 0),  # Зеленый текст
            bg_color=None  # Без фона
        )
        
        # ------------ ИНТЕРАКТИВНЫЕ ДАННЫЕ АНАЛИЗА ЛИЦА В ЛЕВОМ НИЖНЕМ УГЛУ ------------
        # Показываем данные анализа реже для создания эффекта медленной смены информации
        if frame_num % 15 < 12:  # Показываем на 12 из 15 кадров (более долго остаются на экране)
            # Получаем метрики для текущей формы лица
            face_metrics = face_analysis_data[current_shape]
            
            # Меняем метрику только через определенное количество кадров для более долгого отображения
            # Используем большее значение для более медленной смены
            metric_idx = (frame_num // 30) % len(face_metrics)
            metric = face_metrics[metric_idx]
            
            # Перемещаем формулы в левый нижний угол согласно требованиям пользователя
            pos_x = 30  # Левая сторона экрана
            pos_y = height - 120  # Немного выше нижнего текстового блока
            
            # Полупрозрачный фон для формул (более темный для контраста)
            overlay = frame.copy()
            cv2.rectangle(overlay,
                         (pos_x - 5, pos_y - 20),
                         (pos_x + len(metric) * 8 + 5, pos_y + 5),
                         (0, 0, 0), -1)
            cv2.addWeighted(overlay, 0.7, frame, 0.3, 0, frame)
            
            # Рисуем математическую формулу с желаемым форматированием
            frame = draw_text_with_pil(
                frame,
                metric,
                (pos_x, pos_y - 18),
                font_size=16,  # Компактный размер шрифта
                color=(0, 255, 0),  # Ярко-зеленый как на референсных фото
                bg_color=None  # Без фона
            )
        
        # ------------ НИЖНИЙ ТЕКСТ ------------
        # Создаем нижний текстовый блок
        bottom_text_height = 60
        bottom_text_y = height - bottom_text_height - 10
        
        # Полупрозрачный черный фон
        overlay = frame.copy()
        cv2.rectangle(overlay,
                     (0, bottom_text_y),
                     (width, bottom_text_y + bottom_text_height),
                     (0, 0, 0), -1)
        cv2.addWeighted(overlay, 0.7, frame, 0.3, 0, frame)
        
        # Добавляем текст с информацией о форме лица
        descriptions = {
            "ОВАЛЬНАЯ": "Идеальная форма с балансом пропорций",
            "КРУГЛАЯ": "Мягкие линии и равные пропорции",
            "КВАДРАТНАЯ": "Выраженные углы и сильная челюсть",
            "СЕРДЦЕВИДНАЯ": "Широкий лоб и суженный подбородок",
            "ПРОДОЛГОВАТАЯ": "Вытянутое лицо с высоким лбом",
            "РОМБОВИДНАЯ": "Выраженные скулы и узкий лоб/подбородок"
        }
        
        description = descriptions[current_shape]
        
        # Добавляем заголовок внизу экрана, изменили на использование DejaVuSans-Bold или эквивалент
        frame = draw_text_with_pil(
            frame,
            f"{current_shape} форма лица",
            (20, bottom_text_y + 10),
            font_size=22,
            color=(255, 255, 255),  # Белый текст для заголовка
            bg_color=None,  # Без фона
            font_name="DejaVuSans-Bold"  # Жирный шрифт для заголовка
        )
        
        # Добавляем описание формы лица
        frame = draw_text_with_pil(
            frame,
            description,
            (20, bottom_text_y + 40),
            font_size=18,
            color=(0, 255, 0),  # Зеленый текст
            bg_color=None  # Без фона
        )
        
        # Записываем кадр
        out.write(frame)
    
    # Освобождаем ресурсы
    out.release()
    
    logger.info(f"Демо-видео успешно создано: {output_path}")
    logger.info(f"Размер видео: {os.path.getsize(output_path) / (1024 * 1024):.2f} MB")
    
    return output_path

if __name__ == "__main__":
    # Сокращаем время создания видео для быстрого тестирования
    video_path = create_demo_video(duration_sec=2, fps=15)
    if video_path:
        print(f"Видео создано успешно: {video_path}")
        
        # Извлекаем несколько кадров для проверки
        cap = cv2.VideoCapture(video_path)
        if not cap.isOpened():
            print("Ошибка при открытии видео для извлечения кадров")
            exit(1)
            
        # Создаем директорию для кадров
        os.makedirs("frames", exist_ok=True)
        
        # Количество кадров для извлечения
        num_frames = 5
        fps = int(cap.get(cv2.CAP_PROP_FPS))
        total_frames = int(cap.get(cv2.CAP_PROP_FRAME_COUNT))
        
        # Определяем кадры для извлечения
        frame_positions = [int(i * total_frames / num_frames) for i in range(num_frames)]
        
        print(f"Извлекаем {num_frames} кадров из позиций: {frame_positions}")
        
        for i, pos in enumerate(frame_positions):
            cap.set(cv2.CAP_PROP_POS_FRAMES, pos)
            ret, frame = cap.read()
            if ret:
                frame_path = f"frames/frame_{i+1:03d}.jpg"
                cv2.imwrite(frame_path, frame)
                print(f"Сохранен кадр {pos} как {frame_path}")
        
        cap.release()
        print(f"Извлечено {num_frames} кадров в директорию frames")
    else:
        print("Ошибка при создании видео")