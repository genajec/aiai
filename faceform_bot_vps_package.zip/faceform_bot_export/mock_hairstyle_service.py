import os
import logging
import base64
import cv2
import numpy as np
from io import BytesIO
from PIL import Image

# Configure logging
logging.basicConfig(level=logging.INFO, 
                   format='%(asctime)s - %(name)s - %(levelname)s - %(message)s')
logger = logging.getLogger(__name__)

class MockHairstyleService:
    """Mock service for hairstyle try-on when PerfectCorp API is not available"""
    
    def __init__(self):
        """Initialize the mock service"""
        logger.info("Initializing mock hairstyle service")
        self.hairstyles = self._mock_hairstyle_data()
        
    def _mock_hairstyle_data(self):
        """Create mock hairstyle data for testing"""
        mock_data = {
            "OVAL": [
                {"id": "oval_1", "name": "Классическое каре"},
                {"id": "oval_2", "name": "Удлиненный боб"},
                {"id": "oval_3", "name": "Многослойная стрижка"}
            ],
            "ROUND": [
                {"id": "round_1", "name": "Асимметричная стрижка"},
                {"id": "round_2", "name": "Многослойная средняя длина"},
                {"id": "round_3", "name": "Длинная косая челка"}
            ],
            "SQUARE": [
                {"id": "square_1", "name": "Мягкие волны"},
                {"id": "square_2", "name": "Многослойная с объемом"},
                {"id": "square_3", "name": "Асимметричный боб"}
            ],
            "HEART": [
                {"id": "heart_1", "name": "Средняя длина с градуировкой"},
                {"id": "heart_2", "name": "Длинное каре с боковым пробором"},
                {"id": "heart_3", "name": "Челка на бок"}
            ],
            "OBLONG": [
                {"id": "oblong_1", "name": "Объемные кудри по бокам"},
                {"id": "oblong_2", "name": "Волнистые волосы средней длины"},
                {"id": "oblong_3", "name": "Прямая челка"}
            ],
            "DIAMOND": [
                {"id": "diamond_1", "name": "Глубокий боковой пробор"},
                {"id": "diamond_2", "name": "Стрижка с челкой"},
                {"id": "diamond_3", "name": "Многослойная средняя длина"}
            ]
        }
        return mock_data
        
    def get_all_hairstyles(self):
        """Get all available hairstyles"""
        all_hairstyles = []
        for shape, styles in self.hairstyles.items():
            all_hairstyles.extend(styles)
        return all_hairstyles
        
    def get_hairstyles_by_face_shape(self, face_shape):
        """
        Get hairstyles for a specific face shape
        
        Args:
            face_shape (str): Face shape (OVAL, ROUND, etc.)
            
        Returns:
            list: List of hairstyle dictionaries
        """
        if face_shape not in self.hairstyles:
            logger.warning(f"Face shape {face_shape} not found, using OVAL")
            face_shape = "OVAL"
            
        return self.hairstyles[face_shape]
        
    def apply_mock_hairstyle(self, image_data, face_shape, hairstyle_index=0):
        """
        Apply a mock hairstyle to an image
        
        Args:
            image_data (bytes): Original image data
            face_shape (str): Face shape 
            hairstyle_index (int): Index of hairstyle to apply
            
        Returns:
            bytes: Image with text overlay showing mock hairstyle
        """
        try:
            # Convert image bytes to numpy array
            nparr = np.frombuffer(image_data, np.uint8)
            image = cv2.imdecode(nparr, cv2.IMREAD_COLOR)
            
            # Get hairstyles for this face shape
            hairstyles = self.get_hairstyles_by_face_shape(face_shape)
            
            # Make sure index is valid
            if hairstyle_index >= len(hairstyles):
                hairstyle_index = 0
                
            # Get selected hairstyle
            hairstyle = hairstyles[hairstyle_index]
            
            # Add text to the image showing the hairstyle name
            result_image = image.copy()
            
            # Add a semi-transparent overlay showing hairstyle name
            overlay = result_image.copy()
            cv2.rectangle(overlay, (0, 0), (result_image.shape[1], 60), (0, 0, 0), -1)
            cv2.addWeighted(overlay, 0.7, result_image, 0.3, 0, result_image)
            
            # Add text
            cv2.putText(
                result_image,
                f"Демо: {hairstyle['name']}",
                (20, 40),
                cv2.FONT_HERSHEY_SIMPLEX,
                1,
                (255, 255, 255),
                2
            )
            
            # Filter image to simulate hairstyle effect
            # Apply a mild color filter based on face shape
            filter_colors = {
                "OVAL": (1.1, 1.0, 1.0),  # Slightly red
                "ROUND": (1.0, 1.1, 1.0),  # Slightly green
                "SQUARE": (1.0, 1.0, 1.1),  # Slightly blue
                "HEART": (1.1, 1.1, 1.0),  # Yellow-ish
                "OBLONG": (1.0, 1.1, 1.1),  # Cyan-ish
                "DIAMOND": (1.1, 1.0, 1.1)  # Purple-ish
            }
            
            filter_color = filter_colors.get(face_shape, (1.0, 1.0, 1.0))
            
            # Apply color adjustment
            for i in range(3):  # RGB channels
                result_image[:, :, i] = np.clip(result_image[:, :, i] * filter_color[i], 0, 255)
            
            # Encode the result image
            _, buffer = cv2.imencode('.jpg', result_image)
            return buffer.tobytes()
            
        except Exception as e:
            logger.error(f"Error applying mock hairstyle: {e}")
            return image_data