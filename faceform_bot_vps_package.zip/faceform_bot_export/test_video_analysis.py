#!/usr/bin/env python3
"""
Скрипт для тестирования функции анализа видео с возвратом расширенной аналитики
"""

import sys
import os
import logging
import time
import json
from process_video_with_grid import process_video_with_grid

# Настройка логирования
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger(__name__)

def test_video_analysis():
    """Тестирует функцию анализа видео с возвратом расширенной аналитики"""
    
    # Проверяем наличие тестового видео
    test_video_path = "test_face_video.mp4"
    if not os.path.exists(test_video_path):
        logger.error(f"Тестовое видео не найдено: {test_video_path}")
        logger.info("Используйте create_test_video.py для создания тестового видео")
        return False
    
    # Прогресс-функция для вывода в консоль
    def update_progress(percent, stage):
        logger.info(f"Прогресс: {percent}% - {stage}")
    
    # Загружаем видео
    with open(test_video_path, "rb") as video_file:
        video_data = video_file.read()
    
    logger.info(f"Загружено видео размером {len(video_data) / 1024:.1f} КБ")
    
    # Обрабатываем видео с возвратом аналитики
    start_time = time.time()
    
    # Вызываем функцию обработки с параметром return_analysis=True
    result = process_video_with_grid(
        video_data, 
        progress_callback=update_progress, 
        return_analysis=True
    )
    
    processing_time = time.time() - start_time
    
    # Проверяем результат
    if isinstance(result, tuple) and len(result) == 2:
        processed_video, analysis_data = result
        logger.info(f"Получен обработанный видеофайл размером {len(processed_video) / 1024:.1f} КБ")
        logger.info(f"Получены данные анализа: {len(str(analysis_data))} байт")
        
        # Сохраняем обработанное видео
        output_path = "test_processed_video.avi"
        with open(output_path, "wb") as out_file:
            out_file.write(processed_video)
        logger.info(f"Обработанное видео сохранено в {output_path}")
        
        # Сохраняем данные анализа в JSON
        json_path = "test_analysis_data.json"
        with open(json_path, "w", encoding="utf-8") as json_file:
            json.dump(analysis_data, json_file, indent=2, ensure_ascii=False)
        logger.info(f"Данные анализа сохранены в {json_path}")
        
        # Выводим ключевые результаты анализа
        print("\n=== РЕЗУЛЬТАТЫ АНАЛИЗА ВИДЕО ===")
        print(f"Форма лица: {analysis_data.get('face_shape', 'не определена')}")
        print(f"Соотношение ширины/длины: {analysis_data.get('width_ratio', 0):.2f}")
        print(f"Соотношение лоб/челюсть: {analysis_data.get('forehead_ratio', 0):.2f}")
        print(f"Соотношение скулы/челюсть: {analysis_data.get('cheekbone_ratio', 0):.2f}")
        print(f"Вертикальная асимметрия: {analysis_data.get('vertical_asymmetry', 0)*100:.1f}%")
        print(f"Горизонтальная асимметрия: {analysis_data.get('horizontal_asymmetry', 0)*100:.1f}%")
        print(f"Наиболее вероятный возрастной диапазон: {analysis_data.get('most_common_age_range', 'не определен')}")
        print(f"Средний возраст: {analysis_data.get('average_age', 0):.1f}")
        print(f"Проанализировано кадров: {analysis_data.get('frames_analyzed', 0)}")
        print(f"Кадров с обнаруженным лицом: {analysis_data.get('frames_with_face', 0)}")
        print(f"Время обработки: {processing_time:.1f} сек")
        
        return True
    else:
        logger.error("Функция process_video_with_grid не вернула ожидаемый результат")
        logger.error(f"Тип результата: {type(result)}")
        if isinstance(result, tuple):
            logger.error(f"Длина результата: {len(result)}")
        return False

if __name__ == "__main__":
    success = test_video_analysis()
    sys.exit(0 if success else 1)