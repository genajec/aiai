#!/usr/bin/env python3
"""
Скрипт для интеграции LightX API в существующего бота
"""

import os
import sys
import logging
from lightx_api import LightXAPI
from lightx_bot_integration import LightXBotIntegration

# Настраиваем логирование
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(name)s - %(levelname)s - %(message)s')
logger = logging.getLogger(__name__)

def integrate_lightx_to_bot(bot_instance=None, user_data=None):
    """
    Интегрирует функциональность LightX API в существующего бота
    
    Args:
        bot_instance: Экземпляр бота (если None, будет создан новый)
        user_data: Хранилище данных пользователей
        
    Returns:
        LightXBotIntegration: Интеграция с LightX API
    """
    try:
        # Проверяем наличие бота
        if bot_instance is None:
            # Импортируем модуль бота
            try:
                from bot import FaceShapeBot
                import telebot
                from config import BOT_TOKEN
                
                # Создаем экземпляр бота
                bot_instance = telebot.TeleBot(BOT_TOKEN)
                logger.info("Создан новый экземпляр бота")
            except ImportError:
                logger.error("Не удалось импортировать модуль бота")
                return None
        
        # Проверяем наличие API-ключа
        if not os.environ.get("LIGHTX_API_KEY"):
            logger.warning("API-ключ LightX не найден в переменных окружения")
            logger.info("Функциональность может быть ограничена")
        
        # Создаем интеграцию
        integration = LightXBotIntegration(bot_instance, user_data)
        logger.info("Интеграция с LightX API успешно создана")
        
        return integration
        
    except Exception as e:
        logger.error(f"Ошибка при интеграции LightX API: {str(e)}")
        return None

def patch_faceform_bot():
    """
    Модифицирует существующего бота FaceForm для интеграции с LightX API
    """
    try:
        # Импортируем необходимые модули
        from bot import FaceShapeBot
        import telebot
        from config import BOT_TOKEN
        
        # Загружаем оригинальный код бота
        with open('bot.py', 'r') as f:
            original_code = f.read()
        
        # Проверяем, уже интегрирован ли LightX API
        if 'from lightx_api import LightXAPI' in original_code:
            logger.info("LightX API уже интегрирован в бота")
            return True
        
        # Создаем резервную копию
        with open('bot.py.backup', 'w') as f:
            f.write(original_code)
        logger.info("Создана резервная копия bot.py.backup")
        
        # Добавляем импорт LightX API
        import_index = original_code.find('class FaceShapeBot:')
        if import_index == -1:
            logger.error("Не удалось найти определение класса FaceShapeBot")
            return False
        
        modified_code = original_code[:import_index] + 'from lightx_api import LightXAPI\n\n' + original_code[import_index:]
        
        # Добавляем инициализацию LightX API в __init__
        init_pattern = 'def __init__(self, use_webhook=False):'
        init_index = modified_code.find(init_pattern)
        if init_index == -1:
            logger.error("Не удалось найти метод __init__")
            return False
        
        # Находим конец метода recommender = HairstyleRecommender()
        recommender_pattern = 'self.recommender = HairstyleRecommender()'
        recommender_index = modified_code.find(recommender_pattern, init_index)
        if recommender_index == -1:
            logger.error("Не удалось найти инициализацию HairstyleRecommender")
            return False
        
        # Добавляем инициализацию LightX API
        insert_index = recommender_index + len(recommender_pattern)
        modified_code = modified_code[:insert_index] + '\n        self.lightx_api = LightXAPI()' + modified_code[insert_index:]
        
        # Добавляем метод ai_style_command
        method_before = 'def reset_command(self, message):'
        method_index = modified_code.find(method_before)
        if method_index == -1:
            logger.error("Не удалось найти метод reset_command")
            return False
        
        ai_style_method = """
    def ai_style_command(self, message):
        """Обработка команды /aistyle для AI-подбора прически с LightX API"""
        user_id = message.from_user.id
        
        # Проверяем, есть ли у пользователя загруженное фото
        if user_id not in self.user_data or 'image_data' not in self.user_data[user_id]:
            self.bot.send_message(user_id, "Пожалуйста, сначала загрузите фотографию.")
            return
        
        # Проверяем, доступен ли LightX API
        if not self.lightx_api.is_available():
            self.bot.send_message(
                user_id, 
                "Функция AI-подбора прически временно недоступна. "
                "Попробуйте позже или свяжитесь с администратором."
            )
            return
        
        # Получаем доступные стили причесок
        styles = self.lightx_api.get_available_styles()
        
        # Создаем клавиатуру с вариантами причесок
        markup = telebot.types.InlineKeyboardMarkup(row_width=2)
        buttons = []
        
        for i, style in enumerate(styles):
            # Добавляем кнопки для каждого стиля
            button_text = style
            callback_data = f"lightx_style_{i}"
            buttons.append(telebot.types.InlineKeyboardButton(button_text, callback_data=callback_data))
        
        # Добавляем кнопки в разметку
        markup.add(*buttons)
        
        # Отправляем сообщение с выбором прически
        self.bot.send_message(
            user_id,
            "Выберите стиль прически для AI-генерации:",
            reply_markup=markup
        )
        
        # Регистрируем обработчик callback-запросов для выбора стиля
        @self.bot.callback_query_handler(func=lambda call: call.data.startswith('lightx_style_'))
        def handle_lightx_style_selection(call):
            try:
                # Извлекаем индекс выбранного стиля из callback_data
                style_index = int(call.data.split('_')[-1])
                selected_style = styles[style_index]
                
                # Отправляем сообщение о начале обработки
                processing_message = self.bot.send_message(
                    call.message.chat.id,
                    f"Применяем стиль '{selected_style}'...\nЭто может занять до 30 секунд."
                )
                
                # Применяем выбранный стиль к изображению
                user_id = call.from_user.id
                image_data = self.user_data[user_id]['image_data']
                
                # Используем LightX API для генерации прически
                result_image = self.lightx_api.apply_hairstyle_with_retry(
                    image_data, selected_style
                )
                
                if result_image:
                    # Отправляем результат
                    self.bot.send_photo(
                        call.message.chat.id,
                        result_image,
                        caption=f"Результат AI-стилизации: {selected_style}"
                    )
                else:
                    # Отправляем сообщение об ошибке
                    self.bot.send_message(
                        call.message.chat.id,
                        "К сожалению, не удалось применить выбранный стиль. Пожалуйста, попробуйте другой стиль или другое фото."
                    )
                
                # Удаляем сообщение о процессе обработки
                try:
                    self.bot.delete_message(call.message.chat.id, processing_message.message_id)
                except Exception as e:
                    pass
                
            except Exception as e:
                self.bot.send_message(
                    call.message.chat.id,
                    f"Произошла ошибка при обработке стиля: {str(e)}"
                )
                
"""
        
        modified_code = modified_code[:method_index] + ai_style_method + modified_code[method_index:]
        
        # Добавляем регистрацию команды /aistyle
        command_pattern = '# Регистрация обработчиков команд и сообщений'
        command_index = modified_code.find(command_pattern)
        if command_index == -1:
            logger.error("Не удалось найти раздел регистрации команд")
            return False
        
        # Находим обработчик команды /hairstyles
        handler_pattern = '@command_handler(["hairstyles"])'
        handler_index = modified_code.find(handler_pattern, command_index)
        if handler_index == -1:
            logger.error("Не удалось найти обработчик команды /hairstyles")
            return False
        
        # Находим конец этого обработчика
        handler_end = modified_code.find('\n', handler_index + len(handler_pattern))
        if handler_end == -1:
            logger.error("Не удалось найти конец обработчика команды /hairstyles")
            return False
        
        # Добавляем обработчик команды /aistyle
        aistyle_handler = """
        @command_handler(["aistyle"])
        def handle_aistyle(message):
            self.ai_style_command(message)
"""
        
        modified_code = modified_code[:handler_end + 1] + aistyle_handler + modified_code[handler_end + 1:]
        
        # Добавляем команду /aistyle в справку
        help_pattern = 'def help_command(self, message):'
        help_index = modified_code.find(help_pattern)
        if help_index == -1:
            logger.error("Не удалось найти метод help_command")
            return False
        
        help_text_pattern = 'text += "\\n/reset - Сбросить все данные и начать снова"'
        help_text_index = modified_code.find(help_text_pattern, help_index)
        if help_text_index == -1:
            logger.error("Не удалось найти текст помощи")
            return False
        
        # Добавляем команду /aistyle в текст помощи
        help_end = help_text_index + len(help_text_pattern)
        aistyle_help = '\n        text += "\\n/aistyle - AI-подбор прически"'
        modified_code = modified_code[:help_end] + aistyle_help + modified_code[help_end:]
        
        # Записываем модифицированный код
        with open('bot.py', 'w') as f:
            f.write(modified_code)
        
        logger.info("LightX API успешно интегрирован в бота")
        return True
        
    except Exception as e:
        logger.error(f"Ошибка при патче бота: {str(e)}")
        return False

def main():
    """
    Основная функция
    """
    # Патчим бота
    if patch_faceform_bot():
        logger.info("Интеграция успешно выполнена")
    else:
        logger.error("Не удалось выполнить интеграцию")

if __name__ == "__main__":
    main()