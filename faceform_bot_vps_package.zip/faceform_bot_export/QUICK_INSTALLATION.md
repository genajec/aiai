# Быстрая установка FaceForm Bot на VPS

## Шаг 1: Подготовка сервера

```bash
# Обновление системы
sudo apt update
sudo apt upgrade -y

# Установка необходимых пакетов
sudo apt install -y python3-pip python3-venv nginx supervisor git

# Установка библиотек для компьютерного зрения
sudo apt install -y ffmpeg libsm6 libxext6 libgl1-mesa-glx
```

## Шаг 2: Подготовка файлов проекта

```bash
# Создание директорий
sudo mkdir -p /home/faceform/faceform_bot
sudo chown -R $USER:$USER /home/faceform

# Распаковка архива
unzip faceform_bot_vps_package.zip
cp -r faceform_bot_export/* /home/faceform/faceform_bot/
cd /home/faceform/faceform_bot
```

## Шаг 3: Настройка виртуального окружения Python

```bash
# Создание виртуального окружения
python3 -m venv venv

# Активация виртуального окружения
source venv/bin/activate

# Установка зависимостей
pip install -r vps_requirements.txt
```

## Шаг 4: Настройка Supervisor

```bash
# Копирование конфигурации Supervisor
sudo cp faceform_bot_supervisor.conf /etc/supervisor/conf.d/

# Создание директорий для логов
sudo mkdir -p /var/log/faceform_bot
sudo chown -R $USER:$USER /var/log/faceform_bot

# Обновление и запуск Supervisor
sudo supervisorctl reread
sudo supervisorctl update
sudo supervisorctl status
```

## Шаг 5: Настройка Nginx для веб-интерфейса

```bash
# Создание конфигурации Nginx
sudo nano /etc/nginx/sites-available/faceform_bot
```

Вставьте следующую конфигурацию (замените example.com на ваш домен):

```nginx
server {
    listen 80;
    server_name example.com www.example.com;

    location / {
        proxy_pass http://127.0.0.1:5000;
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto $scheme;
    }

    location /static {
        alias /home/faceform/faceform_bot/static;
        expires 30d;
    }
}
```

Активируйте конфигурацию:

```bash
sudo ln -s /etc/nginx/sites-available/faceform_bot /etc/nginx/sites-enabled/
sudo nginx -t
sudo systemctl restart nginx
```

## Шаг 6: Настройка SSL с Let's Encrypt

```bash
sudo apt install -y certbot python3-certbot-nginx
sudo certbot --nginx -d example.com -d www.example.com
```

## Шаг 7: Проверка работы

```bash
# Проверка логов
tail -f /var/log/faceform_bot/stderr.log
tail -f /var/log/faceform_bot/web_stderr.log

# Проверка статуса
sudo supervisorctl status
```

## Важные замечания

1. Переменные окружения и ключи API находятся в файле `.env`
2. База данных находится в файле `faceform_bot.db`
3. Для изменения настроек отредактируйте файл `config.py`
4. При необходимости перезапуска сервисов используйте:
   ```bash
   sudo supervisorctl restart faceform_bot
   sudo supervisorctl restart faceform_bot_web
   ```