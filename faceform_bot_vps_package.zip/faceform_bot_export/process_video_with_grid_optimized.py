import cv2
import logging
import tempfile
import os
import numpy as np
import mediapipe as mp
import subprocess
import shutil
import math
import random
from pathlib import Path
from PIL import Image, ImageDraw, ImageFont
import io

# Настройка логирования
logging.basicConfig(level=logging.DEBUG, 
                    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s')
logger = logging.getLogger(__name__)

# Установка уровня логирования для основного модуля
logger.setLevel(logging.DEBUG)

def draw_text_with_pil(img, text, position, font_size=30, color=(0, 255, 0), bg_color=(0, 0, 0, 255)):
    """
    Рисует текст с поддержкой кириллицы и 3D-эффектами, используя PIL
    
    Args:
        img: OpenCV изображение (в формате BGR)
        text: Текст для отображения (поддерживает кириллицу)
        position: Позиция (x, y) для отображения текста
        font_size: Размер шрифта
        color: Цвет текста в формате BGR или BGRA (с прозрачностью)
        bg_color: Цвет фона в формате BGR или BGRA (с прозрачностью)
        
    Returns:
        OpenCV изображение с добавленным текстом
    """
    # Логируем для отладки
    logger.debug(f"Добавление текста: '{text}' в позиции {position}")
    
    # Конвертируем из BGR в RGBA для PIL с поддержкой прозрачности
    img_rgb = cv2.cvtColor(img, cv2.COLOR_BGR2RGB)
    pil_img = Image.fromarray(img_rgb).convert("RGBA")
    
    # Создаем прозрачный слой для наложения текста
    text_overlay = Image.new('RGBA', pil_img.size, (0, 0, 0, 0))
    
    # Создаем объект для рисования на прозрачном слое
    draw = ImageDraw.Draw(text_overlay)
    
    # Пробуем загрузить шрифт DejaVuSans (поддерживает кириллицу)
    try:
        # Выведем список всех шрифтов в системе для отладки
        logger.debug("Поиск шрифтов с поддержкой кириллицы")
        
        # Распространенные пути к шрифтам в Linux
        system_font_dirs = [
            "/usr/share/fonts/",
            "/usr/local/share/fonts/",
            "/usr/share/fonts/truetype/",
            "/usr/share/fonts/TTF/",
            "/usr/share/fonts/dejavu/"
        ]
        
        # Соберем все потенциальные шрифты
        font_paths = []
        for font_dir in system_font_dirs:
            if os.path.exists(font_dir):
                logger.debug(f"Проверка директории: {font_dir}")
                for root, dirs, files in os.walk(font_dir):
                    for file in files:
                        if file.lower().endswith('.ttf'):
                            font_paths.append(os.path.join(root, file))
        
        logger.debug(f"Найдено {len(font_paths)} .ttf файлов")
        if font_paths:
            logger.debug(f"Первые 5 шрифтов: {font_paths[:5]}")
        
        # Конкретные шрифты, которые хорошо поддерживают кириллицу
        # Сначала используем абсолютные пути, так как мы точно знаем, где находится DejaVuSans.ttf
        cyrillic_fonts = [
            "/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf",  # Проверено, что этот шрифт существует в системе
            "/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf",
            "/usr/share/fonts/TTF/DejaVuSans.ttf",
            "/usr/share/fonts/dejavu/DejaVuSans.ttf",
            "/usr/share/fonts/truetype/freefont/FreeSans.ttf",
            "/usr/share/fonts/truetype/liberation/LiberationSans-Regular.ttf"
        ]
        
        # Логируем доступность основного шрифта
        if os.path.exists("/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf"):
            logger.info("Подтверждено: шрифт DejaVuSans.ttf доступен в системе")
        else:
            logger.warning("Шрифт DejaVuSans.ttf не найден по ожидаемому пути")
        
        # Добавляем найденные шрифты к списку проверки
        for path in font_paths[:10]:  # Проверяем только первые 10 найденных
            if "sans" in path.lower() and path not in cyrillic_fonts:
                cyrillic_fonts.append(path)
        
        # Ищем первый доступный шрифт
        font = None
        for path in cyrillic_fonts:
            if os.path.exists(path):
                try:
                    font = ImageFont.truetype(path, font_size)
                    logger.info(f"Используется шрифт с поддержкой кириллицы: {path}")
                    break
                except Exception as font_err:
                    logger.warning(f"Не удалось загрузить шрифт {path}: {font_err}")
                
        if font is None:
            # Если шрифт не найден, используем стандартный
            font = ImageFont.load_default()
            logger.warning("Не удалось найти подходящий шрифт, используется стандартный")
    except Exception as e:
        logger.warning(f"Ошибка при загрузке шрифта: {e}")
        font = ImageFont.load_default()
    
    # Определяем размер текста для создания фона
    text_bbox = draw.textbbox(position, text, font=font)
    logger.debug(f"Размер текста: {text_bbox}")
    
    # Обрабатываем цвета, чтобы добавить альфа-канал, если его нет
    def ensure_alpha(color):
        if len(color) == 3:
            return (color[0], color[1], color[2], 255)  # Полная непрозрачность
        return color
    
    bg_color = ensure_alpha(bg_color)
    color = ensure_alpha(color)
    
    # Рисуем фон с закругленными углами (3D-эффект)
    # Создаем прямоугольник с закругленными краями
    rounded_rect_margin = 5
    rect_coords = [
        text_bbox[0] - rounded_rect_margin, 
        text_bbox[1] - rounded_rect_margin,
        text_bbox[2] + rounded_rect_margin, 
        text_bbox[3] + rounded_rect_margin
    ]
    
    # Рисуем прямоугольник с градиентом для 3D эффекта
    corner_radius = 10
    
    # Преобразуем цвета BGR в RGB для PIL
    bg_color_rgb = (bg_color[2], bg_color[1], bg_color[0], bg_color[3])
    
    # Преобразуем список в кортеж пар координат для rounded_rectangle
    rect_coords_tuple = ((rect_coords[0], rect_coords[1]), (rect_coords[2], rect_coords[3]))
    
    # Рисуем скругленный прямоугольник
    draw.rounded_rectangle(rect_coords_tuple, corner_radius, fill=bg_color_rgb)
    
    # Рисуем текст с тенью для 3D эффекта (сначала тень)
    shadow_offset = 2
    shadow_color = (0, 0, 0, 180)  # Полупрозрачный черный
    shadow_position = (position[0] + shadow_offset, position[1] + shadow_offset)
    
    # Рисуем тень текста
    draw.text(shadow_position, text, fill=shadow_color, font=font)
    
    # Рисуем основной текст
    color_rgb = (color[2], color[1], color[0], color[3])  # BGR -> RGB с сохранением альфа-канала
    draw.text(position, text, fill=color_rgb, font=font)
    
    # Комбинируем изображение с наложенным текстом
    composite = Image.alpha_composite(pil_img.convert("RGBA"), text_overlay)
    
    # Конвертируем обратно в BGR для OpenCV
    result_img = cv2.cvtColor(np.array(composite.convert('RGB')), cv2.COLOR_RGB2BGR)
    return result_img

def calculate_distance(point1, point2):
    """Calculate Euclidean distance between two points"""
    return np.sqrt((point1[0] - point2[0]) ** 2 + (point1[1] - point2[1]) ** 2)

def analyze_skin_texture_uniformity(landmarks_list):
    """
    Анализирует равномерность текстуры кожи на основе распределения ориентиров на лице
    
    Args:
        landmarks_list (list): Список координат лицевых ориентиров
    
    Returns:
        float: Коэффициент неоднородности текстуры от 0 до 1, где 0 - идеально ровная текстура
    """
    # Выделяем ориентиры в области щек для анализа текстуры 
    # Используем точки из области левой и правой щеки
    left_cheek_indices = [117, 118, 119, 120, 121, 122, 123, 147, 187, 207, 212, 214, 192]
    right_cheek_indices = [348, 349, 350, 351, 397, 419, 427, 423, 376, 345, 352, 346, 347]
    
    # Ограничиваем индексы длиной списка landmarks_list
    max_index = len(landmarks_list) - 1
    left_cheek_indices = [min(idx, max_index) for idx in left_cheek_indices]
    right_cheek_indices = [min(idx, max_index) for idx in right_cheek_indices]
    
    # Средние расстояния между соседними точками на левой и правой щеке
    left_distances = []
    right_distances = []
    
    # Рассчитываем расстояния между соседними точками на левой щеке
    for i in range(len(left_cheek_indices)-1):
        p1 = landmarks_list[left_cheek_indices[i]]
        p2 = landmarks_list[left_cheek_indices[i+1]]
        left_distances.append(calculate_distance(p1, p2))
    
    # Рассчитываем расстояния между соседними точками на правой щеке
    for i in range(len(right_cheek_indices)-1):
        p1 = landmarks_list[right_cheek_indices[i]]
        p2 = landmarks_list[right_cheek_indices[i+1]]
        right_distances.append(calculate_distance(p1, p2))
    
    # Вычисляем стандартное отклонение расстояний как меру неоднородности
    if left_distances and right_distances:
        import numpy as np
        left_std = np.std(left_distances) / np.mean(left_distances) if np.mean(left_distances) > 0 else 0
        right_std = np.std(right_distances) / np.mean(right_distances) if np.mean(right_distances) > 0 else 0
        
        # Усредняем показатели для обеих щек
        texture_uniformity = (left_std + right_std) / 2
        
        # Нормализуем результат для получения значения от 0 до 1
        # Большее значение означает более неоднородную текстуру
        return min(1.0, texture_uniformity * 5)  # Масштабируем для усиления эффекта
    
    # Если не удалось рассчитать, возвращаем среднее значение
    return 0.2  # Значение по умолчанию - незначительная неоднородность

def analyze_facial_tone(landmarks_list, width_ratio):
    """
    Анализирует тонус лица на основе четкости контуров и формы лица
    
    Args:
        landmarks_list (list): Список координат лицевых ориентиров
        width_ratio (float): Соотношение ширины лица к его длине
        
    Returns:
        float: Оценка тонуса лица от 0 до 1, где 1 - отличный тонус
    """
    # Ключевые точки для анализа контура лица
    jawline_indices = [0, 17, 57, 106, 135, 149, 150, 176, 177, 178, 179, 180, 181, 191, 310, 311, 312, 313, 314, 315, 316, 334, 335, 337, 338, 338, 399, 400, 401, 402]
    
    # Ограничиваем индексы длиной списка landmarks_list
    max_index = len(landmarks_list) - 1
    jawline_indices = [min(idx, max_index) for idx in jawline_indices]
    
    # Вычисляем плавность контура как среднее отклонение от идеальной линии
    smoothness = calculate_contour_smoothness(landmarks_list, jawline_indices)
    
    # Фактор формы лица - округлые и овальные формы обычно имеют лучший тонус
    shape_factor = 0.7
    if 0.7 <= width_ratio <= 0.85:  # Оптимальные пропорции
        shape_factor = 0.9
    elif width_ratio > 0.85:  # Более круглое лицо
        shape_factor = 0.8
    elif width_ratio < 0.65:  # Вытянутое лицо
        shape_factor = 0.6
    
    # Итоговая оценка тонуса (70% важности - плавность контура, 30% - форма)
    tone_score = (smoothness * 0.7) + (shape_factor * 0.3)
    
    return min(1.0, tone_score)

def calculate_contour_smoothness(landmarks_list, contour_indices):
    """
    Вычисляет плавность контура лица
    
    Args:
        landmarks_list (list): Список координат лицевых ориентиров
        contour_indices (list): Индексы точек, образующих контур
        
    Returns:
        float: Оценка плавности контура от 0 до 1
    """
    # Получаем точки контура
    contour_points = [landmarks_list[idx] for idx in contour_indices if idx < len(landmarks_list)]
    
    # Если точек недостаточно, возвращаем среднее значение
    if len(contour_points) < 3:
        return 0.7
    
    # Вычисляем углы между соседними сегментами контура
    angles = []
    for i in range(1, len(contour_points)-1):
        # Векторы между точками
        v1 = [contour_points[i][0] - contour_points[i-1][0], 
              contour_points[i][1] - contour_points[i-1][1]]
        v2 = [contour_points[i+1][0] - contour_points[i][0], 
              contour_points[i+1][1] - contour_points[i][1]]
        
        # Вычисляем косинус угла между векторами
        import numpy as np
        norm_v1 = np.sqrt(v1[0]**2 + v1[1]**2)
        norm_v2 = np.sqrt(v2[0]**2 + v2[1]**2)
        
        if norm_v1 > 0 and norm_v2 > 0:
            cos_angle = (v1[0]*v2[0] + v1[1]*v2[1]) / (norm_v1 * norm_v2)
            # Ограничиваем значение косинуса между -1 и 1
            cos_angle = max(-1, min(1, cos_angle))
            angle = np.arccos(cos_angle)
            angles.append(angle)
    
    if not angles:
        return 0.7
    
    # Вычисляем стандартное отклонение углов как меру неплавности
    import numpy as np
    angle_std = np.std(angles)
    
    # Преобразуем в оценку плавности (меньшее отклонение = более плавный контур)
    smoothness = 1.0 - min(1.0, angle_std / np.pi)
    
    return smoothness


def draw_face_contour(image, landmarks_list, face_shape):
    """
    Рисует четкие линии контура лица для определения формы лица,
    аналогично изображениям-примерам
    
    Args:
        image (numpy.ndarray): Исходное изображение
        landmarks_list (list): Список координат точек лица
        face_shape (str): Определенная форма лица
        
    Returns:
        numpy.ndarray: Изображение с нарисованными контурами
    """
    if len(landmarks_list) < 10:
        return image  # Недостаточно точек для контура
    
    # Создаем копию изображения для рисования
    img_with_contour = image.copy()
    
    # Определяем ключевые индексы точек для контура лица
    # Эти индексы соответствуют модели лица MediaPipe Face Mesh
    
    # Линия челюсти
    jawline_indices = [0, 17, 18, 20, 21, 32, 35, 37, 38, 39, 40, 43, 45, 46, 47, 
                        48, 50, 58, 66, 67, 88, 89, 90, 91, 92, 93, 94, 106, 
                        107, 108, 109, 135, 136, 149, 150, 152, 176, 177, 
                        199, 200, 201, 202, 204, 207, 208, 210, 211, 212, 
                        213, 214, 215, 216]
    
    # Линия лба
    forehead_indices = [10, 21, 33, 34, 35, 45, 50, 55, 65, 66, 67, 69, 75, 
                         80, 81, 82, 84, 87, 105, 106, 107, 108, 109, 112, 123, 
                         129, 134, 136, 137, 275, 276, 283, 297, 299, 334, 
                         335, 336, 337, 338, 339, 340, 341, 351, 375, 397, 
                         398, 400, 432, 433, 434]
    
    # Линия скул
    cheekbone_indices = [21, 22, 26, 35, 36, 39, 50, 71, 89, 102, 103, 104, 105, 
                           108, 109, 124, 136, 137, 138, 170, 171, 175, 195, 197, 
                           205, 206, 207, 208, 209, 210, 211, 212, 213, 214, 215, 216, 
                           330, 331, 332, 333, 334, 335, 342, 344, 350, 351, 352, 435, 
                           436, 437, 458, 459, 460, 461, 462]
    
    # Линии для разных форм лица
    face_shape_contours = {
        "ROUND": [10, 21, 50, 103, 109, 137, 175, 211, 323, 334, 351, 373, 435, 438, 445, 454, 465],
        "SQUARE": [10, 21, 34, 50, 60, 88, 89, 109, 125, 175, 213, 214, 227, 260, 276, 330, 351, 370, 400, 435, 447],
        "OVAL": [10, 21, 33, 50, 67, 89, 109, 126, 151, 208, 227, 264, 330, 351, 380, 402, 435, 445],
        "HEART": [10, 21, 32, 50, 66, 69, 90, 109, 126, 176, 208, 220, 264, 313, 330, 351, 365, 400, 435, 440],
        "OBLONG": [10, 21, 33, 50, 67, 74, 88, 109, 126, 151, 204, 227, 276, 316, 335, 351, 380, 402, 435, 445],
        "DIAMOND": [10, 21, 32, 50, 67, 88, 103, 109, 126, 175, 208, 227, 276, 316, 330, 351, 380, 402, 435, 445]
    }
    
    # Линия для текущей формы лица (если определена)
    specific_contour = face_shape_contours.get(face_shape, face_shape_contours["OVAL"])
    
    # Получаем размеры изображения
    height, width = img_with_contour.shape[:2]
    
    # Ограничиваем индексы длиной списка landmarks_list
    max_index = len(landmarks_list) - 1
    jawline_indices = [min(idx, max_index) for idx in jawline_indices]
    forehead_indices = [min(idx, max_index) for idx in forehead_indices]
    cheekbone_indices = [min(idx, max_index) for idx in cheekbone_indices]
    specific_contour = [min(idx, max_index) for idx in specific_contour]
    
    # Получаем точки для каждой линии
    jawline_points = np.array([(int(landmarks_list[idx][0] * width), int(landmarks_list[idx][1] * height)) 
                              for idx in jawline_indices])
    
    forehead_points = np.array([(int(landmarks_list[idx][0] * width), int(landmarks_list[idx][1] * height)) 
                               for idx in forehead_indices])
    
    cheekbone_points = np.array([(int(landmarks_list[idx][0] * width), int(landmarks_list[idx][1] * height)) 
                                for idx in cheekbone_indices])
    
    specific_points = np.array([(int(landmarks_list[idx][0] * width), int(landmarks_list[idx][1] * height)) 
                               for idx in specific_contour])
    
    # Рисуем основной контур формы лица (красный, более толстый)
    for i in range(1, len(specific_points)):
        cv2.line(img_with_contour, tuple(specific_points[i-1]), tuple(specific_points[i]), (0, 0, 255), 2)
    
    # Закрываем контур
    if len(specific_points) > 2:
        cv2.line(img_with_contour, tuple(specific_points[-1]), tuple(specific_points[0]), (0, 0, 255), 2)
    
    # Рисуем дополнительные линии для лучшего визуального анализа (более тонкие)
    if face_shape == "ROUND" or face_shape == "SQUARE":
        # Рисуем линию челюсти более четко для квадратной и круглой формы 
        for i in range(1, len(jawline_points)):
            cv2.line(img_with_contour, tuple(jawline_points[i-1]), tuple(jawline_points[i]), (0, 70, 255), 1)
    
    if face_shape == "HEART" or face_shape == "DIAMOND":
        # Подчеркиваем линию скул для формы сердца и ромба
        for i in range(1, len(cheekbone_points)):
            cv2.line(img_with_contour, tuple(cheekbone_points[i-1]), tuple(cheekbone_points[i]), (0, 100, 255), 1)
    
    if face_shape == "OVAL" or face_shape == "OBLONG":
        # Подчеркиваем линию лба для овальной и продолговатой формы
        for i in range(1, len(forehead_points)):
            cv2.line(img_with_contour, tuple(forehead_points[i-1]), tuple(forehead_points[i]), (0, 100, 255), 1)
    
    return img_with_contour


def detect_face_asymmetry(landmarks_list):
    """
    Определение асимметрии лица на основе ключевых точек
    
    Args:
        landmarks_list (list): Список координат ключевых точек лица
        
    Returns:
        tuple: (вертикальная асимметрия (0-1), горизонтальная асимметрия (0-1), 
                информация об асимметрии)
    """
    # Недостаточно ключевых точек для анализа
    if len(landmarks_list) < 50:
        return 0.5, 0.5, "недостаточно данных"
    
    # Найдем центральную вертикальную линию лица (среднее между глазами)
    # Индексы для глаз в MediaPipe Face Mesh
    left_eye_idx = 33  # Левый глаз (правый на изображении)
    right_eye_idx = 263  # Правый глаз (левый на изображении)
    
    # Проверка индексов
    if left_eye_idx >= len(landmarks_list) or right_eye_idx >= len(landmarks_list):
        # Используем среднее всех точек
        all_x = [p[0] for p in landmarks_list]
        center_x = sum(all_x) / len(all_x) if all_x else 0
    else:
        left_eye = landmarks_list[left_eye_idx]
        right_eye = landmarks_list[right_eye_idx]
        center_x = (left_eye[0] + right_eye[0]) / 2
    
    # Разделяем точки на левую и правую стороны
    left_points = [p for p in landmarks_list if p[0] < center_x]
    right_points = [p for p in landmarks_list if p[0] > center_x]
    
    # Проверка на отсутствие данных
    if not left_points or not right_points:
        return 0.5, 0.5, "недостаточно данных"
    
    # 1. Вертикальная асимметрия (разная высота глаз)
    # Индексы для внешних уголков глаз
    left_eye_corner_idx = 33  # Внешний уголок левого глаза (правый на изображении)
    right_eye_corner_idx = 263  # Внешний уголок правого глаза (левый на изображении)
    
    # Индексы для внутренних уголков глаз
    left_eye_inner_idx = 133  # Внутренний уголок левого глаза
    right_eye_inner_idx = 362  # Внутренний уголок правого глаза
    
    # Проверка индексов и вычисление вертикальной асимметрии
    max_idx = len(landmarks_list) - 1
    left_eye_corner_idx = min(left_eye_corner_idx, max_idx)
    right_eye_corner_idx = min(right_eye_corner_idx, max_idx)
    left_eye_inner_idx = min(left_eye_inner_idx, max_idx)
    right_eye_inner_idx = min(right_eye_inner_idx, max_idx)
    
    left_eye_outer = landmarks_list[left_eye_corner_idx]
    right_eye_outer = landmarks_list[right_eye_corner_idx]
    left_eye_inner = landmarks_list[left_eye_inner_idx]
    right_eye_inner = landmarks_list[right_eye_inner_idx]
    
    # Средняя y-координата для каждого глаза
    left_eye_y = (left_eye_outer[1] + left_eye_inner[1]) / 2
    right_eye_y = (right_eye_outer[1] + right_eye_inner[1]) / 2
    
    # Разница в высоте глаз
    eye_height_diff = abs(left_eye_y - right_eye_y)
    
    # Размер лица для нормализации
    face_height = max(p[1] for p in landmarks_list) - min(p[1] for p in landmarks_list)
    vert_asymmetry = min(1.0, eye_height_diff / (face_height * 0.06))  # 6% высоты лица как порог
    
    # 2. Горизонтальная асимметрия (одна сторона шире другой)
    # Вычисляем среднее расстояние точек от центральной линии
    left_side_widths = [abs(p[0] - center_x) for p in left_points]
    right_side_widths = [abs(p[0] - center_x) for p in right_points]
    
    left_avg_width = sum(left_side_widths) / len(left_side_widths) if left_side_widths else 0
    right_avg_width = sum(right_side_widths) / len(right_side_widths) if right_side_widths else 0
    
    # Разница в ширине сторон
    width_diff_ratio = abs(left_avg_width - right_avg_width) / max(left_avg_width, right_avg_width)
    horiz_asymmetry = min(1.0, width_diff_ratio * 2.0)  # Множитель для усиления эффекта
    
    # Формирование информации об асимметрии
    asymmetry_info = []
    
    if vert_asymmetry > 0.3:
        if left_eye_y < right_eye_y:
            asymmetry_info.append("правый глаз ниже")
        else:
            asymmetry_info.append("левый глаз ниже")
    
    if horiz_asymmetry > 0.3:
        if left_avg_width > right_avg_width:
            asymmetry_info.append("левая часть шире")
        else:
            asymmetry_info.append("правая часть шире")
    
    asymmetry_text = ", ".join(asymmetry_info) if asymmetry_info else "симметричное лицо"
    
    return vert_asymmetry, horiz_asymmetry, asymmetry_text


def estimate_age(landmarks_list, face_shape_scores=None):
    """
    Определение примерного возраста на основе пропорций лица и ключевых точек
    
    Args:
        landmarks_list (list): Список координат ключевых точек лица
        face_shape_scores (dict, optional): Словарь с оценками форм лица
        
    Returns:
        tuple: (estimated_age, age_range)
    """
    # Недостаточно данных для анализа
    if len(landmarks_list) < 50:
        return 30, "25-35"
    
    # Индексы ключевых областей лица, связанных с возрастными изменениями
    # Область глаз (морщинки в уголках глаз - гусиные лапки)
    eye_corner_indices = [33, 133, 160, 144, 153, 154, 155,  # Левый глаз
                          263, 362, 384, 373, 381, 380, 374]  # Правый глаз
    
    # Область лба (горизонтальные морщины)
    forehead_indices = [10, 67, 69, 104, 108, 334, 336, 338]
    
    # Область вокруг рта (носогубные складки, морщины)
    mouth_indices = [61, 76, 62, 78, 191, 95, 88, 178, 87, 14, 317, 402, 291, 318]
    
    # Ограничиваем индексы длиной списка
    max_idx = len(landmarks_list) - 1
    eye_corner_indices = [min(idx, max_idx) for idx in eye_corner_indices]
    forehead_indices = [min(idx, max_idx) for idx in forehead_indices]
    mouth_indices = [min(idx, max_idx) for idx in mouth_indices]
    
    # Вычисляем неравномерность распределения точек в возрастных областях
    # Большая неравномерность может указывать на морщины
    age_factors = []
    
    # Анализ области глаз
    if len(eye_corner_indices) >= 4:
        eye_points = [landmarks_list[idx] for idx in eye_corner_indices]
        eye_distances = []
        for i in range(len(eye_points) - 1):
            for j in range(i + 1, min(i + 3, len(eye_points))):
                dist = calculate_distance(eye_points[i], eye_points[j])
                eye_distances.append(dist)
        
        if eye_distances:
            eye_std = np.std(eye_distances) / np.mean(eye_distances) if np.mean(eye_distances) > 0 else 0
            age_factors.append(min(1.0, eye_std * 5.0))  # Нормализуем и усиливаем эффект
    
    # Анализ области лба
    if len(forehead_indices) >= 4:
        forehead_points = [landmarks_list[idx] for idx in forehead_indices]
        forehead_distances = []
        for i in range(len(forehead_points) - 1):
            for j in range(i + 1, min(i + 3, len(forehead_points))):
                dist = calculate_distance(forehead_points[i], forehead_points[j])
                forehead_distances.append(dist)
        
        if forehead_distances:
            forehead_std = np.std(forehead_distances) / np.mean(forehead_distances) if np.mean(forehead_distances) > 0 else 0
            age_factors.append(min(1.0, forehead_std * 5.0))
    
    # Анализ области рта
    if len(mouth_indices) >= 4:
        mouth_points = [landmarks_list[idx] for idx in mouth_indices]
        mouth_distances = []
        for i in range(len(mouth_points) - 1):
            for j in range(i + 1, min(i + 3, len(mouth_points))):
                dist = calculate_distance(mouth_points[i], mouth_points[j])
                mouth_distances.append(dist)
        
        if mouth_distances:
            mouth_std = np.std(mouth_distances) / np.mean(mouth_distances) if np.mean(mouth_distances) > 0 else 0
            age_factors.append(min(1.0, mouth_std * 5.0))
    
    # Если нет данных о факторах возраста
    if not age_factors:
        return 30, "25-35"
    
    # Базовый возраст
    base_age = 25
    
    # Средний фактор возраста
    avg_age_factor = sum(age_factors) / len(age_factors)
    
    # Расчет примерного возраста на основе среднего фактора
    # Максимальная прибавка - 30 лет к базовому возрасту
    age_addition = avg_age_factor * 30.0
    
    # Если предоставлены оценки формы лица, используем их для уточнения
    if face_shape_scores and isinstance(face_shape_scores, dict):
        # Более округлые формы часто ассоциируются с молодостью
        round_score = face_shape_scores.get("ROUND", 0) / 6.0  # Максимум 6 баллов
        # Более угловатые формы часто ассоциируются со зрелостью
        square_score = face_shape_scores.get("SQUARE", 0) / 6.0
    else:
        # Если face_shape_scores не словарь, используем значения по умолчанию
        logger.warning(f"В estimate_age передан некорректный параметр face_shape_scores: {type(face_shape_scores)}")
        round_score = 1.0 / 6.0  # По умолчанию
        square_score = 1.0 / 6.0  # По умолчанию
        
        # Корректировка возраста на основе формы лица
        shape_adjustment = square_score - round_score
        age_addition += shape_adjustment * 5  # ±5 лет максимум
    
    # Итоговый возраст
    estimated_age = base_age + age_addition
    estimated_age = max(18, min(65, round(estimated_age)))  # Ограничиваем диапазон
    
    # Определение возрастного диапазона
    if estimated_age < 25:
        age_range = "18-25"
    elif estimated_age < 35:
        age_range = "25-35"
    elif estimated_age < 45:
        age_range = "35-45"
    elif estimated_age < 55:
        age_range = "45-55"
    else:
        age_range = "55+"
    
    return estimated_age, age_range

def calculate_face_proportions(landmarks_list):
    """
    Вычисляет пропорции лица на основе ориентиров
    
    Args:
        landmarks_list (list): Список координат лицевых ориентиров
        
    Returns:
        tuple: (width_ratio, forehead_ratio, cheekbone_ratio)
    """
    if not landmarks_list:
        return 0.75, 1.0, 1.2  # Значения по умолчанию для овального лица
        
    # Используем конкретные индексы точек MediaPipe Face Mesh для расчета пропорций
    # Определение ширины и длины лица (с уточненными индексами для большей точности)
    face_top = landmarks_list[10][1]  # Верхняя точка лица (лоб)
    face_bottom = landmarks_list[152][1]  # Нижняя точка подбородка
    face_length = face_bottom - face_top
    
    left_side = landmarks_list[234][0]  # Левая сторона лица
    right_side = landmarks_list[454][0]  # Правая сторона лица
    face_width = right_side - left_side
    
    # Вычисляем ширину лба, челюсти и скул с использованием более точных точек
    # Лоб (верхняя треть лица)
    forehead_left = landmarks_list[21][0]
    forehead_right = landmarks_list[251][0]
    forehead_width = forehead_right - forehead_left
    
    # Челюсть (нижняя линия лица)
    jaw_left = landmarks_list[172][0]
    jaw_right = landmarks_list[397][0]
    jaw_width = jaw_right - jaw_left
    
    # Скулы (средняя часть лица)
    cheekbone_left = landmarks_list[123][0]
    cheekbone_right = landmarks_list[352][0]
    cheekbone_width = cheekbone_right - cheekbone_left
    
    # Дополнительно измеряем высоту нижней части лица для лучшего определения квадратной формы
    chin_height = face_bottom - landmarks_list[200][1]  # Расстояние от нижней губы до подбородка
    
    # Вычисляем соотношения с проверкой деления на ноль
    if face_length > 0:
        width_ratio = face_width / face_length
        chin_ratio = chin_height / face_length  # Дополнительная метрика для определения типа подбородка
    else:
        width_ratio = 0.75
        chin_ratio = 0.3
        
    if jaw_width > 0:
        forehead_ratio = forehead_width / jaw_width
        cheekbone_ratio = cheekbone_width / jaw_width
    else:
        forehead_ratio = 1.0
        cheekbone_ratio = 1.2
        
    # Логируем пропорции для отладки
    logger.debug(f"Пропорции лица: W/L={width_ratio:.2f}, F/J={forehead_ratio:.2f}, C/J={cheekbone_ratio:.2f}, Chin={chin_ratio:.2f}")
        
    return width_ratio, forehead_ratio, cheekbone_ratio
    
def get_face_shape_scores(width_ratio, forehead_ratio, cheekbone_ratio):
    """
    Рассчитывает вероятностные оценки для каждой формы лица на основе пропорций
    
    Args:
        width_ratio (float): Отношение ширины к длине лица
        forehead_ratio (float): Отношение ширины лба к ширине челюсти
        cheekbone_ratio (float): Отношение ширины скул к ширине челюсти
        
    Returns:
        dict: Словарь с оценками для каждой формы лица
    """
    # Инициализируем оценки для каждой формы лица
    scores = {
        "OVAL": 0.0,      # Овальная
        "ROUND": 0.0,     # Круглая
        "SQUARE": 0.0,    # Квадратная
        "HEART": 0.0,     # Сердцевидная
        "OBLONG": 0.0,    # Продолговатая
        "DIAMOND": 0.0    # Ромбовидная
    }
    
    # КРУГЛАЯ форма - широкое лицо, почти равные соотношения частей лица
    if width_ratio >= 0.8:
        scores["ROUND"] += (width_ratio - 0.8) * 10.0  # Основной фактор - соотношение ширины к длине
    if 0.9 <= forehead_ratio <= 1.1 and 0.9 <= cheekbone_ratio <= 1.1:
        scores["ROUND"] += 0.5  # Дополнительные баллы за равномерность
    
    # ОВАЛЬНАЯ форма - идеальные пропорции ближе к золотому сечению
    if 0.65 <= width_ratio <= 0.75:
        oval_factor = 1.0 - abs(0.7 - width_ratio) * 5.0  # Ближе к 0.7 - выше оценка
        scores["OVAL"] += oval_factor
    if forehead_ratio >= 1.0 and cheekbone_ratio >= 1.0:
        scores["OVAL"] += 0.3  # Дополнительные баллы за более широкий лоб и скулы
    
    # КВАДРАТНАЯ форма - широкое лицо с выраженной челюстью
    if width_ratio >= 0.75 and width_ratio <= 0.9:
        scores["SQUARE"] += 0.5  # Базовая оценка за ширину
    if forehead_ratio <= 1.1 and cheekbone_ratio <= 1.2:
        square_factor = (1.1 - forehead_ratio) + (1.2 - cheekbone_ratio)
        scores["SQUARE"] += square_factor  # Более высокий балл для более узкого лба и скул
    
    # СЕРДЦЕВИДНАЯ форма - широкий лоб, узкий подбородок
    if forehead_ratio >= 1.1:
        heart_factor = (forehead_ratio - 1.1) * 2.0
        scores["HEART"] += heart_factor  # Основной признак - ширина лба
    if cheekbone_ratio >= 1.2:
        scores["HEART"] += (cheekbone_ratio - 1.2) * 0.5  # Дополнительно учитываем скулы
    
    # ПРОДОЛГОВАТАЯ форма - длинное узкое лицо
    if width_ratio <= 0.7:
        oblong_factor = (0.7 - width_ratio) * 10.0
        scores["OBLONG"] += oblong_factor  # Основной признак - узкое лицо
    
    # РОМБОВИДНАЯ форма - выраженные скулы, узкий лоб и подбородок
    if cheekbone_ratio >= 1.2 and forehead_ratio <= 1.0:
        diamond_factor = (cheekbone_ratio - 1.2) * 2.0 + (1.0 - forehead_ratio)
        scores["DIAMOND"] += diamond_factor  # Комбинированный признак
        
    # Нормализуем оценки для лучшего сравнения
    total_score = sum(scores.values())
    if total_score > 0:
        for shape in scores:
            scores[shape] = scores[shape] / total_score
            
    # Убедимся, что минимальная оценка для каждой формы не ниже 0.05 для устранения резких переходов
    for shape in scores:
        scores[shape] = max(scores[shape], 0.05)
        
    # Снова нормализуем после установки минимальных значений
    total_score = sum(scores.values())
    if total_score > 0:
        for shape in scores:
            scores[shape] = scores[shape] / total_score
    
    # Логируем оценки всех форм для отладки
    logger.debug(f"Оценки форм лица: {', '.join([f'{shape}: {score:.2f}' for shape, score in scores.items()])}")
            
    return scores

def calculate_chin_angle(landmarks_list):
    """
    Рассчитывает угол подбородка для уточнения формы лица
    
    Args:
        landmarks_list (list): Список координат лицевых ориентиров
        
    Returns:
        float: Угол подбородка в радианах
    """
    if len(landmarks_list) < 200:
        return 0.0
        
    # Используем три точки: центр подбородка и две боковые точки челюсти
    chin_center = landmarks_list[152]  # Центральная точка подбородка
    jaw_left = landmarks_list[172]     # Левый угол челюсти
    jaw_right = landmarks_list[397]    # Правый угол челюсти
    
    # Вычисляем векторы от центра подбородка к углам челюсти
    vec_left = (jaw_left[0] - chin_center[0], jaw_left[1] - chin_center[1])
    vec_right = (jaw_right[0] - chin_center[0], jaw_right[1] - chin_center[1])
    
    # Вычисляем углы между вертикалью и векторами
    import math
    angle_left = math.atan2(vec_left[1], vec_left[0]) if vec_left[0] != 0 else math.pi/2
    angle_right = math.atan2(vec_right[1], vec_right[0]) if vec_right[0] != 0 else math.pi/2
    
    # Вычисляем средний угол
    chin_angle = (abs(angle_left) + abs(angle_right)) / 2
    
    return chin_angle

def calculate_jaw_width_to_length(landmarks_list):
    """
    Рассчитывает соотношение ширины челюсти к её длине для уточнения формы лица
    
    Args:
        landmarks_list (list): Список координат лицевых ориентиров
        
    Returns:
        float: Соотношение ширины челюсти к её длине
    """
    if len(landmarks_list) < 400:
        return 1.0
        
    # Точки для определения ширины челюсти
    jaw_left = landmarks_list[172]    # Левый угол челюсти
    jaw_right = landmarks_list[397]   # Правый угол челюсти
    
    # Точки для определения длины челюсти (от центра низа челюсти до центра низа лица)
    jaw_center = landmarks_list[200]  # Центр низа челюсти (нижняя губа)
    chin_bottom = landmarks_list[152] # Самая нижняя точка подбородка
    
    # Вычисляем ширину и длину
    jaw_width = abs(jaw_right[0] - jaw_left[0])
    jaw_length = abs(chin_bottom[1] - jaw_center[1])
    
    # Избегаем деления на ноль
    if jaw_length > 0:
        ratio = jaw_width / jaw_length
    else:
        ratio = 1.0
        
    return ratio

def adjust_scores_by_features(face_scores, chin_angle, jaw_width_to_length):
    """
    Корректирует оценки форм лица на основе дополнительных характеристик
    
    Args:
        face_scores (dict): Словарь с исходными оценками форм лица
        chin_angle (float): Угол подбородка
        jaw_width_to_length (float): Соотношение ширины челюсти к её длине
        
    Returns:
        None (изменяет face_scores на месте)
    """
    import math
    
    # Корректировка для КВАДРАТНОЙ формы
    # Более угловатая челюсть (меньший угол) = более высокая вероятность квадратной формы
    if chin_angle < math.pi/4:  # Менее 45 градусов - более квадратная форма
        face_scores["SQUARE"] *= 1.5
        
    # Корректировка для СЕРДЦЕВИДНОЙ формы
    # Более острый подбородок = более высокая вероятность сердцевидной формы
    if chin_angle > math.pi/3:  # Более 60 градусов - более острый подбородок
        face_scores["HEART"] *= 1.3
        
    # Корректировка для РОМБОВИДНОЙ формы
    # Сочетание острого подбородка и определенного соотношения ширины к длине челюсти
    if chin_angle > math.pi/4 and jaw_width_to_length < 3.0:
        face_scores["DIAMOND"] *= 1.4
        
    # Корректировка для ОВАЛЬНОЙ формы
    # Плавные линии челюсти (средний угол) = более высокая вероятность овальной формы
    if math.pi/6 < chin_angle < math.pi/3:  # Между 30 и 60 градусами
        face_scores["OVAL"] *= 1.2
        
    # Корректировка для КРУГЛОЙ формы
    # Широкая и короткая челюсть = более высокая вероятность круглой формы
    if jaw_width_to_length > 4.0:
        face_scores["ROUND"] *= 1.4
        
    # Корректировка для ПРОДОЛГОВАТОЙ формы
    # Узкая и длинная челюсть = более высокая вероятность продолговатой формы
    if jaw_width_to_length < 2.5:
        face_scores["OBLONG"] *= 1.3
        
    # Нормализуем оценки после корректировок
    total_score = sum(face_scores.values())
    if total_score > 0:
        for shape in face_scores:
            face_scores[shape] = face_scores[shape] / total_score

def stabilize_shape_detection(face_scores, face_shape_counts):
    """
    Стабилизирует определение формы лица с учетом предыдущих определений
    
    Args:
        face_scores (dict): Текущие оценки форм лица
        face_shape_counts (dict): Счетчики обнаружений разных форм лица
        
    Returns:
        None (изменяет face_scores на месте)
    """
    # Значение стабилизации - насколько сильно учитывать историю (0.0 - не учитывать, 1.0 - максимально учитывать)
    stability_factor = 0.5
    
    # Получаем общее количество кадров с определенными формами лица
    total_shapes = sum(face_shape_counts.values())
    
    if total_shapes > 0:
        # Рассчитываем исторические веса для каждой формы
        history_weights = {}
        for shape, count in face_shape_counts.items():
            history_weights[shape] = count / total_shapes
            
        # Комбинируем текущие оценки с историческими весами
        for shape in face_scores:
            if shape in history_weights:
                # Взвешенное среднее между текущей оценкой и историческим весом
                face_scores[shape] = (face_scores[shape] * (1 - stability_factor) + 
                                      history_weights[shape] * stability_factor)

def calculate_face_symmetry(landmarks_list):
    """
    Рассчитывает симметрию лица на основе лицевых ориентиров
    
    Args:
        landmarks_list (list): Список координат лицевых ориентиров
    
    Returns:
        float: Коэффициент симметрии от 0 до 1, где 1 - идеально симметричное лицо
    """
    # Ключевые пары точек для проверки симметрии
    # Используем индексы из MediaPipe Face Mesh
    symmetry_pairs = [
        # Брови
        (336, 107),  # Внешние углы бровей
        (296, 67),   # Внутренние углы бровей
        
        # Глаза
        (33, 263),   # Внешние углы глаз
        (133, 362),  # Внутренние углы глаз
        
        # Скулы
        (234, 454),  # Скулы
        
        # Нос
        (129, 358),  # Крылья носа
        
        # Рот
        (61, 291),   # Углы рта
        (0, 17),     # Верхняя и нижняя губа центр
        
        # Челюсть
        (172, 397),  # Углы челюсти
    ]
    
    # Найдем центральную вертикальную линию лица (среднее по x между глазами)
    left_eye = landmarks_list[33]
    right_eye = landmarks_list[263]
    center_x = (left_eye[0] + right_eye[0]) / 2
    
    # Рассчитаем асимметрию для каждой пары точек
    symmetry_scores = []
    for left_idx, right_idx in symmetry_pairs:
        try:
            left_point = landmarks_list[left_idx]
            right_point = landmarks_list[right_idx]
            
            # Расстояние от центральной линии до каждой точки
            left_dist = abs(left_point[0] - center_x)
            right_dist = abs(right_point[0] - center_x)
            
            # Высота (y-координата) точек должна быть примерно одинаковой
            height_diff = abs(left_point[1] - right_point[1])
            
            # Вычисляем коэффициент симметрии для данной пары
            # Идеальная симметрия: left_dist = right_dist и height_diff = 0
            ratio = min(left_dist, right_dist) / max(left_dist, right_dist) if max(left_dist, right_dist) > 0 else 1
            
            # Нормализуем разницу высот относительно размера лица
            # Используем расстояние между глазами как масштаб
            eye_distance = calculate_distance(left_eye, right_eye)
            norm_height_diff = 1 - min(1, height_diff / (eye_distance / 2)) if eye_distance > 0 else 0
            
            # Общий коэффициент для пары (средневзвешенное)
            pair_symmetry = (ratio * 0.7) + (norm_height_diff * 0.3)
            symmetry_scores.append(pair_symmetry)
        except (IndexError, ZeroDivisionError, TypeError) as e:
            # Пропускаем пару, если с ней возникла проблема
            logger.warning(f"Ошибка при расчете симметрии для пары {left_idx}, {right_idx}: {e}")
            continue
    
    # Общий коэффициент симметрии - среднее по всем парам
    if symmetry_scores:
        return sum(symmetry_scores) / len(symmetry_scores)
    else:
        return 0.85  # Значение по умолчанию, если не удалось рассчитать

def determine_face_shape(width_to_length_ratio, forehead_to_jawline_ratio, cheekbone_to_jawline_ratio):
    """
    Улучшенное определение формы лица на основе измерений и пропорций с использованием системы баллов
    
    Args:
        width_to_length_ratio (float): Соотношение ширины лица к его длине
        forehead_to_jawline_ratio (float): Соотношение ширины лба к ширине челюсти
        cheekbone_to_jawline_ratio (float): Соотношение ширины скул к ширине челюсти
        
    Returns:
        tuple: (определенная форма лица, баллы для всех форм)
    """
    # Создаем словарь для подсчета баллов для каждой формы лица
    scores = {
        "OVAL": 0,
        "ROUND": 0,
        "SQUARE": 0,
        "HEART": 0,
        "OBLONG": 0,
        "DIAMOND": 0
    }
    
    # Округляем значения для более надежного определения
    width_to_length_ratio = round(width_to_length_ratio, 2)
    forehead_to_jawline_ratio = round(forehead_to_jawline_ratio, 2)
    cheekbone_to_jawline_ratio = round(cheekbone_to_jawline_ratio, 2)
    
    # Логирование измерений для отладки
    logger.info(f"FACE MEASUREMENTS: width/length: {width_to_length_ratio}, forehead/jaw: {forehead_to_jawline_ratio}, cheek/jaw: {cheekbone_to_jawline_ratio}")
    
    # ОВАЛЬНОЕ лицо (классическая форма)
    if 0.65 <= width_to_length_ratio <= 0.75:  # Вытянутое лицо, но не совсем продолговатое
        scores["OVAL"] += 3
    
    if 0.9 <= forehead_to_jawline_ratio <= 1.1:  # Примерно равные ширина лба и челюсти
        scores["OVAL"] += 1
    
    if 1.1 <= cheekbone_to_jawline_ratio <= 1.5:  # Мягкие очертания скул относительно челюсти
        scores["OVAL"] += 2
    
    # КРУГЛОЕ лицо (ширина близка к длине, мягкие углы)
    if width_to_length_ratio >= 0.8:  # Почти такая же ширина, как и длина
        scores["ROUND"] += 3
    
    if 0.85 <= forehead_to_jawline_ratio <= 1.15:  # Равные ширина лба и челюсти
        scores["ROUND"] += 1
    
    if 0.9 <= cheekbone_to_jawline_ratio <= 1.2:  # Скулы близко по ширине к челюсти
        scores["ROUND"] += 2
    
    # КВАДРАТНОЕ лицо (широкая челюсть, отчетливые углы)
    if 0.75 <= width_to_length_ratio <= 0.85:  # Умеренно широкое лицо
        scores["SQUARE"] += 1
    
    if 0.95 <= forehead_to_jawline_ratio <= 1.05:  # Лоб примерно равен челюсти
        scores["SQUARE"] += 2
    
    if 0.85 <= cheekbone_to_jawline_ratio <= 1.1:  # Слабо выраженные скулы относительно ширины челюсти
        scores["SQUARE"] += 3
    
    # СЕРДЦЕВИДНОЕ лицо (широкий лоб, узкий подбородок)
    if 0.65 <= width_to_length_ratio <= 0.75:  # Умеренно вытянутое лицо
        scores["HEART"] += 1
    
    if forehead_to_jawline_ratio > 1.15:  # Лоб заметно шире челюсти
        scores["HEART"] += 3
    
    if 1.2 <= cheekbone_to_jawline_ratio <= 1.5:  # Скулы выражены сильнее челюсти
        scores["HEART"] += 2
    
    # ПРОДОЛГОВАТОЕ лицо (длинное лицо)
    if width_to_length_ratio < 0.65:  # Очень вытянутое лицо
        scores["OBLONG"] += 3
    
    if 0.9 <= forehead_to_jawline_ratio <= 1.1:  # Примерно равные лоб и челюсть
        scores["OBLONG"] += 1
    
    if 1.0 <= cheekbone_to_jawline_ratio <= 1.3:  # Умеренно выраженные скулы
        scores["OBLONG"] += 1
    
    # РОМБОВИДНОЕ лицо (выраженные скулы, узкий лоб и подбородок)
    if 0.65 <= width_to_length_ratio <= 0.75:  # Умеренно вытянутое лицо
        scores["DIAMOND"] += 1
    
    if forehead_to_jawline_ratio < 0.95:  # Лоб уже челюсти
        scores["DIAMOND"] += 1
    
    if cheekbone_to_jawline_ratio > 1.35:  # Очень выраженные скулы
        scores["DIAMOND"] += 3
    
    # Для российских лиц - дополнительные правила
    # Исследования показывают, что славянские лица чаще имеют овальную или круглую форму
    if 0.7 <= width_to_length_ratio <= 0.8 and 1.0 <= cheekbone_to_jawline_ratio <= 1.3:
        scores["OVAL"] += 1  # Небольшой бонус для овальной формы
    
    if width_to_length_ratio >= 0.75 and cheekbone_to_jawline_ratio <= 1.2:
        scores["ROUND"] += 1  # Небольшой бонус для круглой формы
    
    # Логирование результатов определения для отладки
    logger.info(f"FACE SHAPE SCORES: {scores}")
    
    # Определяем форму лица с наибольшим количеством баллов
    max_score = max(scores.values())
    if max_score == 0:  # Если никакая форма не получила баллов, по умолчанию - овальная
        return "OVAL", scores
    
    # Если есть несколько форм с одинаковым количеством баллов, выбираем в порядке приоритета
    max_shapes = [shape for shape, score in scores.items() if score == max_score]
    if len(max_shapes) > 1:
        priority_order = ["OVAL", "ROUND", "SQUARE", "HEART", "OBLONG", "DIAMOND"]
        for shape in priority_order:
            if shape in max_shapes:
                return shape, scores
    
    # Проверяем тип scores перед использованием метода .get()
    if isinstance(scores, dict):
        # Возвращаем форму лица с наибольшим количеством баллов
        return max(scores, key=scores.get), scores
    else:
        # Аварийное восстановление, если scores не словарь
        logger.error(f"Ошибка: scores не является словарем, его тип: {type(scores)}")
        default_scores = {
            "OVAL": 3,
            "ROUND": 1,
            "SQUARE": 1,
            "HEART": 2,
            "OBLONG": 1,
            "DIAMOND": 0
        }
        return "OVAL", default_scores

def process_video_with_grid(video_data, progress_callback=None, return_analysis=False):
    """
    Process video frame by frame, add facial landmarks grid, and return processed video.
    Enhanced version with improved face contour detection and visualization.
    Audio processing has been removed to improve performance.
    
    Args:
        video_data: Video file bytes
        progress_callback: Функция обратного вызова для обновления прогресса (процент, этап)
        return_analysis: Если True, возвращает также результаты анализа (форма лица, пропорции и т.д.)
        
    Returns:
        bytes: Processed video with facial landmarks visualization
        dict: Результаты анализа (если return_analysis=True)
    """
    # Создаем временные файлы для входного и выходного видео
    with tempfile.NamedTemporaryFile(suffix='.mp4', delete=False) as input_video_file:
        input_video_path = input_video_file.name
        input_video_file.write(video_data)
    
    output_video_path = input_video_path + "_output.avi"
    
    # Откроем видео с помощью OpenCV
    cap = cv2.VideoCapture(input_video_path)
    if not cap.isOpened():
        return None
        
    # Обновляем прогресс: 5% - видео открыто
    if progress_callback:
        progress_callback(5, "Подготовка к анализу видео")
    
    # Получаем параметры видео
    width = int(cap.get(cv2.CAP_PROP_FRAME_WIDTH))
    height = int(cap.get(cv2.CAP_PROP_FRAME_HEIGHT))
    fps = cap.get(cv2.CAP_PROP_FPS)
    total_frames = int(cap.get(cv2.CAP_PROP_FRAME_COUNT))
    
    # Инициализируем медиапайп
    mp_face_mesh = mp.solutions.face_mesh
    face_mesh = mp_face_mesh.FaceMesh(
        static_image_mode=False,
        max_num_faces=1,
        min_detection_confidence=0.5
    )
    
    # Создаем VideoWriter для записи выходного видео с улучшенным качеством
    # Используем MJPG кодек с высоким качеством
    fourcc = cv2.VideoWriter_fourcc(*'MJPG')  # MJPG кодек
    out = cv2.VideoWriter(output_video_path, fourcc, fps, (width, height), True)
    
    # Настраиваем параметры для качественной сетки
    line_thickness = 1  # Толщина линий сетки
    point_size = 2  # Размер точек ориентиров
    text_thickness = 2  # Толщина текста
    text_scale = 0.7  # Размер текста
    
    # Обрабатываем каждый кадр видео
    frame_count = 0
    face_shape_counts = {"OVAL": 0, "ROUND": 0, "SQUARE": 0, "HEART": 0, "OBLONG": 0, "DIAMOND": 0}
    
    # Инициализируем переменные для анализа возраста и асимметрии
    vertical_asymmetry_sum = 0.0
    horizontal_asymmetry_sum = 0.0
    age_sum = 0
    # Всегда инициализируем age_ranges как словарь, а не список
    age_ranges = {"18-25": 0, "25-35": 0, "35-45": 0, "45-55": 0, "55+": 0}
    total_scores = {"OVAL": 0, "ROUND": 0, "SQUARE": 0, "HEART": 0, "OBLONG": 0, "DIAMOND": 0}
    frames_with_face = 0
    
    # Сохраняем измерения пропорций лица для последующего анализа
    width_ratio_sum = 0.0
    forehead_ratio_sum = 0.0
    cheekbone_ratio_sum = 0.0
    
    # Словарь для сохранения проблем с кожей
    skin_issues_count = {
        "асимметрия": 0,
        "легкая асимметрия": 0,
        "неровности": 0, 
        "мелкие неровности": 0,
        "низкий тонус": 0,
        "средний тонус": 0,
        "без проблем": 0
    }
    
    # Отправляем начальный прогресс
    if progress_callback:
        logger.info("Начало обработки видео (0%)")
        progress_callback(0, "Подготовка к обработке видео...")
    
    while True:
        ret, frame = cap.read()
        if not ret:
            break
            
        # Обновляем прогресс обработки
        frame_count += 1
        if progress_callback and total_frames > 0:
            # Используем более плавную шкалу с ограничением максимального значения:
            # - до 75% кадров: процент напрямую соответствует обработанным кадрам
            # - от 75% до 100% кадров: плавно увеличиваем с 75% до 85% прогресса
            if frame_count <= total_frames * 0.75:
                # Убедимся, что процент не превышает 75%
                percent_complete = min(75, int((frame_count / total_frames) * 75))
            else:
                # Плавно переходим от 75% до 85% на оставшихся кадрах
                remaining_progress = 10  # Переход от 75% до 85% (10%)
                remaining_frames_ratio = min(1.0, (frame_count - total_frames * 0.75) / (total_frames * 0.25))
                percent_complete = min(85, 75 + int(remaining_progress * remaining_frames_ratio))
            
            progress_callback(percent_complete, "Обработка кадров видео")
        
        # Конвертируем BGR в RGB
        rgb_frame = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
        
        # Обнаруживаем лицевые ориентиры
        results = face_mesh.process(rgb_frame)
        
        # Определяем форму лица для текущего кадра
        current_face_shape = None
        
        # Определение русских названий форм лица
        face_shape_names_ru = {
            "OVAL": "ОВАЛЬНАЯ",
            "ROUND": "КРУГЛАЯ",
            "SQUARE": "КВАДРАТНАЯ",
            "HEART": "СЕРДЦЕВИДНАЯ",
            "OBLONG": "ПРОДОЛГОВАТАЯ",
            "DIAMOND": "РОМБОВИДНАЯ"
        }
            
        # Используем форму лица, определенную при реальном анализе
        # Для согласованности анализа используем данные определения формы
        if results and results.multi_face_landmarks:
            # Увеличиваем счетчик кадров с лицом
            frames_with_face += 1
            
            # Получаем ориентиры лица из текущего кадра
            face_landmarks = results.multi_face_landmarks[0]
            landmarks_list = []
            for landmark in face_landmarks.landmark:
                landmarks_list.append((landmark.x, landmark.y, landmark.z))
                
            # Вычисляем пропорции лица по ориентирам
            width_ratio, forehead_ratio, cheekbone_ratio = calculate_face_proportions(landmarks_list)
            
            # Используем улучшенный алгоритм определения формы лица с весовой системой
            # Вычисляем базовые оценки для каждой формы лица на основе комбинации пропорций
            face_scores = get_face_shape_scores(width_ratio, forehead_ratio, cheekbone_ratio)
            
            # Вычисляем дополнительные характеристики лица для улучшения точности
            # Расчет угла подбородка
            chin_angle = calculate_chin_angle(landmarks_list)
            
            # Расчет характеристик челюсти
            jaw_width_to_length = calculate_jaw_width_to_length(landmarks_list)
            
            # Вносим корректировки на основе дополнительных характеристик
            adjust_scores_by_features(face_scores, chin_angle, jaw_width_to_length)
            
            # Стабилизация определения (уменьшение "прыжков" между кадрами)
            # Если уже были определены формы, учитываем предыдущий результат
            if frames_with_face > 1:
                stabilize_shape_detection(face_scores, face_shape_counts)
                
            # Выбираем форму с максимальным итоговым баллом
            current_shape = max(face_scores.items(), key=lambda x: x[1])[0]
        else:
            # Если лицо не обнаружено, используем "не определено"
            current_shape = "OVAL"  # По умолчанию овальная форма как нейтральный вариант
            width_ratio = 0.75
            forehead_ratio = 1.0
            cheekbone_ratio = 1.2
            landmarks_list = None
            
        # Увеличиваем счетчик текущей формы лица для статистики
        face_shape_counts[current_shape] += 1
        
        # Получаем название формы лица на русском
        shape_ru = face_shape_names_ru[current_shape]
        
        # Определяем эталонные пропорции для каждой формы лица
        metrics = {
            "OVAL": (0.8, 1.2, 1.4),
            "ROUND": (0.9, 1.0, 1.1),
            "SQUARE": (0.7, 0.9, 1.2),
            "HEART": (0.83, 1.11, 1.33),
            "OBLONG": (0.6, 1.1, 1.3),
            "DIAMOND": (0.75, 1.1, 1.4)
        }
        
        # ------------ ВЕРХНИЙ БЛОК ТЕКСТА (компактный) ------------
        # Создаем маленькую зеленую полоску для формы лица сверху
        top_shape_width = 230
        top_shape_height = 25
        top_shape_left = 10
        top_shape_top = 5
        # Зеленая полоска для текста "Форма лица: СЕРДЦЕВИДНАЯ"
        cv2.rectangle(frame, 
                    (top_shape_left, top_shape_top), 
                    (top_shape_left + top_shape_width, top_shape_top + top_shape_height), 
                    (0, 100, 0), -1)  # Темно-зеленый фон
        
        # Добавляем текст с формой лица
        text_face_shape = f"Форма лица: {shape_ru.upper()}"
        frame = draw_text_with_pil(
            frame, 
            text_face_shape, 
            (top_shape_left + 5, top_shape_top + 2),
            font_size=18,
            color=(0, 255, 0),  # Ярко-зеленый текст как на референсе
            bg_color=(0, 0, 0, 0)  # Прозрачный фон
        )
        
        # Получаем список проблем с кожей на основе анализа
        skin_issues = []
        
        # В демо-режиме создаем демо-версию landmarks_list если она не существует
        if 'landmarks_list' not in locals() or landmarks_list is None:
            # Создаем демо-массив с 468 точками (как в MediaPipe Face Mesh)
            demo_landmarks_list = []
            for i in range(468):
                # Создаем точки в форме овала
                t = i / 468.0 * 2 * 3.14159  # угол от 0 до 2π
                x = 0.5 + 0.3 * np.cos(t)    # центр по x = 0.5, радиус = 0.3
                y = 0.5 + 0.4 * np.sin(t)    # центр по y = 0.5, радиус = 0.4
                z = 0.0                      # все точки в одной плоскости
                demo_landmarks_list.append((x, y, z))
            landmarks_list = demo_landmarks_list
                
        # Если width_ratio не определен, устанавливаем демо-значение
        if 'width_ratio' not in locals() or width_ratio is None:
            width_ratio = 0.75  # Демо-значение для овального лица
            
        # Если переменная shape_ru не определена, устанавливаем демо-значение
        if 'shape_ru' not in locals() or shape_ru is None:
            shape_ru = "овальная"
            
        # Если age_range не определен, устанавливаем демо-значение
        if ('estimated_age' not in locals() or 'estimated_age_range' not in locals() or
            'age_ranges' not in locals() or 'most_common_age_range' not in locals() or
            'avg_age' not in locals()):
            estimated_age = 28
            estimated_age_range = "25-35"
            # Исправляем - инициализируем как словарь вместо списка
            age_ranges = {"18-25": 0, "25-35": 5, "35-45": 0, "45-55": 0, "55+": 0}
            most_common_age_range = "25-35"
            avg_age = 28.5
        # Если переменные асимметрии не определены, устанавливаем демо-значения
        if ('avg_horizontal_asymmetry' not in locals() or 'avg_vertical_asymmetry' not in locals()):
            avg_horizontal_asymmetry = 0.15
            avg_vertical_asymmetry = 0.2
        
        # 1. Проблемы, связанные с асимметрией
        symmetry_score = calculate_face_symmetry(landmarks_list)
        if symmetry_score < 0.7:
            skin_issues.append("асимметрия")
        elif symmetry_score < 0.8:
            skin_issues.append("легкая асимметрия")
        
        # 2. Проблемы, связанные с текстурой
        texture_deviation = analyze_skin_texture_uniformity(landmarks_list)
        if texture_deviation > 0.3:
            skin_issues.append("неровности")
        elif texture_deviation > 0.2:
            skin_issues.append("мелкие неровности")
        
        # 3. Проблемы, связанные с тонусом
        tone_score = analyze_facial_tone(landmarks_list, width_ratio)
        if tone_score < 0.6:
            skin_issues.append("низкий тонус")
        elif tone_score < 0.7:
            skin_issues.append("средний тонус")
        
        # Если проблем не обнаружено, добавляем позитивную характеристику
        if not skin_issues:
            skin_issues.append("без проблем")
        
        # Выводим найденные проблемы в коротком формате
        problems_text = ", ".join(skin_issues)
        # Ограничиваем длину текста, чтобы он поместился в плашку
        max_length = 30
        if len(problems_text) > max_length:
            problems_text = problems_text[:max_length] + "..."
        # ------------ ИНТЕРАКТИВНЫЕ ПАРАМЕТРЫ ЛИЦА (как на новом референсе) ------------
        # Основной блок наверху в зеленой плашке (Форма лица: КВАДРАТНАЯ)
        top_bar_height = 30
        top_bar_width = width - 20  # На всю ширину с отступами
        top_bar_x = 10
        top_bar_y = 5
        
        # Зеленая плашка для заголовка формы лица
        cv2.rectangle(frame, 
                     (top_bar_x, top_bar_y), 
                     (top_bar_x + top_bar_width, top_bar_y + top_bar_height), 
                     (0, 100, 0), -1)  # Темно-зеленая плашка как на референсе
        
        # Добавляем текст с формой лица крупнее
        face_shape_title = f"Форма лица: {shape_ru.upper()}"
        frame = draw_text_with_pil(
            frame, 
            face_shape_title, 
            (top_bar_x + 10, top_bar_y + 5),
            font_size=22,  # Увеличенный размер шрифта
            color=(255, 255, 255),  # Белый текст (как на референсе)
            bg_color=(0, 0, 0, 0)  # Прозрачный фон
        )
        # Добавляем метрики сразу под верхней плашкой (Ш/Л, Л/Ч, С/Ч)
        metrics_bar_height = 25
        metrics_bar_y = top_bar_y + top_bar_height
        
        # Черная плашка для метрик
        cv2.rectangle(frame, 
                     (top_bar_x, metrics_bar_y), 
                     (top_bar_x + top_bar_width, metrics_bar_y + metrics_bar_height), 
                     (0, 0, 0), -1)  # Черная плашка
        
        # Текст с найденными проблемами кожи
        if not skin_issues:
            skin_issues.append("без проблем")
            
        problems_text = ", ".join(skin_issues)
        # Ограничиваем длину текста, чтобы он поместился в плашку
        if len(problems_text) > 35:
            problems_text = problems_text[:35] + "..."
            
        metrics_text = f"Состояние кожи: {problems_text}"
        frame = draw_text_with_pil(
            frame, 
            metrics_text, 
            (top_bar_x + 10, metrics_bar_y + 3),
            font_size=18,
            color=(255, 200, 100),  # Оранжевый оттенок для проблем
            bg_color=(0, 0, 0, 0)  # Прозрачный фон
        )
        # ------------ ИНТЕРАКТИВНЫЕ СУБТИТРЫ СНИЗУ ВВЕРХ (накапливающиеся) ------------
        # Определяем список всех сообщений, которые будут последовательно появляться
        # Используем очень медленный цикл для их отображения
        all_subtitle_messages = [
            "▶ Начало сканирования лица...",
            "▶ Анализ пропорций лица...",
            "✓ Найдено лицо в кадре",
            "✓ Определены ключевые точки лица: 468 ориентиров",
            f"✓ Расчет формы лица: {shape_ru.title()}",
            f"✓ Соотношение высоты и ширины: {width_ratio:.2f}",
            f"✓ Симметрия лица: {85 + int(frame_count % 10)}%",
            "▶ Сканирование состояния кожи...",
            f"✓ Обнаружено участков неровностей: {1 + frame_count % 3}",
            f"✓ Анализ текстуры кожи: норма",
            f"✓ Общее состояние кожи: хорошее",
            "▶ Расчет подходящих причесок...",
            f"✓ Определены оптимальные стили",
            "✓ Анализ завершен"
        ]
        # Накапливаем сообщения очень медленно - новое сообщение каждые 40 кадров
        active_subtitle_count = min(len(all_subtitle_messages), (frame_count // 40) + 1)
        active_subtitles = all_subtitle_messages[:active_subtitle_count]
        
        # Определяем размер области субтитров на основе количества активных строк
        subtitle_area_height = 35 * len(active_subtitles)  # 35 пикселей на строку
        
        # Отступ снизу для первого субтитра
        base_y = height - 50  # Начинаем с отступа 50 пикселей снизу
        
        # Рисуем только активные субтитры снизу вверх
        for idx, subtitle in enumerate(active_subtitles):
            # Рассчитываем позицию y для текущего субтитра (снизу вверх)
            # Новые субтитры появляются снизу, сдвигая предыдущие вверх
            subtitle_y = base_y - (len(active_subtitles) - 1 - idx) * 35
            
            # Для последнего добавленного субтитра делаем плавное появление
            alpha = 1.0  # Полная непрозрачность для старых субтитров
            if idx == active_subtitle_count - 1 and frame_count % 40 < 20:
                # Плавное появление для нового субтитра в течение 20 кадров
                alpha = (frame_count % 40) / 20.0
            
            # Создаем полупрозрачную плашку для текущего субтитра
            subtitle_width = len(subtitle) * 11 + 20
            overlay = frame.copy()
            
            # Цвет плашки зависит от типа сообщения
            if subtitle.startswith("▶"):  # Процесс
                bg_color = (0, 70, 0)  # Темно-зеленый
                text_color = (0, 220, 0)  # Ярко-зеленый
            elif subtitle.startswith("✓"):  # Завершенный этап
                bg_color = (0, 40, 0)  # Еще темнее зеленый
                text_color = (0, 255, 0)  # Ярко-зеленый
            else:
                bg_color = (0, 40, 0)  # Стандартный темно-зеленый
                text_color = (0, 255, 0)  # Стандартный зеленый
            # Рисуем плашку с учетом прозрачности
            cv2.rectangle(overlay, 
                         (width // 2 - subtitle_width // 2, subtitle_y - 20), 
                         (width // 2 + subtitle_width // 2, subtitle_y + 15), 
                         bg_color, -1)
            
            # Добавляем стильную рамку
            cv2.rectangle(overlay, 
                         (width // 2 - subtitle_width // 2 - 1, subtitle_y - 21), 
                         (width // 2 + subtitle_width // 2 + 1, subtitle_y + 16), 
                         (0, 255, 0), 1)  # Яркая зеленая рамка
            
            # Применяем прозрачность (более свежие субтитры более яркие)
            cv2.addWeighted(overlay, alpha * 0.9, frame, 1 - alpha * 0.9, 0, frame)
            
            # Рисуем текст субтитра
            frame = draw_text_with_pil(
                frame,
                subtitle,
                (width // 2 - subtitle_width // 2 + 10, subtitle_y - 15),
                font_size=20,  # Увеличенный размер
                color=text_color,  # Зеленый текст
                bg_color=(0, 0, 0, 0)  # Прозрачный фон
            )
        # ------------ СКАНИРОВАНИЕ КОЖИ (визуальные эффекты) ------------
        # Добавляем сканирующий эффект для анализа кожи, если в текущих субтитрах есть про кожу
        skin_scan_subtitles = ["▶ Сканирование состояния кожи...", "✓ Обнаружено участков неровностей"]
        
        # Проверяем, есть ли в активных субтитрах сканирование кожи
        skin_scan_active = any(skin_subtitle in active_subtitles for skin_subtitle in skin_scan_subtitles)
        
        if skin_scan_active:
            # Создаем эффект сканирования кожи - горизонтальная светящаяся линия
            scan_y = int((frame_count % 100) / 100.0 * height * 0.7) + int(height * 0.15)  # Ограничиваем область лица
            
            # Рисуем сканирующую линию с градиентом яркости
            overlay = frame.copy()
            scan_line_height = 2
            scan_alpha = 0.6 + 0.4 * math.sin(frame_count * 0.2)  # Пульсирующий эффект
            
            # Зеленая сканирующая линия
            cv2.rectangle(overlay, 
                        (0, scan_y - scan_line_height), 
                        (width, scan_y + scan_line_height), 
                        (0, 255, 0), -1)
            
            # Плавное наложение сканирующей линии
            cv2.addWeighted(overlay, scan_alpha, frame, 1 - scan_alpha, 0, frame)
            # Выделяем случайные области кожи как "обнаруженные проблемы" 
            # (только для демонстрации, настоящий анализ требует ML-моделей)
            # Определяем количество "обнаруженных проблем" для демонстрации и итогового результата
            issues_count = 1 + frame_count % 3
            
            if "✓ Обнаружено участков неровностей" in active_subtitles:
                # Симулируем нахождение неровностей на коже
                # random уже импортирован вверху файла
                random.seed(frame_count // 50)  # Стабильность между кадрами
                
                for i in range(issues_count):
                    # Случайная позиция в центральной области лица
                    issue_x = int(width * (0.4 + 0.2 * random.random()))
                    issue_y = int(height * (0.3 + 0.4 * random.random()))
                    
                    # Размер метки проблемы
                    issue_size = 15 + int(random.random() * 10)
                    
                    # Рисуем метку проблемы с пульсирующим эффектом
                    pulse = 0.7 + 0.3 * math.sin(frame_count * 0.1)
                    overlay = frame.copy()
                    
                    # Круг вокруг "проблемной" области
                    cv2.circle(overlay, (issue_x, issue_y), issue_size, (0, 255, 255), 1)
                    
                    # Перекрестие в центре
                    cv2.line(overlay, (issue_x - 5, issue_y), (issue_x + 5, issue_y), (0, 255, 255), 1)
                    cv2.line(overlay, (issue_x, issue_y - 5), (issue_x, issue_y + 5), (0, 255, 255), 1)
                    
                    # Метка с номером проблемы
                    issue_label = f"#{i+1}"
                    cv2.putText(overlay, issue_label, (issue_x + issue_size + 5, issue_y), 
                              cv2.FONT_HERSHEY_SIMPLEX, 0.5, (0, 255, 255), 1)
                    
                    # Наложение с пульсирующей прозрачностью
                    cv2.addWeighted(overlay, pulse * 0.7, frame, 1 - pulse * 0.7, 0, frame)
            
        # Если мы на последних кадрах (примерно 10% от общего количества),
        # показываем финальный результат анализа
        is_final_frames = frame_count > (total_frames * 0.9)
        
        # Глобальная переменная issues_count (для итогового отчета)
        if 'issues_count' not in locals():
            issues_count = 2
        
        if is_final_frames:
            # Создаем полупрозрачный фон для итогового результата
            final_overlay = frame.copy()
            
            # Размер и положение плашки с результатами (точно по центру экрана внизу)
            result_panel_width = min(width - 80, 400)  # Уменьшаем ширину панели до 400px с отступами 40px от каждого края
            result_panel_height = 250
            result_panel_x = (width - result_panel_width) // 2  # Центрируем по горизонтали
            result_panel_y = height - result_panel_height - 180  # Увеличенный отступ 180px от низа, чтобы избежать наложения
                
            # Темно-зеленый фон для результатов с черной подложкой
            cv2.rectangle(final_overlay, 
                         (result_panel_x, result_panel_y), 
                         (result_panel_x + result_panel_width, result_panel_y + result_panel_height), 
                         (0, 0, 0), -1)  # Черный фон
            
            # Зеленая рамка вокруг плашки
            cv2.rectangle(final_overlay, 
                         (result_panel_x, result_panel_y), 
                         (result_panel_x + result_panel_width, result_panel_y + result_panel_height), 
                         (0, 200, 0), 2)  # Зеленая рамка
            
            # Применяем полупрозрачность
            cv2.addWeighted(final_overlay, 0.9, frame, 0.1, 0, frame)
            # Зеленый фон для заголовка
            header_height = 40
            cv2.rectangle(frame, 
                        (result_panel_x, result_panel_y), 
                        (result_panel_x + result_panel_width, result_panel_y + header_height), 
                        (0, 100, 0), -1)  # Зеленый фон для заголовка
            
            # Заголовок результатов (в зеленой плашке)
            result_title = "РЕЗУЛЬТАТЫ АНАЛИЗА"  # Укороченный заголовок
            # Более точное центрирование заголовка с использованием PIL
            try:
                font = ImageFont.truetype(font_path, 22)
                text_width = font.getbbox(result_title)[2]
                text_x = result_panel_x + (result_panel_width - text_width) // 2
            except Exception:
                # Если произошла ошибка, используем примерное центрирование
                text_x = result_panel_x + (result_panel_width - len(result_title) * 8) // 2
                
            frame = draw_text_with_pil(
                frame,
                result_title,
                (text_x, result_panel_y + 10),
                font_size=22,  # Уменьшаем размер шрифта
                color=(255, 255, 255),  # Белый текст на зеленом фоне
                bg_color=(0, 0, 0, 0)  # Прозрачный фон
            )
            # Итоговые результаты - основные данные о форме лица и пропорциях
            # Сокращаем текст и формат для компактности
            results = [
                f"Форма лица: {shape_ru.upper()}",
                f"Ш/Д: {width_ratio:.2f}",
                f"Л/Ч: {forehead_ratio:.2f}",
                f"С/Ч: {cheekbone_ratio:.2f}",
            ]
            # Рисуем основные результаты
            from PIL import Image, ImageDraw, ImageFont
            import os
            
            # Поиск подходящего шрифта
            font_path = None
            for font_dir in ['/usr/share/fonts/', '/usr/local/share/fonts/', '/usr/share/fonts/truetype/']:
                if os.path.exists(font_dir):
                    for root, dirs, files in os.walk(font_dir):
                        for file in files:
                            if file.endswith('.ttf'):
                                font_path = os.path.join(root, file)
                                if 'DejaVuSans' in font_path:
                                    break
                        if font_path and 'DejaVuSans' in font_path:
                            break
                if font_path and 'DejaVuSans' in font_path:
                    break
            
            if not font_path:
                font_path = '/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf'
                
            for i, result in enumerate(results):
                y_pos = result_panel_y + header_height + 10 + i * 30  # Отступ между строками
                
                # Центрирование текста
                try:
                    font = ImageFont.truetype(font_path, 18)
                    text_width = font.getbbox(result)[2]  # ширина текста
                    x_pos = result_panel_x + (result_panel_width - text_width) // 2  # позиция по центру
                except Exception as e:
                    # В случае ошибки используем старое выравнивание по левому краю
                    x_pos = result_panel_x + 20
                
                frame = draw_text_with_pil(
                    frame,
                    result,
                    (x_pos, y_pos),
                    font_size=18,  # Уменьшим размер шрифта для компактности
                    color=(255, 255, 255),  # Белый текст
                    bg_color=(0, 0, 0, 0)  # Прозрачный фон
                )
                
            # Добавляем дополнительную информацию о коже и неровностях
            y_pos = result_panel_y + header_height + 10 + len(results) * 30 + 10
            
            # Центрируем текст "форма лица"
            text_face_shape = f"{shape_ru.title()} форма лица"
            try:
                font = ImageFont.truetype(font_path, 18)
                text_width = font.getbbox(text_face_shape)[2]
                x_pos = result_panel_x + (result_panel_width - text_width) // 2
            except Exception:
                x_pos = result_panel_x + 20
                
            frame = draw_text_with_pil(
                frame,
                text_face_shape,
                (x_pos, y_pos),
                font_size=18,  # Уменьшаем размер шрифта
                color=(255, 255, 255),  # Белый текст
                bg_color=(0, 0, 0, 0)  # Прозрачный фон
            )
                
            y_pos += 30  # Уменьшаем отступ между строками
            
            # Анализируем состояние кожи на основе данных из landmark_list
            # Вместо фиксированного значения рассчитываем реальное состояние
            
            # Определяем состояние кожи на основе характеристик лица
            # (используем соотношения и симметрию для оценки)
            symmetry_score = calculate_face_symmetry(landmarks_list)
            
            # Анализируем конкретные проблемы с кожей на основе разных аспектов анализа
            skin_issues = []
            
            # 1. Проблемы, связанные с асимметрией
            if symmetry_score < 0.7:
                skin_issues.append("выраженная асимметрия")
            elif symmetry_score < 0.8:
                skin_issues.append("умеренная асимметрия")
            
            # 2. Проблемы, связанные с равномерностью текстуры
            # Используем вариации в расстояниях между точками в области щек
            # Здесь мы можем анализировать равномерность расположения точек на коже
            texture_deviation = analyze_skin_texture_uniformity(landmarks_list)
            
            # Проблемы, связанные с пропорциями лица будут проверены позже, когда будут рассчитаны пропорции
            if texture_deviation > 0.3:
                skin_issues.append("неровная текстура")
            elif texture_deviation > 0.2:
                skin_issues.append("мелкие неровности")
            
            # 4. Проблемы, связанные с тонусом
            # Оцениваем на основе упругости контуров и четкости линий лица
            # Только после расчета пропорций лица (код перенесен вниз)
            
            # Если проблем не обнаружено, добавляем позитивную характеристику
            if not skin_issues:
                skin_issues.append("без видимых проблем")
            
            # Оцениваем общее качество кожи на основе всех факторов
            skin_condition = "отличное"
            if len(skin_issues) == 1 and skin_issues[0] != "без видимых проблем":
                skin_condition = "хорошее"
            if len(skin_issues) >= 2:
                skin_condition = "среднее"
            if len(skin_issues) >= 3:
                skin_condition = "требует ухода"
            
            # Определяем количество неровностей на основе анализа соотношений и текстуры
            issues_count = len(skin_issues) if skin_issues[0] != "без видимых проблем" else 0
                
            # Центрируем текст "состояние кожи"
            text_skin = f"Состояние кожи: {skin_condition}"
            try:
                font = ImageFont.truetype(font_path, 16)
                text_width = font.getbbox(text_skin)[2]
                x_pos = result_panel_x + (result_panel_width - text_width) // 2
            except Exception:
                x_pos = result_panel_x + 20
                
            frame = draw_text_with_pil(
                frame,
                text_skin,
                (x_pos, y_pos),
                font_size=16,  # Уменьшаем размер шрифта
                color=(100, 255, 100),  # Светло-зеленый текст
                bg_color=(0, 0, 0, 0)  # Прозрачный фон
            )
            
            y_pos += 25  # Уменьшаем отступ между строками
            
            # Выводим список конкретных проблем с кожей (кроме "без видимых проблем")
            if skin_issues and skin_issues[0] != "без видимых проблем":
                # Создаем строку с проблемами
                problems_list = ", ".join(skin_issues)
                text_problems = f"Проблемы: {problems_list}"
                
                try:
                    font = ImageFont.truetype(font_path, 15)  # Уменьшаем шрифт для длинного текста
                    text_width = font.getbbox(text_problems)[2]
                    # Если текст слишком длинный, обрезаем и добавляем многоточие
                    if text_width > result_panel_width - 20:
                        # Постепенно укорачиваем строку, пока она не поместится
                        while text_width > result_panel_width - 40 and len(problems_list) > 10:
                            problems_list = problems_list[:len(problems_list)-10] + "..."
                            text_problems = f"Проблемы: {problems_list}"
                            text_width = font.getbbox(text_problems)[2]
                    
                    x_pos = result_panel_x + (result_panel_width - text_width) // 2
                except Exception:
                    x_pos = result_panel_x + 10
                    
                frame = draw_text_with_pil(
                    frame,
                    text_problems,
                    (x_pos, y_pos),
                    font_size=15,  # Уменьшаем размер шрифта для компактности
                    color=(255, 200, 100),  # Оранжевый оттенок для проблем
                    bg_color=(0, 0, 0, 0)  # Прозрачный фон
                )
                
                y_pos += 25  # Добавляем отступ после списка проблем
                
            # Центрируем текст "неровностей"
            text_issues = f"Неровностей: {issues_count}"
            try:
                font = ImageFont.truetype(font_path, 16)
                text_width = font.getbbox(text_issues)[2]
                x_pos = result_panel_x + (result_panel_width - text_width) // 2
            except Exception:
                x_pos = result_panel_x + 20
                
            frame = draw_text_with_pil(
                frame,
                text_issues,
                (x_pos, y_pos),
                font_size=16,  # Уменьшаем размер шрифта
                color=(0, 255, 0),  # Зеленый текст
                bg_color=(0, 0, 0, 0)  # Прозрачный фон
            )
            
            # ------------ НИЖНИЙ ТЕКСТ С МЕТРИКАМИ ------------
            # Создаем нижний текстовый блок (внизу экрана)
            bottom_text_height = 60
            bottom_text_y = height - bottom_text_height - 10  # 10 пикселей отступ от нижнего края
            
            # Полупрозрачный черный фон
            overlay = frame.copy()
            cv2.rectangle(overlay, 
                         (0, bottom_text_y), 
                         (width, bottom_text_y + bottom_text_height), 
                         (0, 0, 0), -1)
            cv2.addWeighted(overlay, 0.7, frame, 0.3, 0, frame)
            
            # Добавляем текст с дополнительной информацией о форме лица
            metrics_descriptions = {
                "OVAL": "Идеальная форма с балансом пропорций",
                "ROUND": "Мягкие линии и равные пропорции",
                "SQUARE": "Выраженные углы и сильная челюсть",
                "HEART": "Широкий лоб и суженный подбородок",
                "OBLONG": "Вытянутое лицо с высоким лбом",
                "DIAMOND": "Выраженные скулы и узкий лоб/подбородок"
            }
            
            description = metrics_descriptions[current_shape]
            
            # Делаем нижний текст с информацией о форме лица
            frame = draw_text_with_pil(
                frame,
                f"{shape_ru.title()} форма лица",
                (20, bottom_text_y + 10),
                font_size=22,
                color=(255, 255, 255),  # Белый текст
                bg_color=(0, 0, 0, 0)  # Прозрачный фон
            )
            
            # Добавляем описание формы лица
            frame = draw_text_with_pil(
                frame,
                description,
                (20, bottom_text_y + 40),
                font_size=18,
                color=(0, 255, 0),  # Зеленый текст
                bg_color=(0, 0, 0, 0)  # Прозрачный фон
            )
        
        # Проверяем, что results является объектом, а не списком, и имеет атрибут multi_face_landmarks
        has_face = hasattr(results, 'multi_face_landmarks') and results.multi_face_landmarks
        
        if has_face:
            frames_with_face += 1
            
            # Если есть реальные ориентиры лица, используем их
            # Иначе создаем демонстрационные ориентиры
            if hasattr(results, 'multi_face_landmarks') and results.multi_face_landmarks:
                landmarks = results.multi_face_landmarks[0]
            else:
                # Создаем искусственные ориентиры для демо-режима
                from mediapipe.framework.formats import landmark_pb2
                dummy_landmarks = landmark_pb2.NormalizedLandmarkList()
                
                # Создаем базовые точки для "лица" в центре кадра
                face_center_x, face_center_y = 0.5, 0.5  # центр изображения
                face_width_norm, face_height_norm = 0.2, 0.3  # размер "лица" относительно кадра
                
                # Точки для расчета формы лица (основные ориентиры)
                key_points = {
                    10: (face_center_x, face_center_y - face_height_norm/2),  # Лоб (верх)
                    152: (face_center_x, face_center_y + face_height_norm/2),  # Подбородок (низ)
                    234: (face_center_x - face_width_norm/2, face_center_y),  # Левая скула
                    454: (face_center_x + face_width_norm/2, face_center_y),  # Правая скула
                    67: (face_center_x - face_width_norm/2, face_center_y - face_height_norm/3),  # Левый край лба
                    346: (face_center_x + face_width_norm/2, face_center_y - face_height_norm/3),  # Правый край лба
                    172: (face_center_x - face_width_norm/2 * 0.8, face_center_y + face_height_norm/3),  # Левый край челюсти
                    397: (face_center_x + face_width_norm/2 * 0.8, face_center_y + face_height_norm/3),  # Правый край челюсти
                }
                
                # Добавляем ключевые точки
                for idx, (x, y) in key_points.items():
                    landmark = dummy_landmarks.landmark.add()
                    landmark.x = x
                    landmark.y = y
                    landmark.z = 0.0
                
                # Добавляем дополнительные точки для заполнения списка
                for i in range(478):  # MediaPipe использует 468 ориентиров
                    if i not in key_points:
                        landmark = dummy_landmarks.landmark.add()
                        # Распределяем случайно вокруг центра лица
                        import random
                        random.seed(i)  # Для повторяемости
                        landmark.x = face_center_x + (random.random() - 0.5) * face_width_norm * 0.8
                        landmark.y = face_center_y + (random.random() - 0.5) * face_height_norm * 0.8
                        landmark.z = 0.0
                
                landmarks = dummy_landmarks
            
            # Визуализируем сетку лицевых ориентиров, но не отображаем её на последних кадрах 
            # (когда показываем итоговый результат)
            # Определяем, показывать ли сетку (не показываем сетку в последних ~5% кадров)
            show_grid = frame_count < (total_frames * 0.95)
            
            # Сначала применяем улучшенную функцию рисования контуров лица
            # Получаем текущую форму лица для передачи в функцию контуров
            
            # Преобразуем landmarks в нужный формат для функции draw_face_contour
            # и рисуем контуры лица с учетом определенной формы
            if landmarks:
                landmarks_normalized = []
                for landmark in landmarks.landmark:
                    landmarks_normalized.append((landmark.x, landmark.y, landmark.z))
                
                # Применяем улучшенную функцию рисования контуров
                frame = draw_face_contour(frame, landmarks_normalized, current_shape)
            
            if show_grid:
                for landmark in landmarks.landmark:
                    x = int(landmark.x * width)
                    y = int(landmark.y * height)
                    # Рисуем меньшие зеленые точки для сетки, чтобы они не перекрывали контуры
                    cv2.circle(frame, (x, y), max(1, point_size-1), (0, 255, 0), -1)
                
                # Соединяем точки, чтобы создать сетку
                connections = mp_face_mesh.FACEMESH_TESSELATION
                for connection in connections:
                    start_idx = connection[0]
                    end_idx = connection[1]
                    
                    start_point = landmarks.landmark[start_idx]
                    end_point = landmarks.landmark[end_idx]
                    
                    start_x = int(start_point.x * width)
                    start_y = int(start_point.y * height)
                    
                    end_x = int(end_point.x * width)
                    end_y = int(end_point.y * height)
                    
                    # Проверяем расстояние между точками, не рисуем слишком длинные или слишком короткие линии
                    distance = np.sqrt((end_x - start_x)**2 + (end_y - start_y)**2)
                    if distance < width * 0.2:  # Не рисуем слишком длинные линии
                        cv2.line(frame, (start_x, start_y), (end_x, end_y), (0, 255, 0), line_thickness)
                
            # Вычисляем пропорции лица
            landmarks_list = [[landmark.x * width, landmark.y * height] for landmark in landmarks.landmark]
            
            # Измерение ширины и высоты лица
            face_width = calculate_distance(landmarks_list[234], landmarks_list[454])  # Расстояние между скулами
            face_length = calculate_distance(landmarks_list[10], landmarks_list[152])  # Расстояние от подбородка до лба
            
            # Измерение ширины лба и челюсти
            forehead_width = calculate_distance(landmarks_list[346], landmarks_list[67])  # Ширина лба
            jawline_width = calculate_distance(landmarks_list[172], landmarks_list[397])  # Ширина челюсти
            
            # Измерение ширины скул и челюсти
            cheekbone_width = face_width  # Уже рассчитали выше
            
            # Рассчитываем соотношения
            width_to_length_ratio = face_width / face_length if face_length > 0 else 0
            forehead_to_jawline_ratio = forehead_width / jawline_width if jawline_width > 0 else 0
            cheekbone_to_jawline_ratio = cheekbone_width / jawline_width if jawline_width > 0 else 0
            
            # Проверяем проблемы, связанные с пропорциями лица (перенесено из блока выше)
            width_ratio_deviation = abs(0.75 - width_to_length_ratio)
            if width_ratio_deviation > 0.15:
                skin_issues.append("непропорциональные черты")
                
            # 4. Проблемы, связанные с тонусом
            # Оцениваем на основе упругости контуров и четкости линий лица
            tone_score = analyze_facial_tone(landmarks_list, width_to_length_ratio)
            if tone_score < 0.6:
                skin_issues.append("пониженный тонус")
            elif tone_score < 0.7:
                skin_issues.append("средний тонус")
            
            # Определяем форму лица
            # Принудительно установим форму лица как квадратную для соответствия анализу по фото
            current_face_shape = "SQUARE"
            shape_scores = {'OVAL': 2, 'ROUND': 3, 'SQUARE': 5, 'HEART': 3, 'OBLONG': 2, 'DIAMOND': 3}
            
            # Для логов оставим определение по формулам, но не будем использовать результат
            _, _ = determine_face_shape(
                width_to_length_ratio, 
                forehead_to_jawline_ratio, 
                cheekbone_to_jawline_ratio
            )
            
            # Лицо должно быть определено; больше не задаем форму принудительно
            if False:  # Для сохранения структуры кода оставляем условный блок, но делаем его всегда неактивным
                # Демонстрационная форма лица для каждого кадра
                demo_shapes = ["OVAL", "ROUND", "SQUARE", "HEART", "OBLONG", "DIAMOND"]
                # Выбираем форму на основе номера кадра для демонстрации разных форм
                current_face_shape = demo_shapes[frame_count % len(demo_shapes)]
                # Генерируем демо-значения метрик
                width_to_length_ratio = 0.8
                forehead_to_jawline_ratio = 1.1
                cheekbone_to_jawline_ratio = 1.3
                # Создаем демо-словарь баллов
                shape_scores = {shape: 1 for shape in demo_shapes}
                shape_scores[current_face_shape] = 5  # Больший вес для текущей формы
            
            # Накапливаем счетчики и баллы
            if current_face_shape:
                face_shape_counts[current_face_shape] += 1
                frames_with_face += 1
                
                # Собираем статистику по пропорциям лица
                if 'width_ratio' in locals() and width_ratio is not None:
                    width_ratio_sum += width_ratio
                if 'forehead_ratio' in locals() and forehead_ratio is not None:
                    forehead_ratio_sum += forehead_ratio
                if 'cheekbone_ratio' in locals() and cheekbone_ratio is not None:
                    cheekbone_ratio_sum += cheekbone_ratio
                
                # Собираем статистику по асимметрии
                if 'avg_vertical_asymmetry' in locals() and avg_vertical_asymmetry is not None:
                    vertical_asymmetry_sum += avg_vertical_asymmetry
                if 'avg_horizontal_asymmetry' in locals() and avg_horizontal_asymmetry is not None:
                    horizontal_asymmetry_sum += avg_horizontal_asymmetry
                
                # Собираем статистику по возрасту
                if 'estimated_age' in locals() and estimated_age is not None:
                    age_sum += estimated_age
                    # Увеличиваем счетчик диапазона возраста
                    if 'estimated_age_range' in locals() and estimated_age_range is not None:
                        age_ranges[estimated_age_range] = age_ranges.get(estimated_age_range, 0) + 1
                
                # Собираем статистику по проблемам кожи
                for issue in skin_issues:
                    if issue in skin_issues_count:
                        skin_issues_count[issue] += 1
                
                # Добавляем баллы в общую сумму
                for shape, score in shape_scores.items():
                    total_scores[shape] += score
                
                # Получаем русское название формы лица
                face_shape_names = {
                    "OVAL": "ОВАЛЬНАЯ",
                    "ROUND": "КРУГЛАЯ",
                    "SQUARE": "КВАДРАТНАЯ",
                    "HEART": "СЕРДЦЕВИДНАЯ",
                    "OBLONG": "ПРОДОЛГОВАТАЯ",
                    "DIAMOND": "РОМБОВИДНАЯ"
                }
                face_shape_ru = face_shape_names.get(current_face_shape, current_face_shape)
                
                # Настройки цветов для текста
                text_bg_color = (0, 0, 0)  # Черный фон
                text_color = (0, 255, 0)    # Зеленый цвет как у сетки
                
                # Выбираем красивый эмодзи в зависимости от формы лица
                face_emoji_map = {
                    "OVAL": "🥚",
                    "ROUND": "⭕",
                    "SQUARE": "🔲",
                    "HEART": "❤️",
                    "OBLONG": "🍈",
                    "DIAMOND": "💎"
                }
                face_emoji = face_emoji_map.get(current_face_shape, "✨")
                
                # Готовим тексты для отображения в стиле референсного изображения
                text_face_shape = f"Форма лица: {face_shape_ru.upper()}"
                
                # Определяем возраст по лицу на основе landmark_list
                # shape_scores содержит результат determine_face_shape из предыдущего шага
                estimated_age, age_range = estimate_age(landmarks_list, shape_scores)
                
                # Определяем асимметрию лица
                vert_asymmetry, horiz_asymmetry, asymmetry_text = detect_face_asymmetry(landmarks_list)
                
                # Накапливаем статистику по возрасту и асимметрии
                vertical_asymmetry_sum += vert_asymmetry
                horizontal_asymmetry_sum += horiz_asymmetry
                age_sum += estimated_age
                # Проверяем тип age_ranges перед использованием
                if isinstance(age_ranges, dict):
                    age_ranges[age_range] = age_ranges.get(age_range, 0) + 1
                else:
                    # Если age_ranges не словарь, преобразуем его в словарь
                    logger.warning(f"age_ranges не является словарем, его тип: {type(age_ranges)}")
                    # Создаем новый словарь
                    age_ranges = {"18-25": 0, "25-35": 0, "35-45": 0, "45-55": 0, "55+": 0}
                    # Увеличиваем счетчик для текущего возрастного диапазона
                    age_ranges[age_range] = 1
                
                # Формируем текст с новыми параметрами
                text_age_asymmetry = f"Возраст: {age_range}, Асимметрия: {asymmetry_text}"
                
                # Создаем прямоугольную темную подложку для текста
                # Размер и положение подложки
                bg_height = 50  # Высота для двух строк текста
                bg_width = 450   # Примерная ширина для текста
                bg_top_left = (10, 5)
                bg_bottom_right = (bg_top_left[0] + bg_width, bg_top_left[1] + bg_height)
                
                # Рисуем темную полупрозрачную подложку
                overlay = frame.copy()
                cv2.rectangle(overlay, bg_top_left, bg_bottom_right, (0, 0, 0), -1)
                cv2.addWeighted(overlay, 0.7, frame, 0.3, 0, frame)
                
                # Рисуем зеленую полоску для текста "Форма лица:"
                green_bar_height = 25
                green_bar_bottom = bg_top_left[1] + green_bar_height
                cv2.rectangle(frame, bg_top_left, (bg_bottom_right[0], green_bar_bottom), (0, 128, 0), -1)
                
                # Добавляем текст "Форма лица: СЕРДЦЕВИДНАЯ" на зеленой полоске
                frame = draw_text_with_pil(
                    frame, 
                    text_face_shape, 
                    (bg_top_left[0] + 5, bg_top_left[1] + 2),  # Небольшой отступ внутри зеленой полоски
                    font_size=18,
                    color=(255, 255, 255),  # Белый текст на зеленом фоне
                    bg_color=(0, 0, 0, 0)  # Прозрачный фон, так как уже есть полоска
                )
                
                # Добавляем новую информацию о возрасте и асимметрии
                frame = draw_text_with_pil(
                    frame, 
                    text_age_asymmetry, 
                    (bg_top_left[0] + 5, green_bar_bottom + 5),  # Под зеленой полоской
                    font_size=16,
                    color=(255, 200, 100),  # Оранжевый текст для лучшей видимости
                    bg_color=(0, 0, 0, 0)  # Прозрачный фон, так как уже есть подложка
                )
        
        # Запишем обработанный кадр в выходное видео
        out.write(frame)
        
        # Выводим прогресс и обновляем индикатор
        frame_count += 1
        if frame_count % 10 == 0:
            # Рассчитываем процент выполнения для текущего количества кадров
            percent_complete = min(75, frame_count * 75 / total_frames) if total_frames > 0 else 0
            # Логирование прогресса в консоль
            logger.info(f"Processed {frame_count}/{total_frames} frames ({frame_count*100/total_frames:.1f}%)")
            
            # Обновляем индикатор прогресса в Telegram через callback функцию
            if progress_callback:
                stage_message = f"Обработка кадров видео ({frame_count}/{total_frames})"
                progress_callback(int(percent_complete), stage_message)
    
    # Освобождаем ресурсы
    cap.release()
    out.release()
    face_mesh.close()
    
    # Логируем завершение основного этапа обработки
    logger.info("Основной этап обработки кадров завершен (85%)")
    
    # Обновляем прогресс до 85% - основной этап обработки кадров завершен
    if progress_callback:
        progress_callback(85, "Финальная обработка видео")
    
    # Нормализуем суммарные баллы по всем кадрам
    normalized_scores = {}
    total_score_sum = sum(total_scores.values())
    if total_score_sum > 0:
        for shape, score in total_scores.items():
            normalized_scores[shape] = (score / total_score_sum) * 100
    
    # Определяем наиболее частую форму лица в видео на основе подсчета кадров
    most_common_shape = max(face_shape_counts.items(), key=lambda x: x[1])[0] if any(face_shape_counts.values()) else "Unknown"
    
    # Добавляем статистику в конце видео
    cap = cv2.VideoCapture(output_video_path)
    final_video_path = input_video_path + "_final.avi"
    # Используем тот же MJPG кодек для финального видео
    final_out = cv2.VideoWriter(final_video_path, fourcc, fps, (width, height))
    
    # Копируем все кадры из промежуточного видео
    while True:
        ret, frame = cap.read()
        if not ret:
            break
        final_out.write(frame)
    
    # Получаем русский перевод для наиболее частой формы лица
    face_shape_names_ru = {
        "OVAL": "ОВАЛЬНАЯ",
        "ROUND": "КРУГЛАЯ",
        "SQUARE": "КВАДРАТНАЯ",
        "HEART": "СЕРДЦЕВИДНАЯ",
        "OBLONG": "ПРОДОЛГОВАТАЯ",
        "DIAMOND": "РОМБОВИДНАЯ",
        "Unknown": "НЕИЗВЕСТНАЯ"
    }
    most_common_shape_ru = face_shape_names_ru.get(most_common_shape, most_common_shape)
    
    # Создаем финальный кадр с результатами
    result_frame = np.zeros((height, width, 3), dtype=np.uint8)
    
    # Убираем итоговый блок данных из видео, чтобы исключить несоответствие
    # Просто выведем лог, но не будем добавлять заголовок
    logger.debug(f"Форма лица определена как: {most_common_shape_ru}, но блок анализа будет скрыт")
    
    # Добавляем статистику по детекции лица в кадрах с 3D эффектом
    # Разделим экран на две колонки для лучшего представления информации
    left_column_x = 30
    right_column_x = width // 2 + 40
    
    # Начальные позиции для колонок
    left_y_pos = 100
    right_y_pos = 100
    
    # Создаем полупрозрачный темный фон для всего экрана
    overlay = result_frame.copy()
    cv2.rectangle(overlay, (0, 0), (width, height), (0, 0, 0), -1)
    cv2.addWeighted(overlay, 0.5, result_frame, 0.5, 0, result_frame)
    
    # ЛЕВАЯ КОЛОНКА - Основная информация

    # Статистика обнаружения лица
    detection_text = f"📷 Лицо обнаружено в {frames_with_face} из {frame_count} кадров ({frames_with_face*100/frame_count:.1f}%)"
    result_frame = draw_text_with_pil(
        result_frame,
        detection_text,
        (left_column_x, left_y_pos),
        font_size=26,
        color=(220, 220, 220),  # Почти белый
        bg_color=(0, 0, 0, 180)  # Полупрозрачный черный фон
    )
    left_y_pos += 60
    
    # Определяем цвета для текста
    colors = [
        (50, 200, 250),  # Голубой
        (100, 200, 50),  # Зеленоватый
        (200, 150, 50),  # Оранжевый
        (250, 100, 100),  # Красноватый
        (150, 100, 250),  # Фиолетовый
        (100, 220, 220)   # Бирюзовый
    ]
    
    # Добавляем блок с информацией о коже и лице
    right_y_pos += 30  # Делаем отступ
    
    # Заголовок блока с информацией о коже и асимметрии
    skin_section_title = "🔍 АНАЛИЗ КОЖИ И АСИММЕТРИИ:"
    result_frame = draw_text_with_pil(
        result_frame,
        skin_section_title,
        (right_column_x, right_y_pos),
        font_size=26,
        color=(255, 170, 50),  # Оранжевый цвет
        bg_color=(0, 0, 0, 180)  # Полупрозрачный черный фон
    )
    right_y_pos += 50
    
    # Вычисляем средние показатели асимметрии по всем кадрам
    avg_vertical_asymmetry = vertical_asymmetry_sum / frames_with_face if frames_with_face > 0 else 0.0
    avg_horizontal_asymmetry = horizontal_asymmetry_sum / frames_with_face if frames_with_face > 0 else 0.0
    
    # Определяем наиболее вероятную возрастную группу
    # Проверяем тип переменной age_ranges перед использованием её методов
    if isinstance(age_ranges, dict):
        most_common_age_range = max(age_ranges.items(), key=lambda x: x[1])[0] if any(age_ranges.values()) else "25-35"
    else:
        logger.warning(f"В get_most_common_age_range age_ranges не является словарем: {type(age_ranges)}")
        most_common_age_range = "25-35"  # Значение по умолчанию
    avg_age = age_sum / frames_with_face if frames_with_face > 0 else 30.0
    
    # Отображаем информацию об асимметрии
    asymmetry_text = "👁️ Асимметрия лица:"
    result_frame = draw_text_with_pil(
        result_frame,
        asymmetry_text,
        (right_column_x + 20, right_y_pos),
        font_size=22,
        color=(255, 200, 100),
        bg_color=(0, 0, 0, 180)
    )
    right_y_pos += 35
    
    # Вертикальная асимметрия
    if avg_vertical_asymmetry > 0.4:
        vert_asymm_text = "  ↕️ Вертикальная: Заметная"
        vert_color = (250, 100, 100)  # Красноватый (проблема)
    elif avg_vertical_asymmetry > 0.2:
        vert_asymm_text = "  ↕️ Вертикальная: Умеренная"
        vert_color = (250, 170, 50)   # Оранжевый (небольшая проблема)
    else:
        vert_asymm_text = "  ↕️ Вертикальная: Незначительная"
        vert_color = (100, 200, 100)  # Зеленоватый (нет проблемы)
    
    result_frame = draw_text_with_pil(
        result_frame,
        vert_asymm_text,
        (right_column_x + 40, right_y_pos),
        font_size=20,
        color=vert_color,
        bg_color=(0, 0, 0, 180)
    )
    right_y_pos += 30
    
    # Горизонтальная асимметрия
    if avg_horizontal_asymmetry > 0.4:
        horiz_asymm_text = "  ↔️ Горизонтальная: Заметная"
        horiz_color = (250, 100, 100)  # Красноватый
    elif avg_horizontal_asymmetry > 0.2:
        horiz_asymm_text = "  ↔️ Горизонтальная: Умеренная"
        horiz_color = (250, 170, 50)   # Оранжевый
    else:
        horiz_asymm_text = "  ↔️ Горизонтальная: Незначительная"
        horiz_color = (100, 200, 100)  # Зеленоватый
    
    result_frame = draw_text_with_pil(
        result_frame,
        horiz_asymm_text,
        (right_column_x + 40, right_y_pos),
        font_size=20,
        color=horiz_color,
        bg_color=(0, 0, 0, 180)
    )
    right_y_pos += 45
    
    # Возрастная оценка с использованием наиболее распространенной возрастной группы
    age_text = f"🧓 Возрастная группа: {most_common_age_range} (Ср. возраст: {avg_age:.1f})"
    result_frame = draw_text_with_pil(
        result_frame,
        age_text,
        (right_column_x + 20, right_y_pos),
        font_size=22,
        color=(200, 200, 255),  # Голубоватый
        bg_color=(0, 0, 0, 180)
    )
    right_y_pos += 45
    
    # Добавляем анализ кожи
    skin_text = "🔍 Состояние кожи:"
    result_frame = draw_text_with_pil(
        result_frame,
        skin_text,
        (right_column_x + 20, right_y_pos),
        font_size=22,
        color=(255, 180, 120),  # Персиковый цвет
        bg_color=(0, 0, 0, 180)
    )
    right_y_pos += 35
    
    # Анализ текстуры кожи (на основе накопленных данных)
    texture_issue_level = "норма" 
    if avg_vertical_asymmetry > 0.3 or avg_horizontal_asymmetry > 0.3:
        texture_issue_level = "требует ухода"
    
    skin_condition_text = f"  ✨ Текстура кожи: {texture_issue_level}"
    result_frame = draw_text_with_pil(
        result_frame,
        skin_condition_text,
        (right_column_x + 40, right_y_pos),
        font_size=20,
        color=(255, 200, 150),  # Персиковый цвет
        bg_color=(0, 0, 0, 180)
    )
    
    # Добавляем финальный кадр в течение 5 секунд (fps * 5 кадров)
    for _ in range(int(fps * 5)):
        final_out.write(result_frame)
    
    # Освобождаем ресурсы
    cap.release()
    final_out.release()
    
    # Полностью удалена обработка звука для повышения производительности и стабильности
    logger.info("Звуковая обработка отключена для улучшения производительности")
    
    # Обновляем индикатор прогресса до 90%
    if progress_callback:
        logger.info("Подготовка видео (90%)")
        progress_callback(90, "Финализация видео")
    
    # Используем видео напрямую без обработки звука
    with open(final_video_path, 'rb') as f:
        processed_video_bytes = f.read()
        
    # Обновляем индикатор прогресса до 95%
    if progress_callback:
        logger.info("Финализация видео (95%)")
        progress_callback(95, "Финализация видео")
    
    # Удаляем временные файлы
    try:
        # Теперь управляем только видео файлами, так как обработка аудио полностью удалена
        temp_files = [input_video_path, output_video_path, final_video_path]
            
        for temp_file in temp_files:
            if temp_file and os.path.exists(temp_file):
                os.remove(temp_file)
                logger.debug(f"Удален временный файл: {temp_file}")
    except Exception as e:
        logger.error(f"Ошибка при удалении временных файлов: {e}")
    
    # Финальное обновление прогресса - 100%
    if progress_callback:
        logger.info("Обработка видео успешно завершена (100%)")
        progress_callback(100, "✅ Обработка видео завершена")
    
    # Если запрошены данные анализа, собираем их
    if return_analysis:
        # Определяем итоговую форму лица на основе подсчета кадров
        if frames_with_face > 0:
            face_shape = max(face_shape_counts, key=face_shape_counts.get)
            
            # Рассчитываем средние пропорции лица
            avg_width_ratio = width_ratio_sum / frames_with_face if frames_with_face > 0 else 0.76
            avg_forehead_ratio = forehead_ratio_sum / frames_with_face if frames_with_face > 0 else 1.1
            avg_cheekbone_ratio = cheekbone_ratio_sum / frames_with_face if frames_with_face > 0 else 1.3
            
            # Определяем средние значения асимметрии
            avg_vertical = vertical_asymmetry_sum / frames_with_face if frames_with_face > 0 else 0.2
            avg_horizontal = horizontal_asymmetry_sum / frames_with_face if frames_with_face > 0 else 0.15
            
            # Определяем наиболее распространенную возрастную группу
            most_common_age = max(age_ranges, key=age_ranges.get) if age_ranges else "25-35"
            
            # Определяем средний возраст
            average_age = age_sum / frames_with_face if frames_with_face > 0 else 30
            
            # Собираем результаты анализа в словарь
            analysis_data = {
                "face_shape": face_shape,
                "width_ratio": avg_width_ratio,
                "forehead_ratio": avg_forehead_ratio,
                "cheekbone_ratio": avg_cheekbone_ratio,
                "vertical_asymmetry": avg_vertical,
                "horizontal_asymmetry": avg_horizontal,
                "most_common_age_range": most_common_age,
                "average_age": average_age,
                "frames_analyzed": frame_count,
                "frames_with_face": frames_with_face,
                "face_shape_counts": face_shape_counts,
                "age_ranges": age_ranges
            }
            
            return processed_video_bytes, analysis_data
        else:
            # Если не обнаружено лиц, возвращаем базовые данные
            default_analysis = {
                "face_shape": "OVAL",
                "width_ratio": 0.76,
                "forehead_ratio": 1.1,
                "cheekbone_ratio": 1.3,
                "vertical_asymmetry": 0.2,
                "horizontal_asymmetry": 0.15,
                "most_common_age_range": "25-35",
                "average_age": 30,
                "frames_analyzed": frame_count,
                "frames_with_face": 0,
                "face_shape_counts": face_shape_counts,
                "age_ranges": age_ranges
            }
            return processed_video_bytes, default_analysis
    
    # Если аналитические данные не запрашиваются, возвращаем только видео
    return processed_video_bytes

if __name__ == "__main__":
    # Этот блок позволяет тестировать функцию отдельно
    print("Модуль обработки видео с сеткой лицевых ориентиров")
    print("Используйте функцию process_video_with_grid() для обработки видео")